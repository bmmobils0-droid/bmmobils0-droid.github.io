import 'server-only';
import Stripe from 'stripe';

let client: Stripe | null | undefined;

/** Cliente de Stripe, o null si no hay clave configurada. La clave secreta solo existe en el servidor. */
export function getStripe(): Stripe | null {
  if (client !== undefined) return client;
  const key = process.env.STRIPE_SECRET_KEY;
  client = key ? new Stripe(key, { appInfo: { name: 'BM Mobils' }, maxNetworkRetries: 2 }) : null;
  return client;
}

/** Los pagos solo se activan si hay clave secreta y secreto de webhook (sin webhook no se pueden confirmar pedidos). */
export function paymentsConfigured(): boolean {
  return Boolean(process.env.STRIPE_SECRET_KEY && process.env.STRIPE_WEBHOOK_SECRET);
}

export function stripeMode(): 'test' | 'live' | 'off' {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) return 'off';
  return key.startsWith('sk_live_') || key.startsWith('rk_live_') ? 'live' : 'test';
}

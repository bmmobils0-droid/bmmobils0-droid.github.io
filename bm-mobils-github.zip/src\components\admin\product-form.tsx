'use client';

import { useRouter } from 'next/navigation';
import { useState, useTransition } from 'react';
import { useFieldArray, useForm, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import type { z } from 'zod';
import { Copy, Plus, Trash2 } from 'lucide-react';
import { saveProductAction } from '@/app/admin/actions/products';
import { productSchema } from '@/lib/validators';
import { GRADE_LABEL } from '@/lib/labels';
import { cn } from '@/lib/cn';
import { Button } from '../ui/button';
import { Checkbox, Field, Input, Select, Textarea } from '../ui/field';
import { useToast } from '../toast';
import { Card } from './ui';

type In = z.input<typeof productSchema>;
type Out = z.output<typeof productSchema>;
type Opt = { id: string; name: string };

const emptyVariant = (): In['variants'][number] => ({
  sku: '', storageGb: '', optionLabel: '', color: '', colorHex: '', grade: '', batteryHealth: '', batteryCheckedAt: '',
  price: '', compareAt: '', stock: 0, lowStockAt: 2, isActive: true
});

export function ProductForm({ productId, defaults, brands, categories, canDelete }: {
  productId: string | null; defaults: In; brands: Opt[]; categories: (Opt & { parent: string | null })[]; canDelete?: boolean;
}) {
  const router = useRouter();
  const { show } = useToast();
  const [pending, start] = useTransition();
  const [formError, setFormError] = useState<string | null>(null);
  const { register, control, handleSubmit, setError, formState: { errors, isDirty }, reset, getValues } = useForm<In, unknown, Out>({
    resolver: zodResolver(productSchema),
    defaultValues: defaults
  });
  const variants = useFieldArray({ control, name: 'variants' });
  const specs = useFieldArray({ control, name: 'specs' });
  const condition = useWatch({ control, name: 'condition' });
  const isDemo = useWatch({ control, name: 'isDemo' });

  const onSubmit = () =>
    start(async () => {
      setFormError(null);
      // Se envían los valores crudos: el servidor vuelve a validar con el mismo esquema.
      const res = await saveProductAction(productId, getValues());
      if (!res.ok) {
        setFormError(res.message);
        show(res.message, { tone: 'error' });
        for (const [k, msg] of Object.entries(res.errors ?? {})) setError(k as keyof In, { message: msg });
        return;
      }
      show(res.message);
      if (res.redirect) router.push(res.redirect);
      else { reset(getValues()); router.refresh(); }
    });

  const e = errors as Record<string, { message?: string } | undefined>;
  const ve = (i: number, k: string) => (errors.variants?.[i] as Record<string, { message?: string }> | undefined)?.[k]?.message;

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
      {formError && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{formError}</p>}

      <div className="grid gap-4 xl:grid-cols-[1fr_340px]">
        <div className="space-y-4">
          <Card title="Información básica">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Nombre completo" htmlFor="p-name" error={e.name?.message} className="sm:col-span-2"><Input id="p-name" {...register('name')} /></Field>
              <Field label="Modelo" htmlFor="p-model" error={e.model?.message} hint="Se usa en filtros y búsqueda (p. ej. “iPhone 15 Pro”)."><Input id="p-model" {...register('model')} /></Field>
              <Field label="URL (slug)" htmlFor="p-slug" error={e.slug?.message} hint="Vacío = se genera a partir del nombre." optional><Input id="p-slug" placeholder="iphone-15-pro-256gb" {...register('slug')} /></Field>
              <Field label="Marca" htmlFor="p-brand" error={e.brandId?.message}>
                <Select id="p-brand" {...register('brandId')}><option value="">Selecciona…</option>{brands.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</Select>
              </Field>
              <Field label="Categoría" htmlFor="p-category" error={e.categoryId?.message}>
                <Select id="p-category" {...register('categoryId')}><option value="">Selecciona…</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.parent ? `${c.parent} › ` : ''}{c.name}</option>)}</Select>
              </Field>
              <Field label="Descripción detallada" htmlFor="p-description" className="sm:col-span-2"><Textarea id="p-description" rows={6} {...register('description')} /></Field>
            </div>
          </Card>

          <Card title="Estado del dispositivo">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Condición" htmlFor="p-condition">
                <Select id="p-condition" {...register('condition')}><option value="NEW">Nuevo</option><option value="REFURBISHED">Reacondicionado</option><option value="USED">Segunda mano</option></Select>
              </Field>
              <div />
              {condition !== 'NEW' && (
                <Field label="Estado estético y técnico" htmlFor="p-conditionDetails" className="sm:col-span-2" hint="Describe con precisión arañazos, marcas, piezas sustituidas y pruebas realizadas. No incluyas nada que no se haya comprobado." optional>
                  <Textarea id="p-conditionDetails" rows={4} {...register('conditionDetails')} />
                </Field>
              )}
              <Field label="Garantía (meses)" htmlFor="p-warrantyMonths" error={e.warrantyMonths?.message} optional><Input id="p-warrantyMonths" inputMode="numeric" {...register('warrantyMonths')} /></Field>
              <Field label="Texto de garantía" htmlFor="p-warrantyText" optional hint="Si se deja vacío se indica la garantía legal."><Input id="p-warrantyText" {...register('warrantyText')} /></Field>
            </div>
          </Card>

          <Card title="Variantes, precios y stock" actions={<Button size="sm" variant="outline" onClick={() => variants.append(emptyVariant())}><Plus className="size-4" />Añadir variante</Button>}>
            {e.variants?.message && <p className="mb-3 text-sm text-danger">{e.variants.message}</p>}
            <div className="space-y-3">
              {variants.fields.map((f, i) => (
                <fieldset key={f.id} className="rounded-xl border border-line p-4">
                  <legend className="sr-only">Variante {i + 1}</legend>
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <Field label="SKU" htmlFor={`v-${i}-sku`} error={ve(i, 'sku')}><Input id={`v-${i}-sku`} className="h-10 uppercase" {...register(`variants.${i}.sku`)} /></Field>
                    <Field label="Almacenamiento (GB)" htmlFor={`v-${i}-storage`} error={ve(i, 'storageGb')} optional><Input id={`v-${i}-storage`} className="h-10" inputMode="numeric" placeholder="128" {...register(`variants.${i}.storageGb`)} /></Field>
                    <Field label="Otra opción" htmlFor={`v-${i}-option`} optional hint="Si no es capacidad: “1 m”, “44 mm”…"><Input id={`v-${i}-option`} className="h-10" {...register(`variants.${i}.optionLabel`)} /></Field>
                    <Field label="Color" htmlFor={`v-${i}-color`} optional><Input id={`v-${i}-color`} className="h-10" {...register(`variants.${i}.color`)} /></Field>
                    <Field label="Color (hex)" htmlFor={`v-${i}-hex`} error={ve(i, 'colorHex')} optional><Input id={`v-${i}-hex`} className="h-10" placeholder="#2E3642" {...register(`variants.${i}.colorHex`)} /></Field>
                    {condition !== 'NEW' && (
                      <Field label="Estado estético" htmlFor={`v-${i}-grade`} optional>
                        <Select id={`v-${i}-grade`} className="h-10" {...register(`variants.${i}.grade`)}><option value="">—</option>{(['EXCELLENT', 'VERY_GOOD', 'GOOD'] as const).map((g) => <option key={g} value={g}>{GRADE_LABEL[g]}</option>)}</Select>
                      </Field>
                    )}
                    {condition !== 'NEW' && (
                      <Field label="Salud batería (%)" htmlFor={`v-${i}-battery`} error={ve(i, 'batteryHealth')} optional hint="Solo si se ha verificado."><Input id={`v-${i}-battery`} className="h-10" inputMode="numeric" {...register(`variants.${i}.batteryHealth`)} /></Field>
                    )}
                    {condition !== 'NEW' && (
                      <Field label="Comprobada el" htmlFor={`v-${i}-batteryAt`} error={ve(i, 'batteryCheckedAt')} optional><Input id={`v-${i}-batteryAt`} className="h-10" type="date" {...register(`variants.${i}.batteryCheckedAt`)} /></Field>
                    )}
                    <Field label="Precio (€, IVA incl.)" htmlFor={`v-${i}-price`} error={ve(i, 'price')}><Input id={`v-${i}-price`} className="h-10" inputMode="decimal" placeholder="499,00" {...register(`variants.${i}.price`)} /></Field>
                    <Field label="Precio anterior (€)" htmlFor={`v-${i}-compare`} error={ve(i, 'compareAt')} optional hint="Precio promocional: muestra el descuento."><Input id={`v-${i}-compare`} className="h-10" inputMode="decimal" {...register(`variants.${i}.compareAt`)} /></Field>
                    <Field label="Stock" htmlFor={`v-${i}-stock`} error={ve(i, 'stock')}><Input id={`v-${i}-stock`} className="h-10" inputMode="numeric" {...register(`variants.${i}.stock`)} /></Field>
                    <Field label="Aviso de poco stock" htmlFor={`v-${i}-low`}><Input id={`v-${i}-low`} className="h-10" inputMode="numeric" {...register(`variants.${i}.lowStockAt`)} /></Field>
                  </div>
                  <input type="hidden" {...register(`variants.${i}.id`)} />
                  <input type="hidden" {...register(`variants.${i}.originalStock`)} />
                  <div className="mt-3 flex flex-wrap items-center gap-4">
                    <Checkbox label="Activa" {...register(`variants.${i}.isActive`)} />
                    <button type="button" className="ml-auto inline-flex items-center gap-1 text-sm text-ink-2 hover:text-ink" onClick={() => { const v = getValues(`variants.${i}`); variants.insert(i + 1, { ...v, id: undefined, originalStock: undefined, sku: `${v.sku}-COPIA`, stock: 0 }); }}>
                      <Copy className="size-4" aria-hidden />Duplicar
                    </button>
                    <button type="button" disabled={variants.fields.length === 1} className="inline-flex items-center gap-1 text-sm text-ink-2 hover:text-danger disabled:opacity-40" onClick={() => variants.remove(i)}>
                      <Trash2 className="size-4" aria-hidden />Quitar
                    </button>
                  </div>
                </fieldset>
              ))}
            </div>
            <p className="mt-3 text-xs text-muted">Las variantes con pedidos no se borran: se desactivan. El stock se ajusta según la diferencia con el valor que tenía al abrir esta página.</p>
          </Card>

          <Card title="Especificaciones técnicas" actions={<Button size="sm" variant="outline" onClick={() => specs.append({ label: '', value: '' })}><Plus className="size-4" />Añadir</Button>}>
            {specs.fields.length === 0 && <p className="text-sm text-muted">Añade solo especificaciones verificadas.</p>}
            <div className="space-y-2">
              {specs.fields.map((f, i) => (
                <div key={f.id} className="flex gap-2">
                  <Input aria-label="Nombre" placeholder="Pantalla" className="h-10 w-1/3" {...register(`specs.${i}.label`)} />
                  <Input aria-label="Valor" placeholder='6,1"' className="h-10 flex-1" {...register(`specs.${i}.value`)} />
                  <button type="button" onClick={() => specs.remove(i)} className="grid size-10 flex-none place-items-center rounded-lg hover:bg-soft" aria-label="Quitar especificación"><Trash2 className="size-4" /></button>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card title="Publicación">
            <div className="space-y-4">
              <Field label="Estado" htmlFor="p-status"><Select id="p-status" {...register('status')}><option value="DRAFT">Borrador</option><option value="PUBLISHED">Publicado</option><option value="ARCHIVED">Archivado</option></Select></Field>
              <Checkbox label="Destacado en la portada" {...register('featured')} />
              <Checkbox label="Producto de demostración (no se puede comprar)" {...register('isDemo')} />
              {isDemo && <p className="rounded-lg bg-warn-soft p-2.5 text-xs text-[#6b3e00]">Desmárcalo solo cuando confirmes que el producto existe y los datos son reales.</p>}
              <Field label="IVA (puntos básicos)" htmlFor="p-tax" hint="2100 = 21 %. Los precios se introducen con IVA incluido."><Input id="p-tax" inputMode="numeric" {...register('taxRate')} /></Field>
            </div>
          </Card>
          <Card title="SEO">
            <div className="space-y-4">
              <Field label="Título SEO" htmlFor="p-seoTitle" optional error={e.seoTitle?.message}><Input id="p-seoTitle" maxLength={70} {...register('seoTitle')} /></Field>
              <Field label="Descripción SEO" htmlFor="p-seoDescription" optional error={e.seoDescription?.message}><Textarea id="p-seoDescription" rows={3} maxLength={170} className="min-h-0" {...register('seoDescription')} /></Field>
            </div>
          </Card>
          <div className={cn('sticky bottom-4 rounded-card border border-line bg-white p-4 shadow-card')}>
            <Button type="submit" className="w-full" disabled={pending}>{pending ? 'Guardando…' : productId ? 'Guardar cambios' : 'Crear producto'}</Button>
            {isDirty && <p className="mt-2 text-center text-xs text-muted">Hay cambios sin guardar.</p>}
            {canDelete === false && productId && <p className="mt-2 text-center text-xs text-muted">Solo un administrador puede eliminar productos.</p>}
          </div>
        </div>
      </div>
    </form>
  );
}

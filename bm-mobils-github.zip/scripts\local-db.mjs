// PostgreSQL local para desarrollo, sin instalar nada en el sistema.
// Uso: npm run db:local  (déjalo abierto en una terminal; Ctrl+C para pararlo)
// Conexión: postgresql://postgres:postgres@localhost:5433/bm_mobils
import EmbeddedPostgres from 'embedded-postgres';
import { existsSync, readFileSync, rmSync } from 'node:fs';
import path from 'node:path';

const dataDir = path.resolve('.local-db/data');
const port = Number(process.env.LOCAL_DB_PORT || 5433);

const pg = new EmbeddedPostgres({
  databaseDir: dataDir,
  user: 'postgres',
  password: 'postgres',
  port,
  persistent: true
});

// Si el equipo o la terminal se cerraron de golpe, queda un postmaster.pid huérfano que impide arrancar.
const pidFile = path.join(dataDir, 'postmaster.pid');
if (existsSync(pidFile)) {
  const pid = Number(readFileSync(pidFile, 'utf8').split('\n')[0]);
  let alive = false;
  try { process.kill(pid, 0); alive = true; } catch { /* el proceso ya no existe */ }
  if (!alive) rmSync(pidFile);
}

const firstRun = !existsSync(path.join(dataDir, 'PG_VERSION'));
if (firstRun) await pg.initialise();
await pg.start();
if (firstRun) await pg.createDatabase('bm_mobils');

console.log(`PostgreSQL local listo en postgresql://postgres:postgres@localhost:${port}/bm_mobils`);

const stop = async () => {
  await pg.stop();
  process.exit(0);
};
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
setInterval(() => {}, 1 << 30);

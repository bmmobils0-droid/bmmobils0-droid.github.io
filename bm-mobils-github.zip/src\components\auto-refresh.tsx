'use client';

import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

/** Refresca la página periódicamente (p. ej. mientras llega la confirmación del pago). Se detiene tras 2 minutos. */
export function AutoRefresh({ seconds }: { seconds: number }) {
  const router = useRouter();
  useEffect(() => {
    const started = Date.now();
    const id = setInterval(() => {
      if (Date.now() - started > 120_000) return clearInterval(id);
      router.refresh();
    }, seconds * 1000);
    return () => clearInterval(id);
  }, [router, seconds]);
  return null;
}

import type { Metadata } from 'next';
import { Lock, ShoppingBag } from 'lucide-react';
import { getCartView } from '@/lib/cart';
import { formatPrice } from '@/lib/money';
import { Breadcrumbs } from '@/components/store/breadcrumbs';
import { CartLines, CouponForm } from '@/components/store/cart-lines';
import { EmptyState } from '@/components/store/empty-state';
import { ButtonLink } from '@/components/ui/button';

export const metadata: Metadata = { title: 'Carrito', robots: { index: false } };

export default async function CartPage() {
  const view = await getCartView();
  return (
    <div className="container-page pt-6">
      <Breadcrumbs items={[{ label: 'Carrito' }]} />
      <h1 className="mb-7 text-[28px] font-bold sm:text-4xl">Tu carrito</h1>
      {!view ? (
        <EmptyState icon={ShoppingBag} title="Tu carrito está vacío" text="Cuando añadas productos, aparecerán aquí.">
          <ButtonLink href="/moviles">Ver móviles</ButtonLink>
        </EmptyState>
      ) : (
        <div className="grid items-start gap-10 lg:grid-cols-[1fr_380px] lg:gap-12">
          <CartLines lines={view.lines} />
          <aside className="flex flex-col gap-3 rounded-card bg-soft p-6 lg:sticky lg:top-[136px]" aria-label="Resumen">
            <h2 className="mb-1 text-lg font-semibold">Resumen</h2>
            <div className="flex justify-between text-[14.5px] text-ink-2"><span>Subtotal ({view.count} {view.count === 1 ? 'artículo' : 'artículos'})</span><span>{formatPrice(view.totals.subtotalCents)}</span></div>
            {view.totals.discountCents > 0 && <div className="flex justify-between text-[14.5px] text-ok"><span>Descuento</span><span>−{formatPrice(view.totals.discountCents)}</span></div>}
            <div className="flex justify-between text-[14.5px] text-ink-2"><span>Envío</span><span>Según tu código postal</span></div>
            <div className="mt-1 flex justify-between border-t border-line-strong pt-3 text-lg font-bold"><span>Total estimado</span><span>{formatPrice(view.totals.subtotalCents - view.totals.discountCents)}</span></div>
            <p className="text-[12.5px] text-muted">IVA incluido.</p>
            {view.totals.couponError && view.couponCode && <p className="text-[13px] text-danger">{view.totals.couponError}</p>}
            <div className="py-2"><CouponForm code={view.couponCode} /></div>
            {view.hasIssues ? (
              <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger">Revisa los productos marcados antes de continuar.</p>
            ) : (
              <ButtonLink href="/checkout" size="lg" className="w-full">Finalizar compra</ButtonLink>
            )}
            <p className="flex items-center justify-center gap-2 text-[12.5px] text-muted"><Lock className="size-3.5" aria-hidden />Pago seguro con Stripe</p>
          </aside>
        </div>
      )}
    </div>
  );
}

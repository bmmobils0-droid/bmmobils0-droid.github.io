import 'server-only';
import { cookies } from 'next/headers';
import type { Prisma } from '@/generated/prisma/client';
import type { ShippingZone } from '@/generated/prisma/enums';
import { db } from './db';
import { hashToken, randomToken } from './crypto';
import { computeTotals, type CouponRule } from './pricing';
import { variantLabel } from './labels';
import { artFor } from './device-art';
import { getSettings } from './settings';

export const CART_COOKIE = 'bm_cart';
export const MAX_PER_LINE = 10;
const CART_DAYS = 60;

const cartInclude = {
  items: {
    orderBy: { createdAt: 'asc' },
    include: {
      variant: {
        include: {
          product: {
            select: {
              id: true, slug: true, name: true, model: true, status: true, isDemo: true, taxRate: true,
              brand: { select: { slug: true, name: true } },
              category: { select: { slug: true } },
              images: { orderBy: { position: 'asc' }, take: 1, select: { url: true, alt: true } }
            }
          }
        }
      }
    }
  }
} satisfies Prisma.CartInclude;

export type CartWithItems = Prisma.CartGetPayload<{ include: typeof cartInclude }>;

async function cartIdFromCookie(): Promise<string | null> {
  const token = (await cookies()).get(CART_COOKIE)?.value;
  return token ? hashToken(token) : null;
}

export async function getCart(): Promise<CartWithItems | null> {
  const id = await cartIdFromCookie();
  if (!id) return null;
  return db.cart.findUnique({ where: { id }, include: cartInclude });
}

export async function getCartCount(): Promise<number> {
  const id = await cartIdFromCookie();
  if (!id) return 0;
  const agg = await db.cartItem.aggregate({ where: { cartId: id }, _sum: { quantity: true } });
  return agg._sum.quantity ?? 0;
}

/** Solo desde server actions o route handlers (escribe la cookie). */
export async function getOrCreateCartId(userId?: string | null): Promise<string> {
  const existing = await cartIdFromCookie();
  if (existing && (await db.cart.findUnique({ where: { id: existing }, select: { id: true } }))) return existing;
  const token = randomToken();
  const id = hashToken(token);
  await db.cart.create({ data: { id, userId: userId ?? null } });
  (await cookies()).set(CART_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: CART_DAYS * 86400
  });
  return id;
}

export type CartActionResult = { ok: boolean; message: string };

export async function addItem(variantId: string, quantity: number, userId?: string | null): Promise<CartActionResult> {
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > MAX_PER_LINE) return { ok: false, message: 'Cantidad no válida.' };
  const variant = await db.productVariant.findUnique({
    where: { id: variantId },
    select: { id: true, stock: true, isActive: true, product: { select: { status: true, isDemo: true } } }
  });
  if (!variant || !variant.isActive || variant.product.status !== 'PUBLISHED') return { ok: false, message: 'Este producto no está disponible.' };
  if (variant.product.isDemo) return { ok: false, message: 'Este es un producto de demostración y no se puede comprar.' };
  if (variant.stock < 1) return { ok: false, message: 'Este producto está agotado.' };

  const cartId = await getOrCreateCartId(userId);
  const current = await db.cartItem.findUnique({ where: { cartId_variantId: { cartId, variantId } } });
  const wanted = Math.min((current?.quantity ?? 0) + quantity, variant.stock, MAX_PER_LINE);
  if (current && wanted === current.quantity) return { ok: false, message: `No hay más unidades disponibles de esta variante (máximo ${wanted}).` };
  await db.cartItem.upsert({
    where: { cartId_variantId: { cartId, variantId } },
    create: { cartId, variantId, quantity: wanted },
    update: { quantity: wanted }
  });
  await db.cart.update({ where: { id: cartId }, data: { updatedAt: new Date() } });
  return { ok: true, message: wanted < (current?.quantity ?? 0) + quantity ? `Añadido. Solo quedan ${variant.stock} unidades.` : 'Producto añadido al carrito.' };
}

export async function updateItemQuantity(itemId: string, quantity: number): Promise<CartActionResult> {
  const cartId = await cartIdFromCookie();
  if (!cartId) return { ok: false, message: 'Carrito no encontrado.' };
  if (!Number.isInteger(quantity) || quantity < 0 || quantity > MAX_PER_LINE) return { ok: false, message: 'Cantidad no válida.' };
  if (quantity === 0) {
    await db.cartItem.deleteMany({ where: { id: itemId, cartId } });
    return { ok: true, message: 'Producto eliminado del carrito.' };
  }
  const item = await db.cartItem.findFirst({ where: { id: itemId, cartId }, include: { variant: { select: { stock: true } } } });
  if (!item) return { ok: false, message: 'Producto no encontrado en el carrito.' };
  const q = Math.min(quantity, item.variant.stock);
  if (q < 1) return { ok: false, message: 'Esta variante está agotada.' };
  await db.cartItem.update({ where: { id: item.id }, data: { quantity: q } });
  return { ok: true, message: q < quantity ? `Solo quedan ${q} unidades disponibles.` : 'Cantidad actualizada.' };
}

export async function setCoupon(code: string | null): Promise<CartActionResult> {
  const cartId = await cartIdFromCookie();
  if (!cartId) return { ok: false, message: 'Tu carrito está vacío.' };
  if (code == null) {
    await db.cart.update({ where: { id: cartId }, data: { couponCode: null } });
    return { ok: true, message: 'Cupón eliminado.' };
  }
  const normalized = code.trim().toUpperCase().slice(0, 30);
  const coupon = await db.coupon.findUnique({ where: { code: normalized } });
  if (!coupon) return { ok: false, message: 'El cupón no existe.' };
  const view = await getCartView();
  if (!view) return { ok: false, message: 'Tu carrito está vacío.' };
  const totals = computeTotals({ lines: view.pricingLines, coupon, shippingTaxRate: view.taxRate });
  if (totals.couponError) return { ok: false, message: totals.couponError };
  await db.cart.update({ where: { id: cartId }, data: { couponCode: normalized } });
  return { ok: true, message: 'Cupón aplicado.' };
}

export type CartLineIssue = 'unavailable' | 'demo' | 'insufficient' | null;

/** Vista del carrito con precios actuales de la base de datos y problemas por línea. */
export async function getCartView(opts: { zone?: ShippingZone; shippingRateId?: string } = {}) {
  const cart = await getCart();
  if (!cart || cart.items.length === 0) return null;
  const settings = await getSettings();

  const lines = cart.items.map((item) => {
    const v = item.variant;
    const p = v.product;
    let issue: CartLineIssue = null;
    if (!v.isActive || p.status !== 'PUBLISHED') issue = 'unavailable';
    else if (p.isDemo) issue = 'demo';
    else if (v.stock < item.quantity) issue = 'insufficient';
    return {
      itemId: item.id,
      variantId: v.id,
      productId: p.id,
      slug: p.slug,
      name: p.name,
      brand: p.brand.name,
      label: variantLabel(v),
      sku: v.sku,
      quantity: item.quantity,
      available: v.stock,
      unitPriceCents: v.priceCents,
      compareAtCents: v.compareAtCents,
      lineTotalCents: v.priceCents * item.quantity,
      taxRate: p.taxRate,
      image: p.images[0] ?? null,
      art: { ...artFor({ categorySlug: p.category.slug, brandSlug: p.brand.slug, model: p.model }), color: v.colorHex },
      issue
    };
  });

  const valid = lines.filter((l) => !l.issue);
  const pricingLines = valid.map((l) => ({ unitPriceCents: l.unitPriceCents, quantity: l.quantity, taxRate: l.taxRate }));
  const coupon: CouponRule | null = cart.couponCode ? await db.coupon.findUnique({ where: { code: cart.couponCode } }) : null;

  const rates = opts.zone
    ? await db.shippingRate.findMany({ where: { active: true, zones: { has: opts.zone } }, orderBy: [{ position: 'asc' }, { priceCents: 'asc' }] })
    : [];
  const rate = rates.find((r) => r.id === opts.shippingRateId) ?? null;
  const totals = computeTotals({ lines: pricingLines, coupon, shipping: rate, shippingTaxRate: settings.defaultTaxRate });

  return {
    cart,
    lines,
    pricingLines,
    couponCode: cart.couponCode,
    totals,
    rates,
    rate,
    taxRate: settings.defaultTaxRate,
    count: lines.reduce((s, l) => s + l.quantity, 0),
    hasIssues: lines.some((l) => l.issue)
  };
}
export type CartView = NonNullable<Awaited<ReturnType<typeof getCartView>>>;

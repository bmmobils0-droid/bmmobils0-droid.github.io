import { requirePermission } from '@/lib/auth';
import { db } from '@/lib/db';
import { formatPrice } from '@/lib/money';
import { createCouponAction, toggleCouponAction } from '@/app/admin/actions/misc';
import { ActionForm } from '@/components/admin/action-form';
import { Card, PageHeader, Table } from '@/components/admin/ui';
import { ConfirmSubmit } from '@/components/confirm-dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Field, Input, Select } from '@/components/ui/field';

export const metadata = { title: 'Cupones' };

export default async function CouponsPage() {
  await requirePermission('coupons:manage');
  const coupons = await db.coupon.findMany({ orderBy: { createdAt: 'desc' } });
  const date = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', year: 'numeric' });
  return (
    <>
      <PageHeader title="Cupones" subtitle="Los descuentos se validan y calculan siempre en el servidor." />
      <Card title="Nuevo cupón" className="mb-4">
        <ActionForm action={createCouponAction} resetOnSuccess className="grid gap-3 sm:grid-cols-3 lg:grid-cols-7 lg:items-end">
          <Field label="Código" htmlFor="c-code"><Input id="c-code" name="code" className="h-10 uppercase" required /></Field>
          <Field label="Tipo" htmlFor="c-type"><Select id="c-type" name="type" className="h-10"><option value="PERCENT">Porcentaje (%)</option><option value="FIXED">Importe fijo (€)</option></Select></Field>
          <Field label="Valor" htmlFor="c-value"><Input id="c-value" name="value" inputMode="decimal" className="h-10" required /></Field>
          <Field label="Pedido mínimo (€)" htmlFor="c-min" optional><Input id="c-min" name="minSubtotal" inputMode="decimal" className="h-10" /></Field>
          <Field label="Desde" htmlFor="c-start" optional><Input id="c-start" name="startsAt" type="date" className="h-10" /></Field>
          <Field label="Hasta" htmlFor="c-end" optional><Input id="c-end" name="endsAt" type="date" className="h-10" /></Field>
          <Field label="Usos máximos" htmlFor="c-max" optional><Input id="c-max" name="maxRedemptions" inputMode="numeric" className="h-10" /></Field>
          <div className="sm:col-span-3 lg:col-span-7"><Button type="submit" size="sm">Crear cupón</Button></div>
        </ActionForm>
      </Card>
      <Table>
        <thead><tr><th>Código</th><th>Descuento</th><th>Condiciones</th><th>Usos</th><th>Estado</th><th /></tr></thead>
        <tbody>
          {coupons.length === 0 && <tr><td colSpan={6} className="py-10 text-center text-muted">No hay cupones.</td></tr>}
          {coupons.map((c) => (
            <tr key={c.id}>
              <td className="font-mono font-semibold">{c.code}</td>
              <td>{c.type === 'PERCENT' ? `${c.value / 100} %` : formatPrice(c.value)}</td>
              <td className="text-xs text-muted">
                {c.minSubtotalCents ? `Mín. ${formatPrice(c.minSubtotalCents)}` : 'Sin mínimo'}
                {c.startsAt && ` · desde ${date.format(c.startsAt)}`}{c.endsAt && ` · hasta ${date.format(c.endsAt)}`}
              </td>
              <td>{c.redemptions}{c.maxRedemptions ? ` / ${c.maxRedemptions}` : ''}</td>
              <td><Badge tone={c.active ? 'ok' : 'gray'}>{c.active ? 'Activo' : 'Inactivo'}</Badge></td>
              <td>
                <ActionForm action={toggleCouponAction} className="flex justify-end gap-2">
                  <input type="hidden" name="couponId" value={c.id} />
                  <Button type="submit" size="sm" variant="outline" name="op" value="toggle">{c.active ? 'Desactivar' : 'Activar'}</Button>
                  {c.redemptions === 0 && <ConfirmSubmit title="¿Eliminar cupón?" description={`Se eliminará el cupón ${c.code}.`} confirmLabel="Eliminar" name="op" value="delete">Eliminar</ConfirmSubmit>}
                </ActionForm>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </>
  );
}

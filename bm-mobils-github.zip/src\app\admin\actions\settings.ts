'use server';

import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { adminAction, UserError, type ActionResult } from '@/lib/admin-action';
import { db } from '@/lib/db';
import { EMAIL_TEMPLATE_KEYS, PAYMENT_METHOD_OPTIONS } from '@/lib/settings';
import { deleteImage, saveImage, UploadError } from '@/lib/storage';
import { pageSchema, settingsSchema, shippingRateSchema } from '@/lib/validators';

const revalidateAll = () => revalidatePath('/', 'layout');
const httpsOrEmpty = (v: string | undefined) => {
  if (!v) return undefined;
  if (!/^https:\/\/[^\s]+$/.test(v)) throw new UserError('Las redes sociales deben ser URLs que empiecen por https://');
  return v;
};

async function upload(file: FormDataEntryValue | null, folder: string) {
  if (!(file instanceof File) || file.size === 0) return null;
  try {
    return await saveImage(file, folder);
  } catch (err) {
    if (err instanceof UploadError) throw new UserError(err.message);
    throw err;
  }
}

export async function saveSettingsAction(fd: FormData): Promise<ActionResult> {
  return adminAction('settings:manage', async () => {
    const parsed = settingsSchema.safeParse({ ...Object.fromEntries(fd.entries()), paymentMethods: fd.getAll('paymentMethods') });
    if (!parsed.success) throw new UserError(parsed.error.issues[0].message);
    const s = parsed.data;
    const current = await db.storeSettings.findUnique({ where: { id: 1 } });

    let logoUrl = current?.logoUrl ?? null;
    const newLogo = await upload(fd.get('logo'), 'branding');
    if (newLogo || fd.get('removeLogo') === 'on') {
      if (logoUrl) await deleteImage(logoUrl);
      logoUrl = newLogo;
    }
    let heroImageUrl = current?.heroImageUrl ?? null;
    const newHero = await upload(fd.get('heroImage'), 'branding');
    if (newHero || fd.get('removeHeroImage') === 'on') {
      if (heroImageUrl) await deleteImage(heroImageUrl);
      heroImageUrl = newHero;
    }

    const data = {
      storeName: s.storeName, logoUrl, heroImageUrl, contactEmail: s.contactEmail, contactPhone: s.contactPhone, whatsapp: s.whatsapp,
      address: s.address, openingHours: s.openingHours,
      social: { instagram: httpsOrEmpty(s.instagram), facebook: httpsOrEmpty(s.facebook), tiktok: httpsOrEmpty(s.tiktok), x: httpsOrEmpty(s.x), youtube: httpsOrEmpty(s.youtube) },
      legalName: s.legalName, legalTaxId: s.legalTaxId, legalAddress: s.legalAddress, legalRegistry: s.legalRegistry,
      defaultTaxRate: Math.round(s.defaultTaxRate * 100),
      heroTitle: s.heroTitle, heroSubtitle: s.heroSubtitle,
      infoBar: s.infoBar.split('\n').map((l) => l.trim()).filter(Boolean).slice(0, 6),
      paymentMethods: s.paymentMethods.filter((m) => m in PAYMENT_METHOD_OPTIONS)
    };
    await db.storeSettings.upsert({ where: { id: 1 }, create: { id: 1, ...data }, update: data });
    revalidateAll();
    return { ok: true, message: 'Configuración guardada.' };
  });
}

export async function saveBannersAction(fd: FormData): Promise<ActionResult> {
  return adminAction('settings:manage', async () => {
    const current = await db.storeSettings.findUnique({ where: { id: 1 }, select: { banners: true } });
    const old = Array.isArray(current?.banners) ? (current!.banners as { imageUrl?: string }[]) : [];
    const banners = [];
    for (let i = 0; i < 4; i++) {
      const title = String(fd.get(`b${i}-title`) ?? '').trim().slice(0, 80);
      if (!title) { if (old[i]?.imageUrl) await deleteImage(old[i].imageUrl!); continue; }
      const href = String(fd.get(`b${i}-href`) ?? '/').trim();
      if (!href.startsWith('/')) throw new UserError('Los enlaces de los banners deben ser rutas internas que empiecen por "/".');
      let imageUrl = old[i]?.imageUrl;
      const img = await upload(fd.get(`b${i}-image`), 'banners');
      if (img || fd.get(`b${i}-removeImage`) === 'on') { if (imageUrl) await deleteImage(imageUrl); imageUrl = img ?? undefined; }
      banners.push({ title, text: String(fd.get(`b${i}-text`) ?? '').trim().slice(0, 160), href, ...(imageUrl ? { imageUrl } : {}) });
    }
    await db.storeSettings.upsert({ where: { id: 1 }, create: { id: 1, banners }, update: { banners } });
    revalidateAll();
    return { ok: true, message: 'Banners guardados.' };
  });
}

export async function saveEmailTemplatesAction(fd: FormData): Promise<ActionResult> {
  return adminAction('settings:manage', async () => {
    const templates: Record<string, { subject: string; intro: string }> = {};
    for (const key of Object.keys(EMAIL_TEMPLATE_KEYS)) {
      const subject = z.string().trim().min(3).max(150).parse(fd.get(`${key}-subject`));
      const intro = z.string().trim().min(3).max(1000).parse(fd.get(`${key}-intro`));
      templates[key] = { subject, intro };
    }
    await db.storeSettings.upsert({ where: { id: 1 }, create: { id: 1, emailTemplates: templates }, update: { emailTemplates: templates } });
    return { ok: true, message: 'Plantillas de correo guardadas.' };
  });
}

export async function saveShippingRateAction(fd: FormData): Promise<ActionResult> {
  return adminAction('settings:manage', async () => {
    const parsed = shippingRateSchema.safeParse({
      id: fd.get('id') || undefined, name: fd.get('name'), description: fd.get('description') || undefined, price: fd.get('price'),
      freeFrom: fd.get('freeFrom'), zones: fd.getAll('zones'), active: fd.get('active') === 'on'
    });
    if (!parsed.success) throw new UserError(parsed.error.issues[0].message);
    const r = parsed.data;
    const data = {
      name: r.name, description: r.description ?? null, priceCents: Math.round(r.price * 100),
      freeFromCents: r.freeFrom != null ? Math.round(r.freeFrom * 100) : null, zones: r.zones, active: r.active
    };
    if (fd.get('op') === 'delete' && r.id) {
      await db.shippingRate.delete({ where: { id: r.id } });
      revalidateAll();
      return { ok: true, message: 'Tarifa eliminada.' };
    }
    if (r.id) await db.shippingRate.update({ where: { id: r.id }, data });
    else await db.shippingRate.create({ data: { ...data, position: await db.shippingRate.count() } });
    revalidateAll();
    return { ok: true, message: 'Tarifa de envío guardada.' };
  });
}

export async function savePageAction(fd: FormData): Promise<ActionResult> {
  return adminAction('content:manage', async () => {
    const slug = z.string().regex(/^[a-z0-9-]+$/).parse(fd.get('slug'));
    const parsed = pageSchema.safeParse({ title: fd.get('title'), content: fd.get('content') ?? '', needsLegalReview: fd.get('needsLegalReview') === 'on' });
    if (!parsed.success) throw new UserError(parsed.error.issues[0].message);
    await db.page.update({ where: { slug }, data: parsed.data });
    revalidatePath(`/info/${slug}`);
    return { ok: true, message: 'Página guardada.' };
  });
}

import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ArrowDown, ArrowUp, ExternalLink } from 'lucide-react';
import { requirePermission } from '@/lib/auth';
import { db } from '@/lib/db';
import { can } from '@/lib/permissions';
import { deleteProductAction, setProductStatusAction, updateImageAction, uploadImagesAction } from '@/app/admin/actions/products';
import { ActionForm } from '@/components/admin/action-form';
import { Card, PageHeader, Table } from '@/components/admin/ui';
import { ProductForm } from '@/components/admin/product-form';
import { ConfirmSubmit } from '@/components/confirm-dialog';
import { Button } from '@/components/ui/button';
import { formOptions, loadProduct, productToForm } from '../product-data';

export const metadata = { title: 'Editar producto' };

const REASON = { INITIAL: 'Stock inicial', ADJUSTMENT: 'Ajuste manual', RESERVATION: 'Reserva de pedido', RELEASE: 'Liberación', RETURN: 'Devolución' } as const;

export default async function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requirePermission('products:write');
  const { id } = await params;
  const [product, opts] = await Promise.all([loadProduct(id), formOptions()]);
  if (!product) notFound();
  const movements = await db.inventoryMovement.findMany({
    where: { variant: { productId: id } },
    orderBy: { createdAt: 'desc' },
    take: 15,
    include: { variant: { select: { sku: true } } }
  });
  const date = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Madrid' });
  const colors = [...new Set(product.variants.map((v) => v.color).filter(Boolean))] as string[];

  return (
    <>
      <PageHeader
        title={product.name}
        subtitle={<Link href={`/producto/${product.slug}`} target="_blank" className="inline-flex items-center gap-1 text-brand hover:underline">/producto/{product.slug}<ExternalLink className="size-3.5" /></Link>}
        actions={
          <>
            {product.status !== 'PUBLISHED' ? (
              <ActionForm action={setProductStatusAction}><input type="hidden" name="productId" value={product.id} /><input type="hidden" name="status" value="PUBLISHED" /><Button type="submit" size="sm">Publicar</Button></ActionForm>
            ) : (
              <ActionForm action={setProductStatusAction}><input type="hidden" name="productId" value={product.id} /><input type="hidden" name="status" value="DRAFT" /><Button type="submit" size="sm" variant="outline">Despublicar</Button></ActionForm>
            )}
            {product.status !== 'ARCHIVED' && (
              <ActionForm action={setProductStatusAction}>
                <input type="hidden" name="productId" value={product.id} /><input type="hidden" name="status" value="ARCHIVED" />
                <ConfirmSubmit variant="outline" title="¿Archivar producto?" description="Dejará de mostrarse en la tienda. Podrás recuperarlo más tarde." confirmLabel="Archivar">Archivar</ConfirmSubmit>
              </ActionForm>
            )}
            {can(user.role, 'products:delete') && (
              <ActionForm action={deleteProductAction}>
                <input type="hidden" name="productId" value={product.id} />
                <ConfirmSubmit title="¿Eliminar definitivamente?" description="Se borrarán el producto, sus variantes y sus fotos. Si tiene pedidos no se podrá eliminar: archívalo." confirmLabel="Eliminar">Eliminar</ConfirmSubmit>
              </ActionForm>
            )}
          </>
        }
      />

      <Card title="Fotografías" className="mb-4">
        {product.images.length === 0 && <p className="mb-4 text-sm text-muted">Sin fotos: la tienda muestra una ilustración genérica.</p>}
        <ul className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {product.images.map((img, i) => (
            <li key={img.id} className="rounded-xl border border-line p-3">
              <div className="relative mb-2 aspect-square overflow-hidden rounded-lg bg-tile"><Image src={img.url} alt={img.alt} fill sizes="240px" className="object-contain" /></div>
              <ActionForm action={updateImageAction} className="space-y-2">
                <input type="hidden" name="imageId" value={img.id} />
                <input name="alt" defaultValue={img.alt} aria-label="Texto alternativo" placeholder="Texto alternativo" className="h-9 w-full rounded-lg border border-line-strong px-2.5 text-sm" />
                <select name="color" defaultValue={img.color ?? ''} aria-label="Color de la variante" className="h-9 w-full rounded-lg border border-line-strong px-2 text-sm">
                  <option value="">Todos los colores</option>{colors.map((c) => <option key={c}>{c}</option>)}
                </select>
                <div className="flex flex-wrap gap-1.5">
                  <Button type="submit" size="sm" variant="outline" name="op" value="save">Guardar</Button>
                  <Button type="submit" size="sm" variant="ghost" name="op" value="up" disabled={i === 0} aria-label="Mover antes"><ArrowUp className="size-4" /></Button>
                  <Button type="submit" size="sm" variant="ghost" name="op" value="down" disabled={i === product.images.length - 1} aria-label="Mover después"><ArrowDown className="size-4" /></Button>
                  <ConfirmSubmit title="¿Eliminar esta foto?" description="Se borrará del almacenamiento." confirmLabel="Eliminar" name="op" value="delete">Eliminar</ConfirmSubmit>
                </div>
              </ActionForm>
            </li>
          ))}
        </ul>
        <ActionForm action={uploadImagesAction} resetOnSuccess className="flex flex-wrap items-center gap-3">
          <input type="hidden" name="productId" value={product.id} />
          <input type="file" name="files" multiple accept="image/jpeg,image/png,image/webp,image/avif" aria-label="Seleccionar fotografías" className="text-sm file:mr-3 file:rounded-full file:border-0 file:bg-soft file:px-4 file:py-2 file:font-semibold" />
          <Button type="submit" size="sm">Subir</Button>
          <span className="text-xs text-muted">JPG, PNG, WebP o AVIF. Máx. 5 MB por imagen.</span>
        </ActionForm>
      </Card>

      <ProductForm productId={product.id} defaults={productToForm(product)} brands={opts.brands} categories={opts.categories} canDelete={can(user.role, 'products:delete')} />

      <div className="mt-4">
        <h2 className="mb-3 text-base font-semibold">Movimientos de inventario recientes</h2>
        <Table>
          <thead><tr><th>Fecha</th><th>SKU</th><th>Motivo</th><th>Cambio</th><th>Nota</th></tr></thead>
          <tbody>
            {movements.length === 0 && <tr><td colSpan={5} className="text-center text-muted">Sin movimientos.</td></tr>}
            {movements.map((m) => (
              <tr key={m.id}>
                <td>{date.format(m.createdAt)}</td><td className="font-mono text-xs">{m.variant.sku}</td><td>{REASON[m.reason]}</td>
                <td className={m.delta < 0 ? 'text-danger' : 'text-ok'}>{m.delta > 0 ? `+${m.delta}` : m.delta}</td><td className="text-muted">{m.note ?? (m.orderId ? 'Pedido' : '')}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </>
  );
}

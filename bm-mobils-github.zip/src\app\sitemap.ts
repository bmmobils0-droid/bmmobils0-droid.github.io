import type { MetadataRoute } from 'next';
import { db } from '@/lib/db';
import { STATIC_COLLECTION_SLUGS } from '@/lib/catalog/collections';
import { absoluteUrl } from '@/lib/site';

export const dynamic = 'force-dynamic';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [products, pages] = await Promise.all([
    // Los productos de demostración no se indexan.
    db.product.findMany({ where: { status: 'PUBLISHED', isDemo: false }, select: { slug: true, updatedAt: true, images: { take: 1, select: { url: true } } } }),
    db.page.findMany({ select: { slug: true, updatedAt: true } })
  ]);
  return [
    { url: absoluteUrl('/'), changeFrequency: 'daily', priority: 1 },
    ...STATIC_COLLECTION_SLUGS.filter((s) => s !== 'catalogo').map((s) => ({ url: absoluteUrl(`/${s}`), changeFrequency: 'daily' as const, priority: 0.8 })),
    ...products.map((p) => ({
      url: absoluteUrl(`/producto/${p.slug}`),
      lastModified: p.updatedAt,
      changeFrequency: 'weekly' as const,
      priority: 0.7,
      images: p.images.map((i) => (i.url.startsWith('http') ? i.url : absoluteUrl(i.url)))
    })),
    { url: absoluteUrl('/contacto'), changeFrequency: 'yearly', priority: 0.3 },
    ...pages.map((p) => ({ url: absoluteUrl(`/info/${p.slug}`), lastModified: p.updatedAt, changeFrequency: 'yearly' as const, priority: 0.2 }))
  ];
}

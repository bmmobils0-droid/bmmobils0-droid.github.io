import type { OrderStatus, PaymentStatus } from '@/generated/prisma/enums';

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  PENDING_PAYMENT: 'Pendiente de pago',
  PAID: 'Pagado',
  PREPARING: 'Preparando pedido',
  SHIPPED: 'Enviado',
  DELIVERED: 'Entregado',
  CANCELLED: 'Cancelado',
  REFUNDED: 'Reembolsado'
};

export const PAYMENT_STATUS_LABEL: Record<PaymentStatus, string> = {
  PENDING: 'Pendiente',
  SUCCEEDED: 'Cobrado',
  FAILED: 'Fallido',
  CANCELLED: 'Cancelado',
  REFUNDED: 'Reembolsado',
  PARTIALLY_REFUNDED: 'Reembolso parcial',
  REQUIRES_REVIEW: 'Requiere revisión'
};

/**
 * Cambios de estado que el equipo puede hacer a mano.
 *  - PAID y REFUNDED solo los fija el webhook del proveedor de pagos.
 *  - SHIPPED exige registrar un envío con número de seguimiento.
 *  - DELIVERED debe marcarse tras la confirmación del transportista.
 *  - Un pedido cobrado no se cancela directamente: se reembolsa.
 */
export const MANUAL_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  PENDING_PAYMENT: ['CANCELLED'],
  PAID: ['PREPARING'],
  PREPARING: ['SHIPPED'],
  SHIPPED: ['DELIVERED'],
  DELIVERED: [],
  CANCELLED: [],
  REFUNDED: []
};

export function canTransition(from: OrderStatus, to: OrderStatus): boolean {
  return MANUAL_TRANSITIONS[from].includes(to);
}

export function canRefund(status: OrderStatus, paymentStatus: PaymentStatus): boolean {
  return ['PAID', 'PREPARING', 'SHIPPED', 'DELIVERED'].includes(status) && ['SUCCEEDED', 'PARTIALLY_REFUNDED'].includes(paymentStatus);
}

/** Estados en los que el pedido cuenta como venta. */
export const SALE_STATUSES: OrderStatus[] = ['PAID', 'PREPARING', 'SHIPPED', 'DELIVERED'];

/** Utilidades de fecha en la zona horaria de la tienda (España peninsular). */
export const STORE_TZ = 'Europe/Madrid';

function tzOffsetMs(date: Date, tz: string): number {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit'
  }).formatToParts(date);
  const m = Object.fromEntries(parts.map((p) => [p.type, p.value]));
  return Date.UTC(+m.year, +m.month - 1, +m.day, +m.hour, +m.minute, +m.second) - Math.floor(date.getTime() / 1000) * 1000;
}

/** Inicio del día (00:00 hora de Madrid) que contiene `date`, como instante UTC. */
export function startOfDay(date = new Date(), tz = STORE_TZ): Date {
  const off = tzOffsetMs(date, tz);
  const local = new Date(date.getTime() + off);
  const midnightLocal = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate());
  return new Date(midnightLocal - tzOffsetMs(new Date(midnightLocal - off), tz));
}

export function startOfMonth(date = new Date(), tz = STORE_TZ): Date {
  const off = tzOffsetMs(date, tz);
  const local = new Date(date.getTime() + off);
  const firstLocal = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), 1);
  return new Date(firstLocal - tzOffsetMs(new Date(firstLocal - off), tz));
}

/** Clave AAAA-MM-DD del día en la zona de la tienda. */
export function dayKey(date: Date, tz = STORE_TZ): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(date);
}

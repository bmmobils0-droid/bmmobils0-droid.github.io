import { createHmac } from 'node:crypto';
import { hashToken, safeEqual } from './crypto';

/**
 * Token de acceso a un pedido sin cuenta (enlace del correo y de vuelta del pago).
 * Se deriva del id con la clave del servidor, así que no hace falta guardarlo en claro.
 */
export function orderAccessToken(orderId: string): string {
  const secret = process.env.SESSION_SECRET ?? '';
  return createHmac('sha256', secret).update(`order-access:${orderId}`).digest('base64url').slice(0, 32);
}

export function orderAccessHash(orderId: string): string {
  return hashToken(orderAccessToken(orderId));
}

export function verifyOrderAccess(orderId: string, token: string | undefined | null): boolean {
  if (!token) return false;
  return safeEqual(token, orderAccessToken(orderId));
}

import 'server-only';
import { db } from '@/lib/db';
import type { ProductInput } from '@/lib/validators';

export async function formOptions() {
  const [brands, categories] = await Promise.all([
    db.brand.findMany({ orderBy: { name: 'asc' }, select: { id: true, name: true } }),
    db.category.findMany({ orderBy: [{ position: 'asc' }, { name: 'asc' }], select: { id: true, name: true, parent: { select: { name: true } } } })
  ]);
  return { brands, categories: categories.map((c) => ({ id: c.id, name: c.name, parent: c.parent?.name ?? null })) };
}

const euros = (cents: number | null) => (cents == null ? '' : (cents / 100).toFixed(2).replace('.', ','));

export function productToForm(p: NonNullable<Awaited<ReturnType<typeof loadProduct>>>): ProductInput {
  return {
    name: p.name, slug: p.slug, model: p.model, brandId: p.brandId, categoryId: p.categoryId, condition: p.condition, status: p.status,
    featured: p.featured, isDemo: p.isDemo, description: p.description, conditionDetails: p.conditionDetails ?? '',
    specs: Array.isArray(p.specs) ? (p.specs as { label: string; value: string }[]) : [],
    warrantyMonths: p.warrantyMonths ?? '', warrantyText: p.warrantyText ?? '', taxRate: p.taxRate, seoTitle: p.seoTitle ?? '', seoDescription: p.seoDescription ?? '',
    variants: p.variants.map((v) => ({
      id: v.id, sku: v.sku, storageGb: v.storageGb ?? '', optionLabel: v.optionLabel ?? '', color: v.color ?? '', colorHex: v.colorHex ?? '',
      grade: v.grade ?? '', batteryHealth: v.batteryHealth ?? '', batteryCheckedAt: v.batteryCheckedAt ? v.batteryCheckedAt.toISOString().slice(0, 10) : '',
      price: euros(v.priceCents), compareAt: euros(v.compareAtCents), stock: v.stock, originalStock: v.stock, lowStockAt: v.lowStockAt, isActive: v.isActive
    }))
  };
}

export function loadProduct(id: string) {
  return db.product.findUnique({
    where: { id },
    include: {
      variants: { orderBy: [{ position: 'asc' }] },
      images: { orderBy: { position: 'asc' } },
      _count: { select: { reviews: true } }
    }
  });
}

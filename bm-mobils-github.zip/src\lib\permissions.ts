import type { Role } from '@/generated/prisma/enums';

/** Matriz de permisos por rol. Se comprueba siempre en el servidor. */
export const PERMISSIONS = {
  'admin:access': ['ADMIN', 'STAFF'],
  'products:write': ['ADMIN', 'STAFF'],
  'products:delete': ['ADMIN'],
  'orders:update': ['ADMIN', 'STAFF'],
  'orders:refund': ['ADMIN'],
  'customers:read': ['ADMIN', 'STAFF'],
  'customers:manage': ['ADMIN'],
  'settings:manage': ['ADMIN'],
  'content:manage': ['ADMIN'],
  'coupons:manage': ['ADMIN'],
  'messages:read': ['ADMIN', 'STAFF']
} as const satisfies Record<string, readonly Role[]>;

export type Permission = keyof typeof PERMISSIONS;

export function can(role: Role | null | undefined, permission: Permission): boolean {
  if (!role) return false;
  return (PERMISSIONS[permission] as readonly Role[]).includes(role);
}

export const ROLE_LABEL: Record<Role, string> = { ADMIN: 'Administrador', STAFF: 'Equipo', CUSTOMER: 'Cliente' };

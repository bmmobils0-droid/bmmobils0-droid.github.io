'use client';

import { useSyncExternalStore } from 'react';
import { Heart } from 'lucide-react';
import { cn } from '@/lib/cn';
import { useToast } from '../toast';

/**
 * Favoritos guardados en el navegador (localStorage), sin necesidad de cuenta.
 * Es almacenamiento técnico solicitado por el usuario, no requiere consentimiento.
 */
const KEY = 'bm:favs';
const EVENT = 'bm:favs-change';

function read(): string[] {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) ?? '[]');
    return Array.isArray(v) ? v.filter((x) => typeof x === 'string').slice(0, 200) : [];
  } catch {
    return [];
  }
}
let cache: { raw: string | null; list: string[] } = { raw: null, list: [] };
function snapshot(): string[] {
  let raw: string | null = null;
  try { raw = localStorage.getItem(KEY); } catch { /* sin almacenamiento */ }
  if (raw !== cache.raw) cache = { raw, list: read() };
  return cache.list;
}
const EMPTY: string[] = [];
function subscribe(cb: () => void) {
  window.addEventListener(EVENT, cb);
  window.addEventListener('storage', cb);
  return () => { window.removeEventListener(EVENT, cb); window.removeEventListener('storage', cb); };
}

export function useFavorites() {
  const list = useSyncExternalStore(subscribe, snapshot, () => EMPTY);
  const toggle = (slug: string) => {
    const cur = read();
    const next = cur.includes(slug) ? cur.filter((s) => s !== slug) : [...cur, slug];
    try { localStorage.setItem(KEY, JSON.stringify(next)); } catch { /* sin almacenamiento */ }
    window.dispatchEvent(new Event(EVENT));
    return next.includes(slug);
  };
  return { list, toggle, has: (slug: string) => list.includes(slug) };
}

export function FavoriteButton({ slug, name, large }: { slug: string; name: string; large?: boolean }) {
  const { has, toggle } = useFavorites();
  const { show } = useToast();
  const on = has(slug);
  return (
    <button
      type="button"
      aria-pressed={on}
      aria-label={on ? `Quitar ${name} de favoritos` : `Añadir ${name} a favoritos`}
      onClick={(e) => {
        e.preventDefault();
        const added = toggle(slug);
        show(added ? 'Añadido a favoritos' : 'Eliminado de favoritos', added ? { action: { label: 'Ver', href: '/favoritos' } } : undefined);
      }}
      className={cn(
        'grid place-items-center rounded-full transition hover:scale-105',
        large ? 'size-13 border border-line-strong bg-white' : 'size-9 bg-white/90 shadow-[0_1px_2px_rgb(16_24_40/.08)]',
        on && 'text-[#d92d50]',
        on && large && 'border-[#f3b8c4] bg-[#fff5f7]'
      )}
    >
      <Heart className={cn('size-5', on && 'fill-current')} aria-hidden />
    </button>
  );
}

export function FavoritesCount() {
  // En el servidor la lista es vacía (snapshot de servidor), así que no hay desajuste de hidratación.
  const { list } = useFavorites();
  if (list.length === 0) return null;
  return <span className="absolute top-0.5 right-0 grid h-[18px] min-w-[18px] place-items-center rounded-full border-2 border-white bg-brand px-1 text-[11px] font-bold text-white">{list.length}</span>;
}

import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { cache } from 'react';
import { db } from '@/lib/db';
import { renderLightMarkdown } from '@/lib/markdown';
import { Breadcrumbs } from '@/components/store/breadcrumbs';

type Props = { params: Promise<{ slug: string }> };
const getPage = cache((slug: string) => db.page.findUnique({ where: { slug } }));

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const page = await getPage((await params).slug);
  if (!page) return {};
  return { title: page.title, alternates: { canonical: `/info/${page.slug}` } };
}

export default async function InfoPage({ params }: Props) {
  const page = await getPage((await params).slug);
  if (!page) notFound();
  return (
    <div className="container-page pt-6">
      <Breadcrumbs items={[{ label: page.title }]} />
      <h1 className="mb-6 text-[28px] font-bold sm:text-4xl">{page.title}</h1>
      <article className="prose-bm" dangerouslySetInnerHTML={{ __html: renderLightMarkdown(page.content) }} />
      <p className="mt-10 text-[13px] text-muted">Última actualización: {page.updatedAt.toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
    </div>
  );
}

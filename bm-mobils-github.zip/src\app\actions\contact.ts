'use server';

import { db } from '@/lib/db';
import { clientIp, rateLimit } from '@/lib/rate-limit';
import { contactSchema, fieldErrors } from '@/lib/validators';

export type ContactState = { ok?: boolean; message?: string; errors?: Record<string, string> } | undefined;

export async function contactAction(_: ContactState, formData: FormData): Promise<ContactState> {
  const parsed = contactSchema.safeParse({
    name: formData.get('name'),
    email: formData.get('email'),
    orderNumber: formData.get('orderNumber') || undefined,
    message: formData.get('message'),
    acceptPrivacy: formData.get('acceptPrivacy') === 'on'
  });
  if (!parsed.success) return { errors: fieldErrors(parsed.error) };
  // Campo trampa para bots: invisible para personas.
  if (formData.get('website')) return { ok: true, message: 'Mensaje enviado. Te responderemos lo antes posible.' };
  if (!(await rateLimit(`contact:${await clientIp()}`, 5, 60 * 60_000))) return { message: 'Has enviado demasiados mensajes. Prueba más tarde.' };
  const { acceptPrivacy: _accepted, ...data } = parsed.data;
  void _accepted;
  await db.contactMessage.create({ data });
  return { ok: true, message: 'Mensaje enviado. Te responderemos lo antes posible.' };
}

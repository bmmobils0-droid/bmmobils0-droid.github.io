'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useId, useRef, useState } from 'react';
import { Search } from 'lucide-react';
import { formatPrice } from '@/lib/money';

type Suggestion = { slug: string; name: string; brand: string; priceCents: number; condition: string };

export function SearchBox() {
  const router = useRouter();
  const params = useSearchParams();
  const [q, setQ] = useState(params.get('q') ?? '');
  const [items, setItems] = useState<Suggestion[]>([]);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const listId = useId();
  const box = useRef<HTMLFormElement>(null);

  useEffect(() => {
    const term = q.trim();
    if (term.length < 2) return; // la lista solo se muestra con 2 o más caracteres
    const ctrl = new AbortController();
    const t = setTimeout(() => {
      fetch(`/api/search?q=${encodeURIComponent(term)}`, { signal: ctrl.signal })
        .then((r) => (r.ok ? r.json() : { items: [] }))
        .then((d: { items: Suggestion[] }) => { setItems(d.items); setActive(-1); })
        .catch(() => {});
    }, 150);
    return () => { clearTimeout(t); ctrl.abort(); };
  }, [q]);

  useEffect(() => {
    const close = (e: MouseEvent) => { if (!box.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  const go = (href: string) => { setOpen(false); router.push(href); };
  const showList = open && q.trim().length >= 2;

  return (
    <form
      ref={box}
      role="search"
      className="relative"
      onSubmit={(e) => {
        e.preventDefault();
        if (active >= 0 && items[active]) return go(`/producto/${items[active].slug}`);
        if (q.trim()) go(`/catalogo?q=${encodeURIComponent(q.trim())}`);
      }}
    >
      <Search className="pointer-events-none absolute top-1/2 left-4 size-5 -translate-y-1/2 text-muted" aria-hidden />
      <input
        type="search"
        value={q}
        onChange={(e) => { setQ(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        onKeyDown={(e) => {
          if (e.key === 'Escape') setOpen(false);
          if (!items.length) return;
          if (e.key === 'ArrowDown') { e.preventDefault(); setActive((a) => (a + 1) % items.length); }
          if (e.key === 'ArrowUp') { e.preventDefault(); setActive((a) => (a <= 0 ? items.length - 1 : a - 1)); }
        }}
        placeholder="Busca iPhone 15, Galaxy S25, fundas…"
        aria-label="Buscar productos"
        role="combobox"
        aria-expanded={showList}
        aria-controls={listId}
        aria-autocomplete="list"
        aria-activedescendant={active >= 0 ? `${listId}-${active}` : undefined}
        autoComplete="off"
        maxLength={80}
        className="h-[42px] w-full rounded-full border border-line bg-soft pr-4 pl-12 text-[15px] outline-none transition placeholder:text-[#8b909c] focus:border-ink focus:bg-white focus:ring-4 focus:ring-ink/5 md:h-[46px]"
      />
      {showList && (
        <div id={listId} role="listbox" className="absolute inset-x-0 top-[calc(100%+8px)] z-50 max-h-[70vh] overflow-auto rounded-card border border-line bg-white p-2 shadow-pop">
          {items.length === 0 ? (
            <p className="px-3 py-3 text-sm text-muted">Sin sugerencias. Pulsa Intro para buscar “{q.trim()}”.</p>
          ) : (
            <>
              {items.map((it, i) => (
                <button
                  key={it.slug}
                  id={`${listId}-${i}`}
                  type="button"
                  role="option"
                  aria-selected={i === active}
                  onClick={() => go(`/producto/${it.slug}`)}
                  className="flex w-full items-center gap-3 rounded-[10px] px-3 py-2.5 text-left hover:bg-soft aria-selected:bg-soft"
                >
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium">{it.name}</span>
                    <span className="block text-[13px] text-muted">{it.brand} · {it.condition}</span>
                  </span>
                  <span className="text-sm font-semibold whitespace-nowrap">{formatPrice(it.priceCents)}</span>
                </button>
              ))}
              <button type="submit" className="mt-1 block w-full border-t border-line px-3 pt-2.5 pb-1.5 text-left text-sm font-semibold text-brand">
                Ver todos los resultados
              </button>
            </>
          )}
        </div>
      )}
    </form>
  );
}

/**
 * Ilustraciones SVG de producto. Solo se usan cuando un producto no tiene fotos.
 * Los colores llegan validados (#RRGGBB); cualquier otro valor se sustituye por gris.
 */
export type ArtType = 'phone' | 'tablet' | 'case' | 'protector' | 'charger' | 'cable' | 'earbuds' | 'headphones' | 'watch';
export type ArtStyle = 'apple-pro' | 'apple' | 'samsung' | 'pixel' | 'xiaomi' | 'band';
export type ArtView = 'duo' | 'back' | 'front';
export type ArtOptions = { color?: string | null; style?: ArtStyle; view?: ArtView; label?: string; clear?: boolean };

// Ids deterministas (mismo resultado en servidor y cliente): dos dibujos idénticos comparten
// definiciones idénticas, así que una colisión de id no cambia el resultado.
function stableId(prefix: string, key: string): string {
  let h = 5381;
  for (let i = 0; i < key.length; i++) h = ((h << 5) + h + key.charCodeAt(i)) >>> 0;
  return prefix + h.toString(36);
}
const HEX = /^#[0-9a-fA-F]{6}$/;
const safeColor = (c?: string | null) => (c && HEX.test(c) ? c : '#D1D5DB');

function rgb(hex: string): [number, number, number] {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function mix(hex: string, amt: number): string {
  const t = amt < 0 ? 0 : 255;
  const p = Math.abs(amt);
  return '#' + rgb(hex).map((v) => Math.round(v + (t - v) * p).toString(16).padStart(2, '0')).join('');
}

function defs(id: string, color: string) {
  return `<linearGradient id="b${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${mix(color, 0.2)}"/><stop offset=".55" stop-color="${color}"/><stop offset="1" stop-color="${mix(color, -0.14)}"/></linearGradient>
<linearGradient id="w${id}" x1="0" y1="0" x2=".7" y2="1"><stop offset="0" stop-color="${mix(color, 0.15)}"/><stop offset="1" stop-color="${mix(color, -0.62)}"/></linearGradient>
<linearGradient id="m${id}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#b9bdc3"/><stop offset=".5" stop-color="#eef0f2"/><stop offset="1" stop-color="#a7acb3"/></linearGradient>
<radialGradient id="g${id}" cx=".25" cy=".15" r=".9"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset=".6" stop-color="#fff" stop-opacity="0"/></radialGradient>
<filter id="f${id}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="9"/></filter>`;
}

const wrap = (id: string, color: string, inner: string, vb = '0 0 400 400') =>
  `<svg viewBox="${vb}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><defs>${defs(id, color)}</defs>${inner}</svg>`;
const shadow = (id: string, cx: number, cy: number, rx: number) =>
  `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${rx * 0.09}" fill="#0b1220" opacity=".16" filter="url(#f${id})"/>`;

function lens(cx: number, cy: number, r: number, ring: string) {
  return `<circle cx="${cx}" cy="${cy}" r="${r + 2.6}" fill="${ring}"/><circle cx="${cx}" cy="${cy}" r="${r}" fill="#121519"/><circle cx="${cx}" cy="${cy}" r="${r * 0.55}" fill="#22304a"/><circle cx="${cx - r * 0.3}" cy="${cy - r * 0.3}" r="${r * 0.18}" fill="#fff" opacity=".5"/>`;
}

function cameras(x: number, y: number, w: number, h: number, color: string, style: ArtStyle) {
  const ring = mix(color, -0.3), mod = mix(color, -0.06), L = w * 0.085, flash = (cx: number, cy: number, r: number) => `<circle cx="${cx}" cy="${cy}" r="${r}" fill="#f5efe0" opacity=".9"/>`;
  switch (style) {
    case 'apple-pro':
      return `<rect x="${x + w * 0.07}" y="${y + w * 0.07}" width="${w * 0.52}" height="${w * 0.52}" rx="${w * 0.14}" fill="${mod}" stroke="${mix(color, -0.18)}"/>${lens(x + w * 0.21, y + w * 0.21, L, ring)}${lens(x + w * 0.21, y + w * 0.45, L, ring)}${lens(x + w * 0.45, y + w * 0.33, L, ring)}${flash(x + w * 0.45, y + w * 0.16, w * 0.03)}`;
    case 'apple':
      return `<rect x="${x + w * 0.07}" y="${y + w * 0.07}" width="${w * 0.27}" height="${w * 0.48}" rx="${w * 0.135}" fill="${mod}" stroke="${mix(color, -0.18)}"/>${lens(x + w * 0.205, y + w * 0.2, L, ring)}${lens(x + w * 0.205, y + w * 0.42, L, ring)}${flash(x + w * 0.42, y + w * 0.16, w * 0.028)}`;
    case 'pixel':
      return `<rect x="${x + w * 0.05}" y="${y + h * 0.09}" width="${w * 0.9}" height="${h * 0.1}" rx="${h * 0.05}" fill="#1b1e23"/>${lens(x + w * 0.26, y + h * 0.14, L * 0.8, '#2a2e35')}${lens(x + w * 0.46, y + h * 0.14, L * 0.8, '#2a2e35')}${flash(x + w * 0.66, y + h * 0.14, w * 0.028)}`;
    case 'xiaomi':
      return `<rect x="${x + w * 0.08}" y="${y + w * 0.08}" width="${w * 0.54}" height="${w * 0.54}" rx="${w * 0.16}" fill="${mix(color, -0.12)}"/>${lens(x + w * 0.22, y + w * 0.22, L, ring)}${lens(x + w * 0.48, y + w * 0.22, L, ring)}${lens(x + w * 0.22, y + w * 0.48, L, ring)}${flash(x + w * 0.48, y + w * 0.48, w * 0.04)}`;
    default:
      return `${lens(x + w * 0.2, y + w * 0.2, L, ring)}${lens(x + w * 0.2, y + w * 0.43, L, ring)}${lens(x + w * 0.2, y + w * 0.66, L, ring)}${flash(x + w * 0.4, y + w * 0.2, w * 0.028)}`;
  }
}

function phoneBack(id: string, x: number, y: number, w: number, h: number, color: string, style: ArtStyle) {
  const r = w * 0.17;
  return `<g><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="url(#b${id})" stroke="${mix(color, -0.24)}" stroke-width="1.5"/><rect x="${x + w - 1}" y="${y + h * 0.22}" width="3" height="${h * 0.12}" rx="1.5" fill="${mix(color, -0.3)}"/>${cameras(x, y, w, h, color, style)}<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="url(#g${id})" opacity=".55"/></g>`;
}

function phoneFront(id: string, x: number, y: number, w: number, h: number, color: string, style: ArtStyle) {
  const r = w * 0.17, b = w * 0.045, cx = x + w / 2, k = `c${id}_${Math.round(x)}`;
  const island = style.startsWith('apple')
    ? `<rect x="${cx - w * 0.15}" y="${y + b + h * 0.022}" width="${w * 0.3}" height="${h * 0.042}" rx="${h * 0.021}" fill="#05060a"/>`
    : `<circle cx="${cx}" cy="${y + b + h * 0.04}" r="${w * 0.032}" fill="#05060a"/>`;
  return `<g><clipPath id="${k}"><rect x="${x + b}" y="${y + b}" width="${w - 2 * b}" height="${h - 2 * b}" rx="${r - b}"/></clipPath>
<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="#111317" stroke="${mix(color, -0.1)}" stroke-width="2"/>
<g clip-path="url(#${k})"><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#w${id})"/><circle cx="${x + w * 0.85}" cy="${y + h * 0.28}" r="${w * 0.6}" fill="#fff" opacity=".13"/><circle cx="${x + w * 0.1}" cy="${y + h * 0.85}" r="${w * 0.55}" fill="#000" opacity=".16"/></g>
${island}<text x="${cx}" y="${y + h * 0.22}" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="${w * 0.21}" font-weight="600" fill="#fff" opacity=".93">9:41</text>
<rect x="${cx - w * 0.17}" y="${y + h - b - h * 0.03}" width="${w * 0.34}" height="${h * 0.012}" rx="${h * 0.006}" fill="#fff" opacity=".7"/></g>`;
}

function phone(id: string, color: string, style: ArtStyle, view: ArtView) {
  if (view === 'back') return shadow(id, 200, 362, 95) + phoneBack(id, 128, 40, 144, 300, color, style);
  if (view === 'front') return shadow(id, 200, 362, 95) + phoneFront(id, 128, 40, 144, 300, color, style);
  return shadow(id, 200, 368, 140) + `<g transform="rotate(-7 160 200)">${phoneBack(id, 92, 46, 136, 284, color, style)}</g><g transform="rotate(5 250 210)">${phoneFront(id, 184, 66, 136, 284, color, style)}</g>`;
}

function tablet(id: string, color: string, style: ArtStyle, view: ArtView) {
  const back = (x: number, y: number, w: number, h: number) => `<g><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="18" fill="url(#b${id})" stroke="${mix(color, -0.22)}" stroke-width="1.5"/>${
    style === 'samsung' ? lens(x + 22, y + 24, 7, mix(color, -0.3)) + lens(x + 22, y + 46, 7, mix(color, -0.3)) : `<rect x="${x + 12}" y="${y + 12}" width="24" height="24" rx="8" fill="${mix(color, -0.06)}"/>` + lens(x + 24, y + 24, 7, mix(color, -0.3))
  }<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="18" fill="url(#g${id})" opacity=".5"/></g>`;
  const front = (x: number, y: number, w: number, h: number) => {
    const k = `t${id}_${x}`;
    return `<g><clipPath id="${k}"><rect x="${x + 9}" y="${y + 9}" width="${w - 18}" height="${h - 18}" rx="10"/></clipPath><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="18" fill="#111317" stroke="${mix(color, -0.1)}" stroke-width="2"/><g clip-path="url(#${k})"><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#w${id})"/><circle cx="${x + w * 0.8}" cy="${y + h * 0.3}" r="${w * 0.55}" fill="#fff" opacity=".12"/></g><text x="${x + w / 2}" y="${y + h * 0.24}" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="34" font-weight="600" fill="#fff" opacity=".92">9:41</text></g>`;
  };
  if (view === 'back') return shadow(id, 200, 362, 120) + back(95, 40, 210, 296);
  if (view === 'front') return shadow(id, 200, 362, 120) + front(95, 40, 210, 296);
  return shadow(id, 200, 366, 150) + `<g transform="rotate(-5 150 200)">${back(52, 52, 196, 276)}</g><g transform="rotate(3 260 210)">${front(150, 72, 196, 276)}</g>`;
}

function phoneCase(id: string, color: string, style: ArtStyle, clear: boolean) {
  const x = 128, y = 40, w = 144, h = 300;
  const body = clear
    ? `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="30" fill="#e9f0f7" fill-opacity=".55" stroke="#b7c3cf" stroke-width="5"/>`
    : `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="30" fill="url(#b${id})" stroke="${mix(color, -0.2)}" stroke-width="4"/>`;
  const cut = style === 'samsung'
    ? `<rect x="${x + w * 0.11}" y="${y + w * 0.1}" width="${w * 0.18}" height="${w * 0.66}" rx="${w * 0.09}" fill="#1c1f24" opacity=".88"/>`
    : `<rect x="${x + w * 0.06}" y="${y + w * 0.06}" width="${style === 'apple-pro' ? w * 0.55 : w * 0.3}" height="${w * 0.55}" rx="${w * 0.14}" fill="#1c1f24" opacity=".88"/>`;
  return shadow(id, 200, 362, 95) + `<g transform="rotate(-6 200 190)">${body}${cut}<rect x="${x + w - 2}" y="${y + h * 0.22}" width="5" height="${h * 0.13}" rx="2.5" fill="${clear ? '#b7c3cf' : mix(color, -0.22)}"/>${clear ? '' : `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="30" fill="url(#g${id})" opacity=".45"/>`}</g>`;
}

function protector(id: string, color: string, style: ArtStyle) {
  return shadow(id, 200, 362, 100) + phoneFront(id, 118, 52, 140, 292, color, style) +
    `<g transform="rotate(7 220 190)"><rect x="160" y="34" width="140" height="292" rx="24" fill="#eef5fb" fill-opacity=".72" stroke="#c3d0dc" stroke-width="2"/><path d="M178 70 L230 40 M178 110 L290 46" stroke="#fff" stroke-width="7" stroke-linecap="round" opacity=".8"/></g>`;
}

function charger(id: string, color: string, label?: string) {
  const dark = rgb(color).reduce((a, v) => a + v, 0) < 300;
  const text = label ? label.replace(/[^0-9A-Za-z ]/g, '').slice(0, 6) : '';
  return shadow(id, 200, 340, 100) + `<rect x="168" y="70" width="16" height="64" rx="8" fill="url(#m${id})"/><rect x="216" y="70" width="16" height="64" rx="8" fill="url(#m${id})"/><rect x="140" y="122" width="120" height="22" rx="11" fill="${mix(color, -0.1)}"/><rect x="125" y="136" width="150" height="180" rx="30" fill="url(#b${id})" stroke="${mix(color, -0.16)}" stroke-width="1.5"/><rect x="125" y="136" width="150" height="180" rx="30" fill="url(#g${id})" opacity=".6"/><rect x="182" y="276" width="36" height="12" rx="6" fill="#26292e"/>${
    text ? `<text x="200" y="230" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="22" font-weight="600" fill="${dark ? '#fff' : '#8a9099'}" opacity=".7">${text}</text>` : ''}`;
}

function cable(id: string, color: string) {
  const edge = mix(color, -0.2), d = 'M126 128 C 110 300, 330 110, 286 288';
  return shadow(id, 200, 366, 120) + `<path d="${d}" fill="none" stroke="${edge}" stroke-width="13" stroke-linecap="round"/><path d="${d}" fill="none" stroke="${color}" stroke-width="10" stroke-linecap="round"/><rect x="114" y="44" width="24" height="28" rx="7" fill="url(#m${id})"/><rect x="108" y="66" width="36" height="70" rx="11" fill="${mix(color, -0.05)}" stroke="${edge}" stroke-width="1.5"/><rect x="274" y="280" width="36" height="70" rx="11" fill="${mix(color, -0.05)}" stroke="${edge}" stroke-width="1.5"/><rect x="280" y="344" width="24" height="26" rx="7" fill="url(#m${id})"/>`;
}

function earbuds(id: string, color: string) {
  const edge = mix(color, -0.18);
  const bud = (cx: number, flip: boolean) => `<g transform="rotate(${flip ? 12 : -12} ${cx} 140)"><rect x="${cx - 9}" y="128" width="18" height="78" rx="9" fill="url(#b${id})" stroke="${edge}"/><ellipse cx="${cx}" cy="120" rx="27" ry="30" fill="url(#b${id})" stroke="${edge}"/><ellipse cx="${cx + (flip ? -12 : 12)}" cy="114" rx="9" ry="11" fill="#30343a"/></g>`;
  return shadow(id, 200, 356, 110) + bud(160, false) + bud(240, true) + `<rect x="112" y="214" width="176" height="128" rx="54" fill="url(#b${id})" stroke="${edge}" stroke-width="1.5"/><path d="M116 256 H284" stroke="${edge}" stroke-width="1.5"/><rect x="112" y="214" width="176" height="128" rx="54" fill="url(#g${id})" opacity=".6"/><circle cx="200" cy="296" r="3.5" fill="#7a818b"/>`;
}

function headphones(id: string, color: string) {
  const edge = mix(color, -0.25), d = 'M118 236 C 112 92, 288 92, 282 236';
  return shadow(id, 200, 356, 130) + `<path d="${d}" fill="none" stroke="${edge}" stroke-width="22" stroke-linecap="round"/><path d="${d}" fill="none" stroke="${color}" stroke-width="17" stroke-linecap="round"/><rect x="86" y="200" width="70" height="128" rx="35" fill="url(#b${id})" stroke="${edge}" stroke-width="1.5"/><rect x="244" y="200" width="70" height="128" rx="35" fill="url(#b${id})" stroke="${edge}" stroke-width="1.5"/><rect x="136" y="214" width="22" height="100" rx="11" fill="${mix(color, -0.35)}"/><rect x="242" y="214" width="22" height="100" rx="11" fill="${mix(color, -0.35)}"/>`;
}

function watch(id: string, color: string, band: boolean) {
  const cw = band ? 92 : 150, ch = band ? 168 : 180, cx = 200 - cw / 2, cy = 110, bw = band ? 70 : 104, mid = cy + ch / 2 + 6, r = band ? 26 : 38;
  return shadow(id, 200, 372, 90) + `<rect x="${200 - bw / 2}" y="34" width="${bw}" height="110" rx="20" fill="url(#b${id})"/><rect x="${200 - bw / 2}" y="250" width="${bw}" height="112" rx="20" fill="url(#b${id})"/><rect x="${cx}" y="${cy}" width="${cw}" height="${ch}" rx="${band ? 40 : 44}" fill="#2b2e33" stroke="#4a4e55" stroke-width="2"/><rect x="${cx + 10}" y="${cy + 10}" width="${cw - 20}" height="${ch - 20}" rx="${band ? 32 : 34}" fill="#05060a"/><circle cx="200" cy="${mid}" r="${r}" fill="none" stroke="#2a2d33" stroke-width="7"/><circle cx="200" cy="${mid}" r="${r}" fill="none" stroke="${mix(color, 0.15)}" stroke-width="7" stroke-linecap="round" stroke-dasharray="${band ? 110 : 165} 400" transform="rotate(-90 200 ${mid})"/><text x="200" y="${cy + (band ? 42 : 46)}" text-anchor="middle" font-family="Inter, system-ui, sans-serif" font-size="${band ? 15 : 19}" font-weight="600" fill="#fff">10:09</text>`;
}

export function renderDeviceArt(type: ArtType, opts: ArtOptions = {}): string {
  const color = safeColor(opts.color);
  const style = opts.style ?? 'samsung';
  const view = opts.view ?? 'duo';
  const id = stableId('a', [type, color, style, view, opts.label ?? '', opts.clear ? 1 : 0].join('|'));
  let inner: string;
  switch (type) {
    case 'tablet': inner = tablet(id, color, style, view); break;
    case 'case': inner = phoneCase(id, color, style, !!opts.clear); break;
    case 'protector': inner = protector(id, color, style); break;
    case 'charger': inner = charger(id, color, opts.label); break;
    case 'cable': inner = cable(id, color); break;
    case 'earbuds': inner = earbuds(id, color); break;
    case 'headphones': inner = headphones(id, color); break;
    case 'watch': inner = watch(id, color, style === 'band'); break;
    default: inner = phone(id, color, style, view);
  }
  return wrap(id, color, inner);
}

/** Composición de tres móviles para la portada. */
export function renderHeroArt(): string {
  const id = 'hero';
  const phones: [string, string, ArtStyle][] = [[`${id}a`, '#D9733B', 'apple-pro'], [`${id}b`, '#4C5A8A', 'pixel'], [`${id}c`, '#DCDDDF', 'samsung']];
  const d = phones.map(([pid, c]) => defs(pid, c)).join('');
  return `<svg viewBox="0 0 560 460" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><defs>${d}<filter id="f${id}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="12"/></filter></defs>
<ellipse cx="280" cy="430" rx="230" ry="18" fill="#0b1220" opacity=".14" filter="url(#f${id})"/>
<g transform="rotate(-11 130 240)">${phoneBack(phones[0][0], 60, 80, 150, 312, phones[0][1], 'apple-pro')}</g>
<g transform="rotate(10 440 240)">${phoneBack(phones[2][0], 352, 84, 150, 312, phones[2][1], 'samsung')}</g>
${phoneFront(phones[1][0], 200, 40, 164, 344, phones[1][1], 'pixel')}</svg>`;
}

/** Deduce el tipo y estilo de ilustración a partir de categoría, marca y modelo. */
export function artFor(p: { categorySlug: string; brandSlug: string; model: string }): { type: ArtType; style: ArtStyle } {
  const typeByCategory: Record<string, ArtType> = {
    tablets: 'tablet', fundas: 'case', protectores: 'protector', cargadores: 'charger', cables: 'cable',
    auriculares: 'earbuds', smartwatches: 'watch'
  };
  const type = typeByCategory[p.categorySlug] ?? 'phone';
  const m = p.model.toLowerCase();
  let style: ArtStyle = 'samsung';
  if (p.brandSlug === 'apple') style = /pro/.test(m) ? 'apple-pro' : 'apple';
  else if (p.brandSlug === 'google') style = 'pixel';
  else if (p.brandSlug === 'xiaomi') style = /band/.test(m) ? 'band' : 'xiaomi';
  if (type === 'earbuds' && /diadema|wh-|over/.test(m)) return { type: 'headphones', style };
  return { type, style };
}

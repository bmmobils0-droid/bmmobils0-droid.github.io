import Link from 'next/link';
import type { Prisma } from '@/generated/prisma/client';
import { db } from '@/lib/db';
import { CONDITION_LABEL, STATUS_LABEL } from '@/lib/labels';
import { formatPrice } from '@/lib/money';
import { artFor } from '@/lib/device-art';
import { PageHeader, Table } from '@/components/admin/ui';
import { ProductVisual } from '@/components/device-art';
import { Badge } from '@/components/ui/badge';
import { ButtonLink } from '@/components/ui/button';

export const metadata = { title: 'Productos' };

const STATUS_TONE = { PUBLISHED: 'ok', DRAFT: 'gray', ARCHIVED: 'warn' } as const;

export default async function ProductsPage({ searchParams }: { searchParams: Promise<{ q?: string; estado?: string; demo?: string; pagina?: string }> }) {
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.pagina) || 1);
  const where: Prisma.ProductWhereInput = {
    ...(sp.estado && ['DRAFT', 'PUBLISHED', 'ARCHIVED'].includes(sp.estado) ? { status: sp.estado as 'DRAFT' } : { status: { not: 'ARCHIVED' } }),
    ...(sp.demo === '1' ? { isDemo: true } : {}),
    ...(sp.q ? { OR: [{ name: { contains: sp.q, mode: 'insensitive' } }, { model: { contains: sp.q, mode: 'insensitive' } }, { variants: { some: { sku: { contains: sp.q, mode: 'insensitive' } } } }] } : {})
  };
  const [total, products] = await Promise.all([
    db.product.count({ where }),
    db.product.findMany({
      where,
      orderBy: { updatedAt: 'desc' },
      skip: (page - 1) * 50,
      take: 50,
      include: {
        brand: { select: { name: true, slug: true } },
        category: { select: { name: true, slug: true } },
        images: { take: 1, orderBy: { position: 'asc' }, select: { url: true, alt: true } },
        variants: { select: { colorHex: true, isActive: true }, take: 1 },
        _count: { select: { variants: true } }
      }
    })
  ]);
  const tabs = [['', 'Activos'], ['PUBLISHED', 'Publicados'], ['DRAFT', 'Borradores'], ['ARCHIVED', 'Archivados']];

  return (
    <>
      <PageHeader title="Productos" subtitle={`${total} productos`} actions={<ButtonLink href="/admin/productos/nuevo" size="sm">Nuevo producto</ButtonLink>} />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {tabs.map(([v, label]) => (
          <Link key={v} href={v ? `/admin/productos?estado=${v}` : '/admin/productos'} className={`rounded-full px-3 py-1.5 text-sm font-medium ${(sp.estado ?? '') === v && !sp.demo ? 'bg-ink text-white' : 'bg-white text-ink-2 hover:text-ink'}`}>{label}</Link>
        ))}
        <Link href="/admin/productos?demo=1" className={`rounded-full px-3 py-1.5 text-sm font-medium ${sp.demo ? 'bg-ink text-white' : 'bg-white text-ink-2 hover:text-ink'}`}>Demostración</Link>
        <form className="ml-auto" role="search">
          {sp.estado && <input type="hidden" name="estado" value={sp.estado} />}
          <input name="q" defaultValue={sp.q} placeholder="Buscar nombre, modelo o SKU" aria-label="Buscar productos" className="h-9 w-64 rounded-full border border-line-strong bg-white px-3.5 text-sm outline-none focus:border-ink" />
        </form>
      </div>
      <Table>
        <thead><tr><th>Producto</th><th>Estado</th><th>Condición</th><th>Precio desde</th><th>Stock</th><th>Variantes</th></tr></thead>
        <tbody>
          {products.length === 0 && <tr><td colSpan={6} className="py-10 text-center text-muted">No hay productos con estos criterios.</td></tr>}
          {products.map((p) => (
            <tr key={p.id} className="hover:bg-soft/60">
              <td>
                <Link href={`/admin/productos/${p.id}`} className="flex items-center gap-3">
                  <span className="relative block size-11 flex-none overflow-hidden rounded-lg bg-tile">
                    <ProductVisual image={p.images[0]} art={{ ...artFor({ categorySlug: p.category.slug, brandSlug: p.brand.slug, model: p.model }), color: p.variants[0]?.colorHex ?? null }} view="back" alt="" sizes="44px" className="size-full" />
                  </span>
                  <span>
                    <span className="block font-semibold hover:underline">{p.name}</span>
                    <span className="text-xs text-muted">{p.brand.name} · {p.category.name}</span>
                  </span>
                </Link>
              </td>
              <td><span className="flex flex-wrap gap-1"><Badge tone={STATUS_TONE[p.status]}>{STATUS_LABEL[p.status]}</Badge>{p.isDemo && <Badge tone="dark">Demo</Badge>}{p.featured && <Badge tone="brand">Destacado</Badge>}</span></td>
              <td>{CONDITION_LABEL[p.condition]}</td>
              <td>{formatPrice(p.fromPriceCents)}{p.maxDiscountPct > 0 && <span className="ml-1 text-xs text-danger">−{p.maxDiscountPct}%</span>}</td>
              <td className={p.totalStock === 0 ? 'font-semibold text-danger' : ''}>{p.totalStock}</td>
              <td>{p._count.variants}</td>
            </tr>
          ))}
        </tbody>
      </Table>
      {total > 50 && (
        <div className="mt-4 flex justify-center gap-2 text-sm">
          {page > 1 && <Link href={`/admin/productos?${new URLSearchParams({ ...(sp.q ? { q: sp.q } : {}), ...(sp.estado ? { estado: sp.estado } : {}), pagina: String(page - 1) })}`} className="rounded-full bg-white px-3 py-1.5">Anterior</Link>}
          <span className="px-3 py-1.5 text-muted">Página {page} de {Math.ceil(total / 50)}</span>
          {page * 50 < total && <Link href={`/admin/productos?${new URLSearchParams({ ...(sp.q ? { q: sp.q } : {}), ...(sp.estado ? { estado: sp.estado } : {}), pagina: String(page + 1) })}`} className="rounded-full bg-white px-3 py-1.5">Siguiente</Link>}
        </div>
      )}
    </>
  );
}

import 'server-only';
import type { Prisma } from '@/generated/prisma/client';
import type { DeviceCondition } from '@/generated/prisma/enums';
import { db } from '../db';
import { artFor } from '../device-art';
import { CONDITION_FROM_SLUG, storageLabel } from '../labels';

export const PAGE_SIZE = 24;

export const SORTS = {
  recomendados: 'Recomendados',
  'precio-asc': 'Precio: de menor a mayor',
  'precio-desc': 'Precio: de mayor a menor',
  recientes: 'Más recientes',
  descuento: 'Mayor descuento'
} as const;
export type SortKey = keyof typeof SORTS;

export type Filters = {
  q: string;
  brands: string[];
  models: string[];
  storage: number[];
  colors: string[];
  conditions: DeviceCondition[];
  categories: string[];
  batteryMin: number | null;
  available: boolean;
  minCents: number | null;
  maxCents: number | null;
  sort: SortKey;
  page: number;
};

type Params = Record<string, string | string[] | undefined>;
const list = (v: string | string[] | undefined) => (Array.isArray(v) ? v : v ? [v] : []).flatMap((x) => x.split(',')).map((x) => x.trim()).filter(Boolean).slice(0, 30);
const num = (v: string | string[] | undefined) => {
  const n = Number(Array.isArray(v) ? v[0] : v);
  return Number.isFinite(n) && n >= 0 ? n : null;
};

export function parseFilters(sp: Params): Filters {
  const sort = (Array.isArray(sp.orden) ? sp.orden[0] : sp.orden) as SortKey;
  const min = num(sp.min);
  const max = num(sp.max);
  const battery = num(sp.bateria);
  return {
    q: (Array.isArray(sp.q) ? sp.q[0] : sp.q ?? '').trim().slice(0, 80),
    brands: list(sp.marca),
    models: list(sp.modelo),
    storage: list(sp.capacidad).map(Number).filter((n) => Number.isInteger(n) && n > 0),
    colors: list(sp.color),
    conditions: list(sp.estado).map((s) => CONDITION_FROM_SLUG[s]).filter(Boolean),
    categories: list(sp.categoria),
    batteryMin: battery != null && battery <= 100 ? battery : null,
    available: sp.disponible === '1',
    minCents: min != null ? Math.round(min * 100) : null,
    maxCents: max != null ? Math.round(max * 100) : null,
    sort: sort in SORTS ? sort : 'recomendados',
    page: Math.max(1, Math.min(500, Math.floor(num(sp.pagina) ?? 1)))
  };
}

export const PUBLIC_PRODUCT: Prisma.ProductWhereInput = { status: 'PUBLISHED' };

function searchWhere(q: string): Prisma.ProductWhereInput[] {
  return q
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 6)
    .map((term) => ({
      OR: [
        { name: { contains: term, mode: 'insensitive' } },
        { model: { contains: term, mode: 'insensitive' } },
        { brand: { name: { contains: term, mode: 'insensitive' } } },
        { variants: { some: { sku: { contains: term, mode: 'insensitive' } } } }
      ]
    }));
}

export function buildWhere(base: Prisma.ProductWhereInput, f: Filters): Prisma.ProductWhereInput {
  const variant: Prisma.ProductVariantWhereInput[] = [{ isActive: true }];
  if (f.storage.length) variant.push({ storageGb: { in: f.storage } });
  if (f.colors.length) variant.push({ color: { in: f.colors } });
  if (f.batteryMin != null) variant.push({ batteryHealth: { gte: f.batteryMin } });
  if (f.minCents != null) variant.push({ priceCents: { gte: f.minCents } });
  if (f.maxCents != null) variant.push({ priceCents: { lte: f.maxCents } });
  if (f.available) variant.push({ stock: { gt: 0 } });

  const and: Prisma.ProductWhereInput[] = [PUBLIC_PRODUCT, base, { variants: { some: { AND: variant } } }];
  if (f.brands.length) and.push({ brand: { slug: { in: f.brands } } });
  if (f.models.length) and.push({ model: { in: f.models } });
  if (f.conditions.length) and.push({ condition: { in: f.conditions } });
  if (f.categories.length) and.push({ category: { OR: [{ slug: { in: f.categories } }, { parent: { slug: { in: f.categories } } }] } });
  if (f.available) and.push({ isDemo: false });
  if (f.q) and.push(...searchWhere(f.q));
  return { AND: and };
}

const ORDER: Record<SortKey, Prisma.ProductOrderByWithRelationInput[]> = {
  recomendados: [{ featured: 'desc' }, { totalStock: 'desc' }, { publishedAt: 'desc' }],
  'precio-asc': [{ fromPriceCents: 'asc' }],
  'precio-desc': [{ fromPriceCents: 'desc' }],
  recientes: [{ publishedAt: 'desc' }],
  descuento: [{ maxDiscountPct: 'desc' }, { fromPriceCents: 'asc' }]
};

export const cardInclude = {
  brand: { select: { name: true, slug: true } },
  category: { select: { slug: true, name: true } },
  images: { orderBy: { position: 'asc' }, take: 1, select: { url: true, alt: true } },
  variants: {
    where: { isActive: true },
    orderBy: [{ priceCents: 'asc' }],
    select: { priceCents: true, compareAtCents: true, color: true, colorHex: true, storageGb: true, stock: true, grade: true }
  }
} satisfies Prisma.ProductInclude;

type CardSource = Prisma.ProductGetPayload<{ include: typeof cardInclude }>;

export function toCard(p: CardSource) {
  const cheapest = p.variants[0];
  const colors = [...new Map(p.variants.filter((v) => v.color).map((v) => [v.color, v.colorHex])).entries()].map(([name, hex]) => ({ name: name!, hex }));
  const storages = [...new Set(p.variants.map((v) => v.storageGb).filter((g): g is number => g != null))].sort((a, b) => a - b);
  return {
    id: p.id,
    slug: p.slug,
    name: p.name,
    brand: p.brand.name,
    condition: p.condition,
    isDemo: p.isDemo,
    isNewArrival: !!p.publishedAt && Date.now() - p.publishedAt.getTime() < 30 * 86400_000,
    priceCents: p.fromPriceCents,
    compareAtCents: cheapest?.compareAtCents ?? null,
    discountPct: p.maxDiscountPct,
    priceVaries: new Set(p.variants.map((v) => v.priceCents)).size > 1,
    inStock: p.totalStock > 0,
    lowStock: p.totalStock > 0 && p.totalStock <= 3,
    image: p.images[0] ?? null,
    colors,
    storageRange: storages.length ? [storageLabel(storages[0]), storages.length > 1 ? storageLabel(storages[storages.length - 1]) : null].filter(Boolean).join(' – ') : null,
    art: { ...artFor({ categorySlug: p.category.slug, brandSlug: p.brand.slug, model: p.model }), color: colors[0]?.hex ?? null }
  };
}
export type ProductCardData = ReturnType<typeof toCard>;

export async function listProducts(base: Prisma.ProductWhereInput, f: Filters) {
  const where = buildWhere(base, f);
  const [total, rows] = await Promise.all([
    db.product.count({ where }),
    db.product.findMany({ where, include: cardInclude, orderBy: [...ORDER[f.sort], { id: 'asc' }], skip: (f.page - 1) * PAGE_SIZE, take: PAGE_SIZE })
  ]);
  return { items: rows.map(toCard), total, page: f.page, pages: Math.max(1, Math.ceil(total / PAGE_SIZE)) };
}

/** Valores disponibles para los filtros, calculados sobre los productos publicados de la colección. */
export async function getFacets(base: Prisma.ProductWhereInput) {
  const products = await db.product.findMany({
    where: { AND: [PUBLIC_PRODUCT, base] },
    select: {
      model: true,
      condition: true,
      brand: { select: { slug: true, name: true } },
      category: { select: { slug: true, name: true } },
      variants: { where: { isActive: true }, select: { storageGb: true, color: true, colorHex: true, batteryHealth: true, priceCents: true } }
    }
  });
  const count = <K extends string>(map: Map<K, { label: string; count: number; hex?: string | null }>, key: K, label: string, hex?: string | null) => {
    const cur = map.get(key);
    map.set(key, { label, count: (cur?.count ?? 0) + 1, hex: cur?.hex ?? hex });
  };
  const brands = new Map<string, { label: string; count: number }>();
  const models = new Map<string, { label: string; count: number }>();
  const categories = new Map<string, { label: string; count: number }>();
  const conditions = new Map<DeviceCondition, { label: string; count: number }>();
  const storage = new Map<string, { label: string; count: number }>();
  const colors = new Map<string, { label: string; count: number; hex?: string | null }>();
  let hasBattery = false;
  let maxPrice = 0;
  for (const p of products) {
    count(brands, p.brand.slug, p.brand.name);
    count(models, p.model, p.model);
    count(categories, p.category.slug, p.category.name);
    count(conditions, p.condition, p.condition);
    new Set(p.variants.map((v) => v.storageGb).filter((g): g is number => g != null)).forEach((g) => count(storage, String(g), storageLabel(g)!));
    new Map(p.variants.filter((v) => v.color).map((v) => [v.color!, v.colorHex])).forEach((hex, c) => count(colors, c, c, hex));
    if (p.variants.some((v) => v.batteryHealth != null)) hasBattery = true;
    p.variants.forEach((v) => { maxPrice = Math.max(maxPrice, v.priceCents); });
  }
  const sorted = <T extends { count: number; label: string }>(m: Map<string, T>) => [...m.entries()].map(([value, v]) => ({ value, ...v })).sort((a, b) => b.count - a.count || a.label.localeCompare(b.label, 'es'));
  return {
    brands: sorted(brands),
    models: sorted(models),
    categories: sorted(categories),
    conditions: (['NEW', 'REFURBISHED', 'USED'] as DeviceCondition[]).filter((c) => conditions.has(c)).map((c) => ({ value: c, count: conditions.get(c)!.count })),
    storage: [...storage.entries()].map(([value, v]) => ({ value, ...v })).sort((a, b) => Number(a.value) - Number(b.value)),
    colors: sorted(colors),
    hasBattery,
    maxPriceCents: maxPrice
  };
}
export type Facets = Awaited<ReturnType<typeof getFacets>>;

export async function getProductBySlug(slug: string) {
  return db.product.findUnique({
    where: { slug },
    include: {
      brand: true,
      category: { include: { parent: true } },
      images: { orderBy: { position: 'asc' } },
      variants: { where: { isActive: true }, orderBy: [{ position: 'asc' }, { priceCents: 'asc' }] },
      reviews: { where: { status: 'APPROVED' }, orderBy: { createdAt: 'desc' }, take: 20, select: { id: true, rating: true, title: true, body: true, createdAt: true, verifiedPurchase: true } }
    }
  });
}

export async function getRelated(product: { id: string; categoryId: string; brandId: string; fromPriceCents: number }, take = 4) {
  const rows = await db.product.findMany({
    where: { AND: [PUBLIC_PRODUCT, { id: { not: product.id } }, { categoryId: product.categoryId }] },
    include: cardInclude,
    take: 24
  });
  return rows
    .sort((a, b) => Number(b.brandId === product.brandId) - Number(a.brandId === product.brandId) || Math.abs(a.fromPriceCents - product.fromPriceCents) - Math.abs(b.fromPriceCents - product.fromPriceCents))
    .slice(0, take)
    .map(toCard);
}

/** Accesorios que mencionan la familia del dispositivo (p. ej. "iPhone") más cargadores y cables universales. */
export async function getCompatibleAccessories(family: string, take = 4) {
  const rows = await db.product.findMany({
    where: {
      AND: [
        PUBLIC_PRODUCT,
        { category: { parent: { slug: 'accesorios' } } },
        { OR: [{ name: { contains: family, mode: 'insensitive' } }, { category: { slug: { in: ['cargadores', 'cables'] } } }] }
      ]
    },
    include: cardInclude,
    orderBy: [{ featured: 'desc' }, { totalStock: 'desc' }],
    take
  });
  return rows.map(toCard);
}

export async function getProductCards(where: Prisma.ProductWhereInput, orderBy: Prisma.ProductOrderByWithRelationInput[], take: number) {
  const rows = await db.product.findMany({ where: { AND: [PUBLIC_PRODUCT, where] }, include: cardInclude, orderBy, take });
  return rows.map(toCard);
}

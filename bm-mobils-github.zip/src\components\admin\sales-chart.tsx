import { formatPrice } from '@/lib/money';

/** Gráfico de barras SVG sin dependencias. Cada barra lleva su importe como título accesible. */
export function SalesChart({ data }: { data: { key: string; label: string; cents: number }[] }) {
  const max = Math.max(...data.map((d) => d.cents));
  const total = data.reduce((s, d) => s + d.cents, 0);
  if (max === 0) return <p className="py-10 text-center text-sm text-muted">Todavía no hay ventas cobradas en este periodo.</p>;
  const W = 600, H = 180, gap = 4, bw = (W - gap * (data.length - 1)) / data.length;
  return (
    <figure>
      <svg viewBox={`0 0 ${W} ${H + 22}`} className="w-full" role="img" aria-label={`Ventas diarias de los últimos 30 días. Total ${formatPrice(total)}.`}>
        <line x1="0" x2={W} y1={H} y2={H} stroke="var(--color-line)" />
        {data.map((d, i) => {
          const h = Math.max(d.cents > 0 ? 3 : 0, (d.cents / max) * (H - 10));
          return (
            <g key={d.key}>
              <rect x={i * (bw + gap)} y={H - h} width={bw} height={h} rx={3} fill="var(--color-brand)" opacity={d.cents ? 0.9 : 0}>
                <title>{`${d.label}: ${formatPrice(d.cents)}`}</title>
              </rect>
              {(i === 0 || i === data.length - 1 || i % 7 === 0) && <text x={i * (bw + gap) + bw / 2} y={H + 16} textAnchor="middle" fontSize="11" fill="var(--color-muted)">{d.label}</text>}
            </g>
          );
        })}
      </svg>
      <figcaption className="mt-2 text-sm text-muted">Total del periodo: <strong className="text-ink">{formatPrice(total)}</strong> · Día con más ventas: {formatPrice(max)}</figcaption>
    </figure>
  );
}

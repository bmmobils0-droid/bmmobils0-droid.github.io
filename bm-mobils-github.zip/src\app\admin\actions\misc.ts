'use server';

import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { adminAction, UserError, type ActionResult } from '@/lib/admin-action';
import { db } from '@/lib/db';
import { couponSchema } from '@/lib/validators';

// --- Clientes -----------------------------------------------------------------

export async function updateCustomerAction(fd: FormData): Promise<ActionResult> {
  return adminAction('customers:manage', async (user) => {
    const id = z.string().min(1).parse(fd.get('userId'));
    const role = z.enum(['ADMIN', 'STAFF', 'CUSTOMER']).parse(fd.get('role'));
    const disabled = fd.get('disabled') === 'on';
    if (id === user.id && (role !== 'ADMIN' || disabled)) throw new UserError('No puedes quitarte permisos ni desactivar tu propia cuenta.');
    if (role !== 'ADMIN' || disabled) {
      const admins = await db.user.count({ where: { role: 'ADMIN', disabled: false, id: { not: id } } });
      const target = await db.user.findUniqueOrThrow({ where: { id }, select: { role: true } });
      if (target.role === 'ADMIN' && admins === 0) throw new UserError('Debe quedar al menos un administrador activo.');
    }
    await db.user.update({ where: { id }, data: { role, disabled } });
    // Al desactivar o cambiar el rol se cierran sus sesiones abiertas.
    await db.session.deleteMany({ where: { userId: id } });
    revalidatePath(`/admin/clientes/${id}`);
    return { ok: true, message: 'Cuenta actualizada. Sus sesiones se han cerrado.' };
  });
}

// --- Cupones ------------------------------------------------------------------

export async function createCouponAction(fd: FormData): Promise<ActionResult> {
  return adminAction('coupons:manage', async () => {
    const parsed = couponSchema.safeParse(Object.fromEntries(fd.entries()));
    if (!parsed.success) throw new UserError(parsed.error.issues[0].message);
    const c = parsed.data;
    await db.coupon.create({
      data: {
        code: c.code, type: c.type, value: c.type === 'PERCENT' ? Math.round(c.value * 100) : Math.round(c.value * 100),
        minSubtotalCents: c.minSubtotal != null ? Math.round(c.minSubtotal * 100) : null, startsAt: c.startsAt, endsAt: c.endsAt, maxRedemptions: c.maxRedemptions
      }
    });
    revalidatePath('/admin/cupones');
    return { ok: true, message: `Cupón ${c.code} creado.` };
  });
}

export async function toggleCouponAction(fd: FormData): Promise<ActionResult> {
  return adminAction('coupons:manage', async () => {
    const id = z.string().min(1).parse(fd.get('couponId'));
    const op = fd.get('op');
    const coupon = await db.coupon.findUniqueOrThrow({ where: { id } });
    if (op === 'delete') {
      if (coupon.redemptions > 0) throw new UserError('Este cupón ya se ha usado: desactívalo en lugar de eliminarlo.');
      await db.coupon.delete({ where: { id } });
    } else {
      await db.coupon.update({ where: { id }, data: { active: !coupon.active } });
    }
    revalidatePath('/admin/cupones');
    return { ok: true, message: op === 'delete' ? 'Cupón eliminado.' : coupon.active ? 'Cupón desactivado.' : 'Cupón activado.' };
  });
}

// --- Mensajes -----------------------------------------------------------------

export async function toggleMessageAction(fd: FormData): Promise<ActionResult> {
  return adminAction('messages:read', async () => {
    const id = z.string().min(1).parse(fd.get('messageId'));
    const m = await db.contactMessage.findUniqueOrThrow({ where: { id } });
    await db.contactMessage.update({ where: { id }, data: { handled: !m.handled } });
    revalidatePath('/admin/mensajes');
    return { ok: true, message: m.handled ? 'Marcado como pendiente.' : 'Marcado como atendido.' };
  });
}

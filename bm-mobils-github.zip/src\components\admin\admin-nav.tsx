'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { FileText, LayoutDashboard, Mail, Package, Settings, ShoppingCart, Tag, Users } from 'lucide-react';
import { cn } from '@/lib/cn';

const ICONS = { dashboard: LayoutDashboard, products: Package, orders: ShoppingCart, customers: Users, coupons: Tag, pages: FileText, messages: Mail, settings: Settings };
export type NavItem = { href: string; label: string; icon: keyof typeof ICONS; badge?: number };

export function AdminNav({ items }: { items: NavItem[] }) {
  const pathname = usePathname();
  return (
    <nav aria-label="Panel" className="flex gap-1 overflow-x-auto lg:flex-col lg:overflow-visible">
      {items.map((it) => {
        const Icon = ICONS[it.icon];
        const active = it.href === '/admin' ? pathname === '/admin' : pathname.startsWith(it.href);
        return (
          <Link
            key={it.href}
            href={it.href}
            aria-current={active ? 'page' : undefined}
            className={cn('flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium whitespace-nowrap transition', active ? 'bg-white text-ink shadow-[0_1px_2px_rgb(16_24_40/.08)]' : 'text-ink-2 hover:bg-white/60 hover:text-ink')}
          >
            <Icon className="size-[18px]" aria-hidden />
            <span className="flex-1">{it.label}</span>
            {!!it.badge && <span className="rounded-full bg-brand px-1.5 text-[11px] font-bold text-white">{it.badge}</span>}
          </Link>
        );
      })}
    </nav>
  );
}

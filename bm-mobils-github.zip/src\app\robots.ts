import type { MetadataRoute } from 'next';
import { absoluteUrl } from '@/lib/site';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: '*', allow: '/', disallow: ['/admin', '/api/', '/cuenta', '/carrito', '/checkout', '/pedido/', '/favoritos'] }],
    sitemap: absoluteUrl('/sitemap.xml')
  };
}

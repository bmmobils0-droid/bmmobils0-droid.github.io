'use client';

import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';
import { CircleAlert, CircleCheck, X } from 'lucide-react';

type Toast = { id: number; message: string; tone: 'success' | 'error'; action?: { label: string; href: string } };
type Ctx = { show: (message: string, opts?: { tone?: Toast['tone']; action?: Toast['action'] }) => void };

const ToastContext = createContext<Ctx>({ show: () => {} });
export const useToast = () => useContext(ToastContext);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const dismiss = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  const show = useCallback<Ctx['show']>((message, opts) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, message, tone: opts?.tone ?? 'success', action: opts?.action }]);
    setTimeout(() => dismiss(id), opts?.tone === 'error' ? 6000 : 3500);
  }, [dismiss]);

  return (
    <ToastContext.Provider value={{ show }}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-5 z-[90] flex flex-col items-center gap-2 px-4" aria-live="polite" role="status">
        {toasts.map((t) => (
          <div key={t.id} className="pointer-events-auto flex w-full max-w-md animate-fade-in items-center gap-3 rounded-xl bg-ink px-4 py-3 text-sm text-white shadow-pop">
            {t.tone === 'success' ? <CircleCheck className="size-5 flex-none text-[#7ee2a8]" aria-hidden /> : <CircleAlert className="size-5 flex-none text-[#ff9b8f]" aria-hidden />}
            <span className="flex-1">{t.message}</span>
            {t.action && <a href={t.action.href} className="font-semibold underline underline-offset-2">{t.action.label}</a>}
            <button type="button" onClick={() => dismiss(t.id)} className="rounded p-1 text-white/70 hover:text-white" aria-label="Cerrar aviso">
              <X className="size-4" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

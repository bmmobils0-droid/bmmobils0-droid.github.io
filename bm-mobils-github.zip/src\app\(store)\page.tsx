import Link from 'next/link';
import Image from 'next/image';
import { Check, Headset, Lock, ShieldCheck, Truck } from 'lucide-react';
import { getProductCards } from '@/lib/catalog/queries';
import { getSettings } from '@/lib/settings';
import { renderDeviceArt, renderHeroArt } from '@/lib/device-art';
import { GRADE_DESCRIPTION, GRADE_LABEL } from '@/lib/labels';
import { ButtonLink } from '@/components/ui/button';
import { ProductGrid } from '@/components/store/product-card';
import { Section } from '@/components/store/section';

export const dynamic = 'force-dynamic';

const TRUST = [
  { Icon: Truck, title: 'Envíos a toda España', text: 'Coste de envío visible antes de pagar.' },
  { Icon: ShieldCheck, title: 'Garantía clara', text: 'Cada producto indica sus condiciones de garantía.' },
  { Icon: Lock, title: 'Pago seguro', text: 'Pago procesado por Stripe. No guardamos los datos de tu tarjeta.' },
  { Icon: Headset, title: 'Atención al cliente', text: 'Te ayudamos antes, durante y después de tu compra.' }
];

const CATEGORIES = [
  { href: '/iphone', title: 'iPhone', sub: 'Nuevos y reacondicionados', art: renderDeviceArt('phone', { color: '#D9733B', style: 'apple-pro', view: 'back' }) },
  { href: '/samsung', title: 'Samsung', sub: 'Galaxy S, A y Z', art: renderDeviceArt('phone', { color: '#9FB2C6', style: 'samsung', view: 'back' }) },
  { href: '/reacondicionados', title: 'Reacondicionados', sub: 'Clasificados por estado', art: renderDeviceArt('phone', { color: '#A9B79E', style: 'apple', view: 'back' }) },
  { href: '/segunda-mano', title: 'Segunda mano', sub: 'Al mejor precio', art: renderDeviceArt('phone', { color: '#4C5A8A', style: 'pixel', view: 'back' }) },
  { href: '/accesorios', title: 'Fundas y accesorios', sub: 'Fundas, cargadores y cables', art: renderDeviceArt('case', { color: '#B9A9D6', style: 'apple' }) },
  { href: '/tablets', title: 'Tablets y tecnología', sub: 'iPad, Galaxy Tab y más', art: renderDeviceArt('tablet', { color: '#A9C3DB', style: 'apple', view: 'front' }) }
];

export default async function HomePage() {
  const [settings, featured, deals, accessories] = await Promise.all([
    getSettings(),
    getProductCards({ featured: true, category: { slug: { in: ['moviles', 'tablets'] } } }, [{ totalStock: 'desc' }, { publishedAt: 'desc' }], 8),
    getProductCards({ maxDiscountPct: { gt: 0 } }, [{ maxDiscountPct: 'desc' }], 4),
    getProductCards({ category: { parent: { slug: { in: ['accesorios', 'audio-y-wearables'] } } } }, [{ featured: 'desc' }, { totalStock: 'desc' }], 4)
  ]);

  return (
    <>
      <section className="overflow-hidden bg-soft">
        <div className="container-page grid items-center gap-3 py-9 md:min-h-[540px] md:grid-cols-[1.05fr_1fr] md:gap-10 md:py-12">
          <div>
            <p className="mb-4 text-[13px] font-semibold tracking-[.08em] text-muted uppercase">Móviles · Tablets · Accesorios</p>
            <h1 className="max-w-[13ch] text-[38px] leading-[1.04] font-bold tracking-[-0.035em] sm:text-5xl lg:text-[64px]">{settings.heroTitle}</h1>
            <p className="mt-5 max-w-[46ch] text-base text-ink-2 sm:text-lg">{settings.heroSubtitle}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <ButtonLink href="/moviles" size="lg" className="flex-1 sm:flex-none">Comprar móviles</ButtonLink>
              <ButtonLink href="/ofertas" size="lg" variant="outline" className="flex-1 bg-transparent sm:flex-none">Ver ofertas</ButtonLink>
            </div>
            <ul className="mt-9 flex flex-wrap gap-x-6 gap-y-2 text-sm text-ink-2">
              <li className="inline-flex items-center gap-2"><Check className="size-[18px] text-ok" aria-hidden />Nuevos, reacondicionados y de segunda mano</li>
              <li className="inline-flex items-center gap-2"><Check className="size-[18px] text-ok" aria-hidden />Precios con IVA incluido</li>
            </ul>
          </div>
          <div className="relative mx-auto aspect-[560/460] w-full max-w-[460px] md:max-w-none">
            {settings.heroImageUrl ? (
              <Image src={settings.heroImageUrl} alt="" fill priority sizes="(min-width: 768px) 50vw, 100vw" className="object-contain" />
            ) : (
              <div className="art-box size-full animate-fade-in" dangerouslySetInnerHTML={{ __html: renderHeroArt() }} />
            )}
          </div>
        </div>
      </section>

      <div className="container-page">
        <section className="grid gap-2.5 pt-8 sm:grid-cols-2 sm:gap-4 lg:grid-cols-4" aria-label={`Por qué comprar en ${settings.storeName}`}>
          {TRUST.map(({ Icon, title, text }) => (
            <div key={title} className="flex gap-3.5 rounded-card border border-line p-5">
              <span className="grid size-[42px] flex-none place-items-center rounded-xl bg-soft"><Icon className="size-5" aria-hidden /></span>
              <div>
                <h2 className="text-[15px] font-semibold tracking-tight">{title}</h2>
                <p className="mt-0.5 text-[13.5px] text-muted">{text}</p>
              </div>
            </div>
          ))}
        </section>

        {settings.banners.length > 0 && (
          <section className="grid gap-4 pt-8 md:grid-cols-2" aria-label="Destacados">
            {settings.banners.map((b, i) => (
              <Link key={i} href={b.href} className="group relative flex min-h-[180px] flex-col justify-end overflow-hidden rounded-[20px] bg-ink p-7 text-white">
                {b.imageUrl && <Image src={b.imageUrl} alt="" fill sizes="(min-width: 768px) 50vw, 100vw" className="object-cover opacity-60 transition duration-500 group-hover:scale-105" />}
                <span className="relative text-2xl font-bold">{b.title}</span>
                {b.text && <span className="relative mt-1 text-white/80">{b.text}</span>}
              </Link>
            ))}
          </section>
        )}

        <Section id="h-cats" title="Compra por categoría">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 xl:grid-cols-6">
            {CATEGORIES.map((c) => (
              <Link key={c.href} href={c.href} className="group flex flex-col overflow-hidden rounded-card bg-tile p-4.5 pb-5 transition duration-300 hover:-translate-y-0.5 hover:bg-[#eceef1] hover:shadow-card">
                <div className="art-box -mx-1.5 -mt-1.5 mb-1.5 aspect-square transition duration-300 group-hover:scale-[1.04]" dangerouslySetInnerHTML={{ __html: c.art }} />
                <h3 className="text-base font-semibold tracking-tight">{c.title}</h3>
                <p className="mt-0.5 text-[13px] text-muted">{c.sub}</p>
              </Link>
            ))}
          </div>
        </Section>

        {featured.length > 0 && (
          <Section id="h-feat" title="Productos destacados" subtitle="Una selección de nuestro catálogo." link={{ href: '/moviles', label: 'Ver todos' }}>
            <ProductGrid items={featured} />
          </Section>
        )}

        <section className="pt-14 md:pt-[72px]">
          <div className="grid items-center gap-7 rounded-3xl bg-soft p-6 sm:p-10 lg:grid-cols-[1fr_1.3fr] lg:gap-12 lg:p-12">
            <div>
              <p className="mb-3 text-[13px] font-semibold tracking-[.08em] text-muted uppercase">Reacondicionados</p>
              <h2 className="text-[26px] font-bold sm:text-4xl">El mismo móvil, a un precio más bajo.</h2>
              <p className="mt-3.5 max-w-[44ch] text-base text-ink-2">Clasificamos cada reacondicionado según su estado estético para que sepas exactamente qué vas a recibir.</p>
              <ButtonLink href="/reacondicionados" className="mt-6">Ver reacondicionados</ButtonLink>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              {(['EXCELLENT', 'VERY_GOOD', 'GOOD'] as const).map((g, i) => (
                <div key={g} className="rounded-card border border-line bg-white p-5">
                  <div className="mb-3.5 flex gap-1" aria-hidden>
                    {[0, 1, 2].map((k) => <span key={k} className={`h-[5px] flex-1 rounded-full ${k < 3 - i ? 'bg-ok' : 'bg-line'}`} />)}
                  </div>
                  <h3 className="font-semibold">{GRADE_LABEL[g]}</h3>
                  <p className="mt-1 text-[13.5px] text-muted">{GRADE_DESCRIPTION[g]}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {deals.length > 0 && (
          <Section id="h-deals" title="Ofertas" subtitle="Precios rebajados respecto al precio de referencia." link={{ href: '/ofertas', label: 'Ver ofertas' }}>
            <ProductGrid items={deals} />
          </Section>
        )}

        {accessories.length > 0 && (
          <Section id="h-acc" title="Accesorios" subtitle="Completa tu dispositivo." link={{ href: '/accesorios', label: 'Ver accesorios' }}>
            <ProductGrid items={accessories} />
          </Section>
        )}

        <Section id="h-brands" title="Marcas">
          <div className="flex flex-wrap gap-3">
            {[['Apple', '/iphone'], ['Samsung', '/samsung'], ['Google', '/google'], ['Xiaomi', '/xiaomi']].map(([name, href]) => (
              <Link key={name} href={href} className="grid h-[76px] min-w-[140px] flex-1 place-items-center rounded-card border border-line text-xl font-bold tracking-tight text-ink-2 transition hover:border-ink hover:bg-soft hover:text-ink">{name}</Link>
            ))}
          </div>
        </Section>
      </div>
    </>
  );
}

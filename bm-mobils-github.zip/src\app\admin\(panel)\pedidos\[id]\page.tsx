import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requirePermission } from '@/lib/auth';
import { db } from '@/lib/db';
import { can } from '@/lib/permissions';
import { formatPrice, formatRate } from '@/lib/money';
import { canRefund, canTransition, ORDER_STATUS_LABEL } from '@/lib/order-status';
import { ZONE_LABEL } from '@/lib/geo';
import { addOrderNoteAction, addShipmentAction, changeOrderStatusAction, refundOrderAction } from '@/app/admin/actions/orders';
import { ActionForm } from '@/components/admin/action-form';
import { Card, Notice, OrderStatusBadge, PageHeader, PaymentStatusBadge } from '@/components/admin/ui';
import { ConfirmSubmit } from '@/components/confirm-dialog';
import { Button } from '@/components/ui/button';
import { Field, Input } from '@/components/ui/field';

export const metadata = { title: 'Pedido' };

export default async function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requirePermission('admin:access');
  const { id } = await params;
  const order = await db.order.findUnique({
    where: { id },
    include: {
      items: true,
      payments: { orderBy: { createdAt: 'desc' } },
      shipments: { orderBy: { shippedAt: 'desc' } },
      events: { orderBy: { createdAt: 'desc' } },
      user: { select: { id: true, name: true } }
    }
  });
  if (!order) notFound();
  const actorIds = [...new Set(order.events.map((e) => e.actorId).filter((a): a is string => !!a))];
  const actors = new Map((await db.user.findMany({ where: { id: { in: actorIds } }, select: { id: true, name: true } })).map((u) => [u.id, u.name]));
  const date = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Madrid' });
  const canUpdate = can(user.role, 'orders:update');
  const refundable = canRefund(order.status, order.paymentStatus) && can(user.role, 'orders:refund');
  const refunded = order.payments.reduce((s, p) => s + p.refundedCents, 0);

  return (
    <>
      <PageHeader
        title={`Pedido ${order.number}`}
        subtitle={<>Creado el {date.format(order.createdAt)}{order.paidAt && <> · Cobrado el {date.format(order.paidAt)}</>}</>}
        actions={<span className="flex items-center gap-2"><OrderStatusBadge status={order.status} /><PaymentStatusBadge status={order.paymentStatus} /></span>}
      />
      <div className="mb-4 space-y-2">
        {order.paymentStatus === 'REQUIRES_REVIEW' && <Notice tone="danger">El pago necesita revisión manual (importe distinto o pedido no pendiente). Consulta el historial y el panel de Stripe antes de enviar nada.</Notice>}
        {order.requiresTaxReview && <Notice>Envío a {ZONE_LABEL[order.shippingZone]}: régimen fiscal distinto (IGIC/IPSI). Revisa con tu asesor el tratamiento del IVA y contacta con el cliente antes de enviar.</Notice>}
        {order.status === 'PENDING_PAYMENT' && <Notice tone="info">Esperando la confirmación de Stripe. El stock está reservado hasta {order.reservationExpiresAt ? date.format(order.reservationExpiresAt) : '—'}. No envíes nada hasta que el pedido figure como pagado.</Notice>}
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
        <div className="space-y-4">
          <Card title="Productos">
            <ul className="divide-y divide-line text-sm">
              {order.items.map((i) => (
                <li key={i.id} className="flex justify-between gap-4 py-2.5">
                  <span>
                    {i.productId ? <Link href={`/admin/productos/${i.productId}`} className="font-semibold hover:underline">{i.productName}</Link> : <span className="font-semibold">{i.productName}</span>}
                    <span className="block text-xs text-muted">{i.variantLabel} · SKU {i.sku} · {formatPrice(i.unitPriceCents)} × {i.quantity} · IVA {formatRate(i.taxRate)}</span>
                  </span>
                  <span className="font-semibold">{formatPrice(i.lineTotalCents)}</span>
                </li>
              ))}
            </ul>
            <dl className="mt-3 space-y-1.5 border-t border-line pt-3 text-sm">
              <div className="flex justify-between"><dt className="text-muted">Subtotal</dt><dd>{formatPrice(order.subtotalCents)}</dd></div>
              {order.discountCents > 0 && <div className="flex justify-between"><dt className="text-muted">Descuento ({order.couponCode})</dt><dd>−{formatPrice(order.discountCents)}</dd></div>}
              <div className="flex justify-between"><dt className="text-muted">{order.shippingMethod}</dt><dd>{formatPrice(order.shippingCents)}</dd></div>
              <div className="flex justify-between text-base font-bold"><dt>Total</dt><dd>{formatPrice(order.totalCents)}</dd></div>
              <div className="flex justify-between text-xs text-muted"><dt>IVA incluido</dt><dd>{formatPrice(order.taxCents)}</dd></div>
              {refunded > 0 && <div className="flex justify-between text-danger"><dt>Reembolsado</dt><dd>−{formatPrice(refunded)}</dd></div>}
            </dl>
          </Card>

          {canUpdate && (
            <Card title="Gestión del pedido">
              <div className="space-y-5">
                <div className="flex flex-wrap gap-2">
                  {canTransition(order.status, 'PREPARING') && (
                    <ActionForm action={changeOrderStatusAction}><input type="hidden" name="orderId" value={order.id} /><input type="hidden" name="to" value="PREPARING" /><Button type="submit" size="sm">Marcar como “Preparando pedido”</Button></ActionForm>
                  )}
                  {canTransition(order.status, 'DELIVERED') && (
                    <ActionForm action={changeOrderStatusAction}>
                      <input type="hidden" name="orderId" value={order.id} /><input type="hidden" name="to" value="DELIVERED" />
                      <ConfirmSubmit variant="primary" title="¿Marcar como entregado?" description="Hazlo solo cuando el transportista haya confirmado la entrega. Se avisará al cliente." confirmLabel="Marcar entregado">Marcar como entregado</ConfirmSubmit>
                    </ActionForm>
                  )}
                  {canTransition(order.status, 'CANCELLED') && (
                    <ActionForm action={changeOrderStatusAction}>
                      <input type="hidden" name="orderId" value={order.id} /><input type="hidden" name="to" value="CANCELLED" />
                      <ConfirmSubmit title="¿Cancelar el pedido?" description="Se anulará el pago pendiente en Stripe y se liberará el stock reservado." confirmLabel="Cancelar pedido">Cancelar pedido</ConfirmSubmit>
                    </ActionForm>
                  )}
                  {order.status === 'DELIVERED' || order.status === 'CANCELLED' || order.status === 'REFUNDED' ? <p className="text-sm text-muted">Este pedido está cerrado ({ORDER_STATUS_LABEL[order.status]}).</p> : null}
                </div>

                {(order.status === 'PAID' || order.status === 'PREPARING') && (
                  <ActionForm action={addShipmentAction} className="grid gap-3 rounded-xl border border-line p-4 sm:grid-cols-3">
                    <input type="hidden" name="orderId" value={order.id} />
                    <p className="text-sm font-semibold sm:col-span-3">Registrar envío</p>
                    <Field label="Transportista" htmlFor="s-carrier"><Input id="s-carrier" name="carrier" className="h-10" placeholder="Correos, SEUR, MRW…" required /></Field>
                    <Field label="Nº de seguimiento" htmlFor="s-tracking"><Input id="s-tracking" name="trackingNumber" className="h-10" required /></Field>
                    <Field label="URL de seguimiento" htmlFor="s-url" optional><Input id="s-url" name="trackingUrl" type="url" className="h-10" /></Field>
                    <div className="sm:col-span-3"><Button type="submit" size="sm">Marcar como enviado y avisar al cliente</Button></div>
                  </ActionForm>
                )}

                {refundable && (
                  <ActionForm action={refundOrderAction} className="flex flex-wrap items-end gap-3 rounded-xl border border-line p-4">
                    <input type="hidden" name="orderId" value={order.id} />
                    <Field label="Importe a reembolsar (€)" htmlFor="r-amount" hint="Vacío = reembolso total." optional><Input id="r-amount" name="amount" inputMode="decimal" className="h-10 w-48" /></Field>
                    <ConfirmSubmit title="¿Solicitar el reembolso?" description="Se enviará la orden de reembolso a Stripe. Es irreversible. El estado del pedido cambiará cuando Stripe confirme el reembolso. Repón el stock manualmente si el producto vuelve al almacén." confirmLabel="Reembolsar">Reembolsar</ConfirmSubmit>
                  </ActionForm>
                )}
                {canRefund(order.status, order.paymentStatus) && !can(user.role, 'orders:refund') && <p className="text-xs text-muted">Solo un administrador puede emitir reembolsos.</p>}
              </div>
            </Card>
          )}

          <Card title="Historial">
            <ol className="space-y-3 text-sm">
              {order.events.map((e) => (
                <li key={e.id} className="border-l-2 border-line pl-3">
                  <p>{e.message}</p>
                  <p className="text-xs text-muted">{date.format(e.createdAt)} · {e.actorId ? actors.get(e.actorId) ?? 'Equipo' : 'Sistema'}</p>
                </li>
              ))}
            </ol>
            {canUpdate && (
              <ActionForm action={addOrderNoteAction} resetOnSuccess className="mt-4 flex gap-2">
                <input type="hidden" name="orderId" value={order.id} />
                <Input name="message" aria-label="Nota interna" placeholder="Añadir nota interna…" className="h-10" />
                <Button type="submit" size="sm" variant="outline">Añadir</Button>
              </ActionForm>
            )}
          </Card>
        </div>

        <div className="space-y-4">
          <Card title="Cliente">
            <dl className="space-y-1 text-sm">
              <dd className="font-semibold">{order.shipFirstName} {order.shipLastName}</dd>
              <dd><a href={`mailto:${order.email}`} className="text-brand hover:underline">{order.email}</a></dd>
              {order.phone && <dd>{order.phone}</dd>}
              {order.user && can(user.role, 'customers:read') && <dd><Link href={`/admin/clientes/${order.user.id}`} className="text-brand hover:underline">Ver ficha de cliente</Link></dd>}
            </dl>
          </Card>
          <Card title="Envío">
            <p className="text-sm">{order.shipLine1}{order.shipLine2 && `, ${order.shipLine2}`}<br />{order.shipPostalCode} {order.shipCity} ({order.shipProvince})<br />España · {ZONE_LABEL[order.shippingZone]}</p>
            <p className="mt-2 text-sm text-muted">{order.shippingMethod}</p>
            {order.shipments.map((s) => (
              <p key={s.id} className="mt-3 rounded-lg bg-soft p-2.5 text-sm"><strong>{s.carrier}</strong> · {s.trackingNumber}{s.trackingUrl && <> · <a href={s.trackingUrl} target="_blank" rel="noopener noreferrer" className="text-brand underline">seguimiento</a></>}<br /><span className="text-xs text-muted">Enviado el {date.format(s.shippedAt)}{s.deliveredAt && ` · Entregado el ${date.format(s.deliveredAt)}`}</span></p>
            ))}
          </Card>
          {order.billingName && (
            <Card title="Facturación">
              <p className="text-sm">{order.billingName}<br />NIF/CIF: {order.billingTaxId}<br />{order.billingLine1}<br />{order.billingPostalCode} {order.billingCity} {order.billingProvince && `(${order.billingProvince})`}</p>
            </Card>
          )}
          {order.customerNote && <Card title="Nota del cliente"><p className="text-sm whitespace-pre-line">{order.customerNote}</p></Card>}
          <Card title="Pagos">
            {order.payments.length === 0 ? <p className="text-sm text-muted">Sin pagos confirmados.</p> : (
              <ul className="space-y-2 text-sm">
                {order.payments.map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-2"><span><PaymentStatusBadge status={p.status} /> <span className="text-xs text-muted">{p.provider}</span></span><span>{formatPrice(p.amountCents)}</span></li>
                ))}
              </ul>
            )}
            {order.stripePaymentIntentId && <p className="mt-2 truncate font-mono text-xs text-muted" title={order.stripePaymentIntentId}>{order.stripePaymentIntentId}</p>}
          </Card>
        </div>
      </div>
    </>
  );
}

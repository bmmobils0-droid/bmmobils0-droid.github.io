'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState, useTransition } from 'react';
import { Minus, Plus, Tag, Trash2, X } from 'lucide-react';
import { applyCouponAction, removeCouponAction, updateCartItemAction } from '@/app/actions/cart';
import { formatPrice } from '@/lib/money';
import { cn } from '@/lib/cn';
import type { ArtSpec } from '../device-art';
import { ProductVisual } from '../device-art';
import { useToast } from '../toast';

export type CartLineView = {
  itemId: string; slug: string; name: string; label: string; quantity: number; available: number; unitPriceCents: number; lineTotalCents: number;
  image: { url: string; alt: string } | null; art: ArtSpec; issue: 'unavailable' | 'demo' | 'insufficient' | null;
};

const ISSUE_TEXT = {
  unavailable: 'Este producto ya no está disponible. Elimínalo para continuar.',
  demo: 'Producto de demostración: no se puede comprar.',
  insufficient: 'No hay suficientes unidades. Reduce la cantidad.'
};

export function CartLines({ lines }: { lines: CartLineView[] }) {
  const router = useRouter();
  const { show } = useToast();
  const [pending, start] = useTransition();
  const update = (itemId: string, qty: number) =>
    start(async () => {
      const res = await updateCartItemAction(itemId, qty);
      if (!res.ok || qty === 0 || res.message.startsWith('Solo')) show(res.message, { tone: res.ok ? 'success' : 'error' });
      router.refresh();
    });

  return (
    <ul className={cn('divide-y divide-line', pending && 'opacity-60')} aria-busy={pending}>
      {lines.map((l) => (
        <li key={l.itemId} className="grid grid-cols-[88px_1fr] gap-4 py-5">
          <Link href={`/producto/${l.slug}`} tabIndex={-1} aria-hidden className="relative block size-[88px] overflow-hidden rounded-xl bg-tile">
            <ProductVisual image={l.image} art={l.art} view={l.art.type === 'phone' ? 'back' : undefined} alt="" sizes="88px" className="size-full" />
          </Link>
          <div className="min-w-0">
            <div className="flex justify-between gap-3">
              <Link href={`/producto/${l.slug}`} className="leading-snug font-semibold hover:underline">{l.name}</Link>
              <span className="font-semibold whitespace-nowrap">{formatPrice(l.lineTotalCents)}</span>
            </div>
            <p className="mt-0.5 text-[13px] text-muted">{l.label}{l.quantity > 1 && ` · ${formatPrice(l.unitPriceCents)}/ud.`}</p>
            {l.issue && <p className="mt-1.5 text-[13px] font-medium text-danger" role="alert">{ISSUE_TEXT[l.issue]}{l.issue === 'insufficient' && ` Disponibles: ${l.available}.`}</p>}
            <div className="mt-3 flex items-center justify-between">
              <div className="inline-flex h-9 items-center rounded-full border border-line-strong px-0.5" role="group" aria-label={`Cantidad de ${l.name}`}>
                <button type="button" className="grid size-8 place-items-center rounded-full hover:bg-soft disabled:opacity-35" disabled={pending} onClick={() => update(l.itemId, l.quantity - 1)} aria-label="Quitar una unidad"><Minus className="size-3.5" /></button>
                <output className="min-w-7 text-center text-sm font-semibold">{l.quantity}</output>
                <button type="button" className="grid size-8 place-items-center rounded-full hover:bg-soft disabled:opacity-35" disabled={pending || l.quantity >= Math.min(l.available, 10)} onClick={() => update(l.itemId, l.quantity + 1)} aria-label="Añadir una unidad"><Plus className="size-3.5" /></button>
              </div>
              <button type="button" disabled={pending} onClick={() => update(l.itemId, 0)} className="inline-flex items-center gap-1 rounded-md p-1 text-[13px] text-muted hover:text-danger">
                <Trash2 className="size-3.5" aria-hidden />Eliminar
              </button>
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}

export function CouponForm({ code }: { code: string | null }) {
  const router = useRouter();
  const { show } = useToast();
  const [value, setValue] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  if (code) {
    return (
      <div className="flex items-center justify-between rounded-xl bg-ok-soft px-3.5 py-2.5 text-sm text-ok">
        <span className="inline-flex items-center gap-2 font-semibold"><Tag className="size-4" aria-hidden />{code}</span>
        <button type="button" disabled={pending} onClick={() => start(async () => { const r = await removeCouponAction(); show(r.message); router.refresh(); })} className="rounded p-1 hover:bg-white/60" aria-label="Quitar cupón"><X className="size-4" /></button>
      </div>
    );
  }
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          const r = await applyCouponAction(value);
          setError(r.ok ? null : r.message);
          if (r.ok) { show(r.message); setValue(''); router.refresh(); }
        });
      }}
    >
      <label htmlFor="coupon" className="text-[13px] font-medium text-ink-2">Cupón de descuento</label>
      <div className="mt-1.5 flex gap-2">
        <input id="coupon" value={value} onChange={(e) => setValue(e.target.value.toUpperCase())} maxLength={30} aria-invalid={!!error} aria-describedby={error ? 'coupon-error' : undefined} className="h-10 min-w-0 flex-1 rounded-[10px] border border-line-strong bg-white px-3 text-sm uppercase outline-none focus:border-ink" />
        <button type="submit" disabled={pending || !value.trim()} className="h-10 rounded-full border border-line-strong bg-white px-4 text-sm font-semibold hover:border-ink disabled:opacity-45">Aplicar</button>
      </div>
      {error && <p id="coupon-error" className="mt-1.5 text-[12.5px] text-danger" role="alert">{error}</p>}
    </form>
  );
}

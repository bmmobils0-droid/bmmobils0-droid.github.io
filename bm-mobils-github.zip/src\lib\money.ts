const eur = new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR', useGrouping: 'always' });

/** 123456 -> "1.234,56 €" */
export function formatPrice(cents: number): string {
  return eur.format(cents / 100);
}

/** Convierte euros introducidos por una persona (12,5 o 12.50) a céntimos. */
export function eurosToCents(euros: number): number {
  return Math.round(euros * 100);
}

export function centsToEuros(cents: number): number {
  return cents / 100;
}

/** IVA contenido en un importe con IVA incluido. rateBp: 2100 = 21 %. */
export function taxIncluded(grossCents: number, rateBp: number): number {
  if (rateBp <= 0) return 0;
  return Math.round(grossCents - (grossCents * 10000) / (10000 + rateBp));
}

export function discountPct(priceCents: number, compareAtCents: number | null | undefined): number {
  if (!compareAtCents || compareAtCents <= priceCents) return 0;
  return Math.round((1 - priceCents / compareAtCents) * 100);
}

export function formatRate(rateBp: number): string {
  return `${(rateBp / 100).toLocaleString('es-ES')} %`;
}

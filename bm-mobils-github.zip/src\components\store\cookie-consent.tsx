'use client';

import Link from 'next/link';
import { useEffect, useState, useSyncExternalStore } from 'react';
import { Button } from '../ui/button';

/**
 * Consentimiento de cookies. La web solo usa cookies técnicas, que no requieren consentimiento.
 * Si en el futuro se añade analítica o publicidad, se debe cargar únicamente cuando
 * `hasConsent('analytics')` / `hasConsent('marketing')` sea true (ver <ConsentGate>).
 */
type Consent = { analytics: boolean; marketing: boolean; date: string };
const COOKIE = 'bm_consent';
const OPEN_EVENT = 'bm:open-cookie-settings';

function readConsent(): Consent | null {
  const raw = document.cookie.split('; ').find((c) => c.startsWith(`${COOKIE}=`))?.slice(COOKIE.length + 1);
  if (!raw) return null;
  try { return JSON.parse(decodeURIComponent(raw)) as Consent; } catch { return null; }
}
function saveConsent(c: Omit<Consent, 'date'>) {
  const value = encodeURIComponent(JSON.stringify({ ...c, date: new Date().toISOString() }));
  document.cookie = `${COOKIE}=${value}; Max-Age=${180 * 86400}; Path=/; SameSite=Lax${location.protocol === 'https:' ? '; Secure' : ''}`;
  window.dispatchEvent(new Event('bm:consent-change'));
}

export function hasConsent(kind: 'analytics' | 'marketing'): boolean {
  return typeof document !== 'undefined' && !!readConsent()?.[kind];
}

const subscribe = (cb: () => void) => {
  window.addEventListener('bm:consent-change', cb);
  return () => window.removeEventListener('bm:consent-change', cb);
};
// En el servidor se considera "ya decidido" para no pintar el aviso antes de hidratar.
const hasDecision = () => readConsent() !== null;

export function CookieConsent() {
  const decided = useSyncExternalStore(subscribe, hasDecision, () => true);
  const [reopened, setReopened] = useState(false);
  const [custom, setCustom] = useState(false);
  const [analytics, setAnalytics] = useState(false);
  const [marketing, setMarketing] = useState(false);

  useEffect(() => {
    const reopen = () => {
      const cur = readConsent();
      setAnalytics(!!cur?.analytics);
      setMarketing(!!cur?.marketing);
      setCustom(true);
      setReopened(true);
    };
    window.addEventListener(OPEN_EVENT, reopen);
    return () => window.removeEventListener(OPEN_EVENT, reopen);
  }, []);

  if (decided && !reopened) return null;
  const decide = (c: { analytics: boolean; marketing: boolean }) => { saveConsent(c); setReopened(false); };

  return (
    <div role="dialog" aria-modal="false" aria-labelledby="cookie-title" className="fixed inset-x-3 bottom-3 z-[80] mx-auto max-w-2xl animate-fade-in rounded-2xl border border-line bg-white p-5 shadow-pop sm:inset-x-6 sm:bottom-6">
      <h2 id="cookie-title" className="text-base font-semibold">Tu privacidad</h2>
      <p className="mt-1.5 text-sm text-ink-2">
        Usamos cookies técnicas necesarias para que la tienda funcione (sesión, carrito y esta preferencia). No usamos cookies de analítica ni publicidad sin tu permiso.{' '}
        <Link href="/info/cookies" className="text-brand underline">Política de cookies</Link>
      </p>
      {custom && (
        <div className="mt-4 space-y-3 rounded-xl bg-soft p-4 text-sm">
          <label className="flex items-start gap-3"><input type="checkbox" checked disabled className="mt-0.5 size-4 accent-ink" /><span><strong>Técnicas</strong> — siempre activas, necesarias para el funcionamiento.</span></label>
          <label className="flex items-start gap-3"><input type="checkbox" checked={analytics} onChange={(e) => setAnalytics(e.target.checked)} className="mt-0.5 size-4 accent-ink" /><span><strong>Analítica</strong> — medir el uso de la web de forma agregada.</span></label>
          <label className="flex items-start gap-3"><input type="checkbox" checked={marketing} onChange={(e) => setMarketing(e.target.checked)} className="mt-0.5 size-4 accent-ink" /><span><strong>Publicidad</strong> — mostrar anuncios relevantes en otras webs.</span></label>
        </div>
      )}
      <div className="mt-4 flex flex-wrap gap-2">
        <Button size="sm" variant="outline" onClick={() => decide({ analytics: false, marketing: false })}>Rechazar opcionales</Button>
        {custom ? (
          <Button size="sm" variant="outline" onClick={() => decide({ analytics, marketing })}>Guardar selección</Button>
        ) : (
          <Button size="sm" variant="outline" onClick={() => setCustom(true)}>Configurar</Button>
        )}
        <Button size="sm" variant="primary" onClick={() => decide({ analytics: true, marketing: true })}>Aceptar todas</Button>
      </div>
    </div>
  );
}

export function CookieSettingsLink() {
  return (
    <button type="button" onClick={() => window.dispatchEvent(new Event(OPEN_EVENT))} className="text-ink-2 hover:text-ink hover:underline">
      Configurar cookies
    </button>
  );
}

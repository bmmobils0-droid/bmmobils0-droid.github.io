import { NextResponse, type NextRequest } from 'next/server';

/**
 * Primera barrera para rutas privadas: sin cookie de sesión se redirige al login.
 * La comprobación real (sesión válida y permisos del rol) se hace en el servidor
 * en cada página y server action del panel (src/lib/auth.ts).
 */
export function proxy(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  const hasSession = req.cookies.has('bm_session');

  if (pathname.startsWith('/admin') && pathname !== '/admin/login' && !hasSession) {
    return NextResponse.redirect(new URL('/admin/login', req.url));
  }
  if (pathname === '/cuenta' && !hasSession) {
    const url = new URL('/cuenta/acceso', req.url);
    url.searchParams.set('next', pathname + search);
    return NextResponse.redirect(url);
  }
  const res = NextResponse.next();
  if (pathname.startsWith('/admin')) res.headers.set('X-Robots-Tag', 'noindex, nofollow');
  return res;
}

export const config = { matcher: ['/admin/:path*', '/cuenta'] };

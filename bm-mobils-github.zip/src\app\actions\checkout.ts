'use server';

import { getCurrentUser } from '@/lib/auth';
import { getCart } from '@/lib/cart';
import { CheckoutError, cancelPendingOrder, createOrderAndCheckout, releaseExpiredReservations } from '@/lib/orders';
import { clientIp, rateLimit } from '@/lib/rate-limit';
import { checkoutSchema, fieldErrors } from '@/lib/validators';

export type CheckoutResult = { ok: true; url: string } | { ok: false; message: string; fieldErrors?: Record<string, string> };

export async function checkoutAction(raw: unknown): Promise<CheckoutResult> {
  const parsed = checkoutSchema.safeParse(raw);
  if (!parsed.success) return { ok: false, message: 'Revisa los campos marcados.', fieldErrors: fieldErrors(parsed.error) };
  if (!(await rateLimit(`checkout:${await clientIp()}`, 10, 10 * 60_000))) {
    return { ok: false, message: 'Demasiados intentos de pago. Espera unos minutos.' };
  }
  await releaseExpiredReservations(10).catch(() => 0);
  const user = await getCurrentUser();
  try {
    const { url } = await createOrderAndCheckout(parsed.data, user?.id ?? null);
    return { ok: true, url };
  } catch (err) {
    if (err instanceof CheckoutError) return { ok: false, message: err.message };
    console.error('[checkout]', err);
    return { ok: false, message: 'No hemos podido procesar tu pedido. Inténtalo de nuevo.' };
  }
}

/** Al volver de Stripe sin pagar: libera la reserva del pedido pendiente de este carrito. */
export async function cancelPendingCheckoutAction(): Promise<void> {
  const cart = await getCart();
  if (cart?.pendingOrderId) await cancelPendingOrder(cart.pendingOrderId, 'El cliente volvió de la pasarela sin completar el pago.').catch(() => false);
}

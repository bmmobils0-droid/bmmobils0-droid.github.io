'use client';

import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { createContext, useContext, useTransition, type ReactNode } from 'react';
import { cn } from '@/lib/cn';

type Ctx = { pending: boolean; setParams: (mutate: (p: URLSearchParams) => void) => void };
const CatalogContext = createContext<Ctx>({ pending: false, setParams: () => {} });
export const useCatalog = () => useContext(CatalogContext);

/** Coordina filtros, orden y resultados: cambia la URL y muestra estado de carga mientras llega la respuesta. */
export function CatalogShell({ children }: { children: ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [pending, start] = useTransition();
  const setParams: Ctx['setParams'] = (mutate) => {
    const next = new URLSearchParams(params.toString());
    mutate(next);
    next.delete('pagina');
    const qs = next.toString();
    start(() => router.push(qs ? `${pathname}?${qs}` : pathname, { scroll: false }));
  };
  return <CatalogContext.Provider value={{ pending, setParams }}>{children}</CatalogContext.Provider>;
}

export function CatalogResults({ children }: { children: ReactNode }) {
  const { pending } = useCatalog();
  return (
    <div aria-busy={pending} className={cn('transition-opacity duration-200', pending && 'pointer-events-none opacity-50')}>
      {children}
    </div>
  );
}

import { describe, expect, it } from 'vitest';
import { computeTotals, couponDiscount, shippingCost, validateCoupon, type CouponRule } from '@/lib/pricing';
import { discountPct, formatPrice, taxIncluded } from '@/lib/money';

const coupon = (over: Partial<CouponRule> = {}): CouponRule => ({
  code: 'BM10', type: 'PERCENT', value: 1000, minSubtotalCents: null, startsAt: null, endsAt: null, maxRedemptions: null, redemptions: 0, active: true, ...over
});

describe('money', () => {
  it('formatea en euros con formato español', () => {
    // Intl separa el símbolo con un espacio no separable (U+00A0).
    expect(formatPrice(115800)).toBe('1.158,00 €');
    expect(formatPrice(995)).toBe('9,95 €');
  });
  it('extrae el IVA incluido', () => {
    expect(taxIncluded(12100, 2100)).toBe(2100);
    expect(taxIncluded(1000, 0)).toBe(0);
  });
  it('calcula el descuento solo si el precio anterior es mayor', () => {
    expect(discountPct(800, 1000)).toBe(20);
    expect(discountPct(1000, 1000)).toBe(0);
    expect(discountPct(1000, null)).toBe(0);
  });
});

describe('cupones', () => {
  const now = new Date('2026-06-15T12:00:00Z');
  it('rechaza cupones inactivos, caducados, agotados o por debajo del mínimo', () => {
    expect(validateCoupon(coupon({ active: false }), 5000, now)).toMatch(/no está activo/);
    expect(validateCoupon(coupon({ endsAt: new Date('2026-01-01') }), 5000, now)).toMatch(/caducado/);
    expect(validateCoupon(coupon({ startsAt: new Date('2027-01-01') }), 5000, now)).toMatch(/todavía no/);
    expect(validateCoupon(coupon({ maxRedemptions: 3, redemptions: 3 }), 5000, now)).toMatch(/ya no está disponible/);
    expect(validateCoupon(coupon({ minSubtotalCents: 10000 }), 5000, now)).toMatch(/pedido mínimo/);
    expect(validateCoupon(coupon(), 5000, now)).toBeNull();
  });
  it('nunca descuenta más que el subtotal', () => {
    expect(couponDiscount(coupon({ type: 'FIXED', value: 9000 }), 5000)).toBe(5000);
    expect(couponDiscount(coupon(), 5000)).toBe(500);
  });
});

describe('envío', () => {
  it('aplica envío gratuito a partir del umbral configurado', () => {
    expect(shippingCost({ priceCents: 495, freeFromCents: 5000 }, 4999)).toBe(495);
    expect(shippingCost({ priceCents: 495, freeFromCents: 5000 }, 5000)).toBe(0);
    expect(shippingCost({ priceCents: 495, freeFromCents: null }, 999999)).toBe(495);
    expect(shippingCost(null, 1000)).toBe(0);
  });
});

describe('computeTotals', () => {
  it('suma líneas, descuento, envío e IVA incluido', () => {
    const t = computeTotals({
      lines: [{ unitPriceCents: 12100, quantity: 2, taxRate: 2100 }, { unitPriceCents: 1210, quantity: 1, taxRate: 2100 }],
      coupon: coupon(),
      shipping: { priceCents: 605, freeFromCents: null },
      shippingTaxRate: 2100
    });
    expect(t.subtotalCents).toBe(25410);
    expect(t.discountCents).toBe(2541);
    expect(t.shippingCents).toBe(605);
    expect(t.totalCents).toBe(25410 - 2541 + 605);
    // IVA = (22869 + 605) - (22869 + 605) / 1.21
    expect(t.taxCents).toBe(taxIncluded(22869, 2100) + taxIncluded(605, 2100));
    expect(t.couponError).toBeNull();
  });
  it('ignora un cupón no válido e informa del motivo', () => {
    const t = computeTotals({ lines: [{ unitPriceCents: 1000, quantity: 1, taxRate: 2100 }], coupon: coupon({ active: false }), shippingTaxRate: 2100 });
    expect(t.discountCents).toBe(0);
    expect(t.totalCents).toBe(1000);
    expect(t.couponError).not.toBeNull();
  });
  it('el descuento repartido entre líneas suma exactamente el total', () => {
    const t = computeTotals({
      lines: [{ unitPriceCents: 333, quantity: 3, taxRate: 2100 }, { unitPriceCents: 777, quantity: 1, taxRate: 1000 }],
      coupon: coupon({ type: 'FIXED', value: 101 }),
      shippingTaxRate: 2100
    });
    expect(t.discountCents).toBe(101);
    expect(t.totalCents).toBe(999 + 777 - 101);
  });
});

import Link from 'next/link';
import { Suspense } from 'react';
import { Headset, Heart, Lock, ShieldCheck, ShoppingBag, Truck, User } from 'lucide-react';
import { getCurrentUser } from '@/lib/auth';
import { getCartCount } from '@/lib/cart';
import { getSettings } from '@/lib/settings';
import { Logo } from './logo';
import { MAIN_NAV } from './nav';
import { SearchBox } from './search-box';
import { MobileMenu } from './mobile-menu';
import { CatNav } from './cat-nav';
import { FavoritesCount } from './favorites';

const INFO_ICONS = [Truck, ShieldCheck, Lock, Headset];

export async function SiteHeader() {
  const [settings, count, user] = await Promise.all([getSettings(), getCartCount(), getCurrentUser()]);
  return (
    <>
      {settings.infoBar.length > 0 && (
        <div className="bg-ink text-[13px] text-[#e9eaee]">
          <ul className="container-page flex h-9 items-center justify-center gap-9 overflow-hidden" aria-label="Información de la tienda">
            {settings.infoBar.map((text, i) => {
              const Icon = INFO_ICONS[i % INFO_ICONS.length];
              return (
                <li key={i} className={i > 0 ? 'hidden items-center gap-2 whitespace-nowrap md:inline-flex' : 'inline-flex items-center gap-2 whitespace-nowrap'}>
                  <Icon className="size-[15px] opacity-85" aria-hidden />
                  {text}
                </li>
              );
            })}
          </ul>
        </div>
      )}
      <header className="sticky top-0 z-40 border-b border-line bg-white/92 backdrop-blur-xl backdrop-saturate-150">
        <div className="container-page flex flex-wrap items-center gap-x-1 gap-y-2 py-2.5 md:h-[72px] md:flex-nowrap md:gap-6 md:py-0">
          <MobileMenu nav={MAIN_NAV} signedIn={!!user} />
          <div className="mr-auto md:mr-0">
            <Logo name={settings.storeName} logoUrl={settings.logoUrl} />
          </div>
          <div className="order-3 basis-full md:order-none md:max-w-[620px] md:flex-1 md:basis-auto">
            {/* useSearchParams necesita un límite de Suspense */}
            <Suspense fallback={<div className="h-[42px] rounded-full border border-line bg-soft md:h-[46px]" />}>
              <SearchBox />
            </Suspense>
          </div>
          <nav className="flex items-center md:ml-auto" aria-label="Accesos">
            <Link href="/contacto" className="hidden h-[42px] items-center gap-2 rounded-full px-3 text-sm font-medium text-ink-2 hover:bg-soft hover:text-ink xl:inline-flex">
              <Headset className="size-5" aria-hidden />
              Ayuda
            </Link>
            <Link href={user ? '/cuenta' : '/cuenta/acceso'} className="grid size-[42px] place-items-center rounded-full hover:bg-soft" aria-label={user ? 'Mi cuenta' : 'Iniciar sesión'}>
              <User className="size-5" aria-hidden />
            </Link>
            <Link href="/favoritos" className="relative grid size-[42px] place-items-center rounded-full hover:bg-soft" aria-label="Favoritos">
              <Heart className="size-5" aria-hidden />
              <FavoritesCount />
            </Link>
            <Link href="/carrito" className="relative grid size-[42px] place-items-center rounded-full hover:bg-soft" aria-label={`Carrito, ${count} ${count === 1 ? 'artículo' : 'artículos'}`}>
              <ShoppingBag className="size-5" aria-hidden />
              {count > 0 && (
                <span className="absolute top-0.5 right-0 grid h-[18px] min-w-[18px] place-items-center rounded-full border-2 border-white bg-brand px-1 text-[11px] font-bold text-white">{count}</span>
              )}
            </Link>
          </nav>
        </div>
        <CatNav nav={MAIN_NAV} />
      </header>
    </>
  );
}

import type { ReactNode } from 'react';
import type { LucideIcon } from 'lucide-react';

export function EmptyState({ icon: Icon, title, text, children }: { icon: LucideIcon; title: string; text: string; children?: ReactNode }) {
  return (
    <div className="rounded-card border border-dashed border-line-strong px-6 py-16 text-center">
      <div className="mx-auto mb-4 grid size-14 place-items-center rounded-full bg-soft"><Icon className="size-6" aria-hidden /></div>
      <h2 className="text-xl font-semibold">{title}</h2>
      <p className="mx-auto mt-2 mb-5 max-w-[44ch] text-muted">{text}</p>
      {children}
    </div>
  );
}

/**
 * Crea o actualiza un usuario administrador.
 * Uso: npm run admin:create -- tu@email.es "Tu nombre"
 * La contraseña se pide por la variable de entorno ADMIN_PASSWORD o se genera una aleatoria.
 */
import 'dotenv/config';
import { randomBytes } from 'node:crypto';
import bcrypt from 'bcryptjs';
import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient } from '../src/generated/prisma/client';

const [email, name = 'Administrador'] = process.argv.slice(2);
if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
  console.error('Uso: npm run admin:create -- tu@email.es "Tu nombre"');
  process.exit(1);
}

const db = new PrismaClient({ adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }) });
const generated = !process.env.ADMIN_PASSWORD;
const password = process.env.ADMIN_PASSWORD ?? randomBytes(12).toString('base64url');
if (password.length < 10) {
  console.error('La contraseña debe tener al menos 10 caracteres.');
  process.exit(1);
}

const passwordHash = await bcrypt.hash(password, 12);
await db.user.upsert({
  where: { email: email.toLowerCase() },
  update: { role: 'ADMIN', passwordHash, disabled: false },
  create: { email: email.toLowerCase(), name, role: 'ADMIN', passwordHash }
});
await db.$disconnect();
console.log(`Administrador listo: ${email.toLowerCase()}`);
if (generated) console.log(`Contraseña generada (guárdala ahora, no se volverá a mostrar): ${password}`);

import Link from 'next/link';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/cn';

/** Paginación con enlaces reales (rastreables por buscadores y accesibles sin JavaScript). */
export function Pagination({ page, pages, basePath, params }: { page: number; pages: number; basePath: string; params: Record<string, string | string[] | undefined> }) {
  if (pages <= 1) return null;
  const href = (n: number) => {
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (k !== 'pagina' && typeof v === 'string' && v) sp.set(k, v);
    if (n > 1) sp.set('pagina', String(n));
    const qs = sp.toString();
    return qs ? `${basePath}?${qs}` : basePath;
  };
  const nums = [...new Set([1, page - 1, page, page + 1, pages])].filter((n) => n >= 1 && n <= pages).sort((a, b) => a - b);
  const cell = 'grid h-10 min-w-10 place-items-center rounded-full px-3 text-sm font-medium';
  return (
    <nav aria-label="Paginación" className="mt-12 flex items-center justify-center gap-1">
      {page > 1 ? <Link href={href(page - 1)} className={cn(cell, 'hover:bg-soft')} aria-label="Página anterior"><ChevronLeft className="size-4" /></Link> : <span className={cn(cell, 'opacity-30')}><ChevronLeft className="size-4" /></span>}
      {nums.map((n, i) => (
        <span key={n} className="flex items-center gap-1">
          {i > 0 && n - nums[i - 1] > 1 && <span className="px-1 text-muted">…</span>}
          <Link href={href(n)} aria-current={n === page ? 'page' : undefined} className={cn(cell, n === page ? 'bg-ink text-white' : 'hover:bg-soft')}>{n}</Link>
        </span>
      ))}
      {page < pages ? <Link href={href(page + 1)} className={cn(cell, 'hover:bg-soft')} aria-label="Página siguiente"><ChevronRight className="size-4" /></Link> : <span className={cn(cell, 'opacity-30')}><ChevronRight className="size-4" /></span>}
    </nav>
  );
}

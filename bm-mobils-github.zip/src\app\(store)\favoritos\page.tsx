import type { Metadata } from 'next';
import { Breadcrumbs } from '@/components/store/breadcrumbs';
import { FavoritesList } from '@/components/store/favorites-list';

export const metadata: Metadata = { title: 'Favoritos', robots: { index: false } };

export default function FavoritesPage() {
  return (
    <div className="container-page pt-6">
      <Breadcrumbs items={[{ label: 'Favoritos' }]} />
      <h1 className="mb-7 text-[28px] font-bold sm:text-4xl">Favoritos</h1>
      <FavoritesList />
    </div>
  );
}

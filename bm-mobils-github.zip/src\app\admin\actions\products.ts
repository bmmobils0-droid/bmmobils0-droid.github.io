'use server';

import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import type { ProductStatus } from '@/generated/prisma/enums';
import { adminAction, UserError, type ActionResult } from '@/lib/admin-action';
import { refreshProductAggregates } from '@/lib/catalog/aggregates';
import { db } from '@/lib/db';
import { slugify } from '@/lib/slug';
import { deleteImage, saveImage, UploadError } from '@/lib/storage';
import { fieldErrors, productSchema } from '@/lib/validators';

const id = z.string().min(1).max(64);

async function uniqueSlug(base: string, exceptId?: string) {
  const root = slugify(base) || 'producto';
  for (let i = 0; i < 50; i++) {
    const slug = i === 0 ? root : `${root}-${i + 1}`;
    const found = await db.product.findUnique({ where: { slug }, select: { id: true } });
    if (!found || found.id === exceptId) return slug;
  }
  throw new UserError('No se pudo generar una URL única. Indica una manualmente.');
}

function revalidateStore(slug?: string) {
  revalidatePath('/', 'layout');
  if (slug) revalidatePath(`/producto/${slug}`);
}

export async function saveProductAction(productId: string | null, raw: unknown): Promise<ActionResult> {
  return adminAction('products:write', async (user) => {
    const parsed = productSchema.safeParse(raw);
    if (!parsed.success) return { ok: false, message: 'Revisa los campos marcados.', errors: fieldErrors(parsed.error) };
    const d = parsed.data;
    const skus = d.variants.map((v) => v.sku.toUpperCase());
    if (new Set(skus).size !== skus.length) return { ok: false, message: 'Hay SKUs repetidos entre las variantes.' };

    const existing = productId ? await db.product.findUnique({ where: { id: productId }, include: { variants: { select: { id: true, stock: true } } } }) : null;
    if (productId && !existing) throw new UserError('El producto ya no existe.');
    const slug = d.slug ? await uniqueSlug(d.slug, productId ?? undefined) : existing?.slug ?? (await uniqueSlug(`${d.name}${d.condition === 'REFURBISHED' ? ' reacondicionado' : d.condition === 'USED' ? ' segunda mano' : ''}`));

    const productData = {
      name: d.name, slug, model: d.model, brandId: d.brandId, categoryId: d.categoryId, condition: d.condition, status: d.status,
      featured: d.featured, isDemo: d.isDemo, description: d.description, conditionDetails: d.conditionDetails ?? null,
      specs: d.specs, warrantyMonths: d.warrantyMonths, warrantyText: d.warrantyText ?? null, taxRate: d.taxRate,
      seoTitle: d.seoTitle ?? null, seoDescription: d.seoDescription ?? null,
      publishedAt: d.status === 'PUBLISHED' ? existing?.publishedAt ?? new Date() : existing?.publishedAt ?? null
    };

    const savedId = await db.$transaction(async (tx) => {
      const product = existing
        ? await tx.product.update({ where: { id: existing.id }, data: productData })
        : await tx.product.create({ data: productData });

      const keep = new Set<string>();
      for (const [position, v] of d.variants.entries()) {
        const fields = {
          sku: v.sku.toUpperCase(), storageGb: v.storageGb, optionLabel: v.optionLabel ?? null, color: v.color ?? null, colorHex: v.colorHex ?? null,
          grade: v.grade ?? null, batteryHealth: v.batteryHealth,
          batteryCheckedAt: v.batteryHealth != null && v.batteryCheckedAt ? new Date(v.batteryCheckedAt) : null,
          priceCents: Math.round(v.price * 100), compareAtCents: v.compareAt != null ? Math.round(v.compareAt * 100) : null,
          lowStockAt: v.lowStockAt, isActive: v.isActive, position
        };
        const own = v.id && existing?.variants.find((x) => x.id === v.id);
        if (own) {
          keep.add(own.id);
          // Se aplica la diferencia respecto al stock que se vio al abrir el formulario,
          // así no se pisan las reservas o ventas ocurridas mientras tanto.
          const delta = v.stock - (v.originalStock ?? own.stock);
          await tx.productVariant.update({ where: { id: own.id }, data: { ...fields, ...(delta ? { stock: { increment: delta } } : {}) } });
          if (delta) await tx.inventoryMovement.create({ data: { variantId: own.id, delta, reason: 'ADJUSTMENT', note: 'Ajuste desde el panel', createdById: user.id } });
        } else {
          const created = await tx.productVariant.create({ data: { ...fields, productId: product.id, stock: v.stock } });
          keep.add(created.id);
          if (v.stock) await tx.inventoryMovement.create({ data: { variantId: created.id, delta: v.stock, reason: 'INITIAL', createdById: user.id } });
        }
      }
      for (const old of existing?.variants ?? []) {
        if (keep.has(old.id)) continue;
        const used = await tx.orderItem.count({ where: { variantId: old.id } });
        if (used) await tx.productVariant.update({ where: { id: old.id }, data: { isActive: false } });
        else await tx.productVariant.delete({ where: { id: old.id } });
      }
      await refreshProductAggregates(product.id, tx);
      return product.id;
    });

    revalidateStore(slug);
    return productId
      ? { ok: true, message: 'Producto guardado.' }
      : { ok: true, message: 'Producto creado. Ya puedes añadir fotografías.', redirect: `/admin/productos/${savedId}` };
  });
}

export async function setProductStatusAction(fd: FormData): Promise<ActionResult> {
  return adminAction('products:write', async () => {
    const pid = id.parse(fd.get('productId'));
    const status = z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED']).parse(fd.get('status')) as ProductStatus;
    const p = await db.product.update({
      where: { id: pid },
      data: { status, ...(status === 'PUBLISHED' ? { publishedAt: (await db.product.findUnique({ where: { id: pid }, select: { publishedAt: true } }))?.publishedAt ?? new Date() } : {}) }
    });
    revalidateStore(p.slug);
    return { ok: true, message: { DRAFT: 'Producto despublicado.', PUBLISHED: 'Producto publicado.', ARCHIVED: 'Producto archivado.' }[status] };
  });
}

export async function deleteProductAction(fd: FormData): Promise<ActionResult> {
  return adminAction('products:delete', async () => {
    const pid = id.parse(fd.get('productId'));
    const sold = await db.orderItem.count({ where: { productId: pid } });
    if (sold) throw new UserError('Este producto tiene pedidos asociados y no se puede eliminar. Archívalo para ocultarlo.');
    const images = await db.productImage.findMany({ where: { productId: pid }, select: { url: true } });
    await db.product.delete({ where: { id: pid } });
    await Promise.all(images.map((i) => deleteImage(i.url)));
    revalidateStore();
    return { ok: true, message: 'Producto eliminado.', redirect: '/admin/productos' };
  });
}

export async function uploadImagesAction(fd: FormData): Promise<ActionResult> {
  return adminAction('products:write', async () => {
    const pid = id.parse(fd.get('productId'));
    const files = fd.getAll('files').filter((f): f is File => f instanceof File && f.size > 0).slice(0, 10);
    if (!files.length) throw new UserError('Selecciona al menos una imagen.');
    const product = await db.product.findUniqueOrThrow({ where: { id: pid }, select: { slug: true, name: true, _count: { select: { images: true } } } });
    let position = product._count.images;
    try {
      for (const file of files) {
        const url = await saveImage(file);
        await db.productImage.create({ data: { productId: pid, url, alt: product.name, position: position++ } });
      }
    } catch (err) {
      if (err instanceof UploadError) throw new UserError(err.message);
      throw err;
    }
    revalidateStore(product.slug);
    return { ok: true, message: files.length === 1 ? 'Imagen subida.' : `${files.length} imágenes subidas.` };
  });
}

export async function updateImageAction(fd: FormData): Promise<ActionResult> {
  return adminAction('products:write', async () => {
    const imageId = id.parse(fd.get('imageId'));
    const op = fd.get('op');
    const image = await db.productImage.findUniqueOrThrow({ where: { id: imageId }, include: { product: { select: { slug: true } } } });
    if (op === 'delete') {
      await db.productImage.delete({ where: { id: imageId } });
      await deleteImage(image.url);
    } else if (op === 'up' || op === 'down') {
      const siblings = await db.productImage.findMany({ where: { productId: image.productId }, orderBy: { position: 'asc' } });
      const i = siblings.findIndex((s) => s.id === imageId);
      const j = op === 'up' ? i - 1 : i + 1;
      if (j >= 0 && j < siblings.length) {
        [siblings[i], siblings[j]] = [siblings[j], siblings[i]];
        await db.$transaction(siblings.map((s, pos) => db.productImage.update({ where: { id: s.id }, data: { position: pos } })));
      }
    } else {
      const alt = z.string().trim().max(160).parse(fd.get('alt') ?? '');
      const color = z.string().trim().max(40).parse(fd.get('color') ?? '');
      await db.productImage.update({ where: { id: imageId }, data: { alt, color: color || null } });
    }
    revalidateStore(image.product.slug);
    return { ok: true, message: op === 'delete' ? 'Imagen eliminada.' : 'Imagen actualizada.' };
  });
}

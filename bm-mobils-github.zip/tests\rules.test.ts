import { describe, expect, it } from 'vitest';
import Stripe from 'stripe';
import { provinceFromPostalCode, requiresTaxReview, zoneForPostalCode } from '@/lib/geo';
import { isValidNif } from '@/lib/nif';
import { renderLightMarkdown } from '@/lib/markdown';
import { canRefund, canTransition } from '@/lib/order-status';
import { can } from '@/lib/permissions';
import { checkoutSchema, productSchema } from '@/lib/validators';
import { dayKey, startOfDay, startOfMonth } from '@/lib/dates';
import { renderDeviceArt } from '@/lib/device-art';
import { slugify } from '@/lib/slug';

describe('geografía', () => {
  it('deduce provincia y zona por código postal', () => {
    expect(provinceFromPostalCode('28013')).toBe('Madrid');
    expect(provinceFromPostalCode('08001')).toBe('Barcelona');
    expect(provinceFromPostalCode('99999')).toBeNull();
    expect(zoneForPostalCode('07001')).toBe('BALEARES');
    expect(zoneForPostalCode('38001')).toBe('CANARIAS');
    expect(zoneForPostalCode('51001')).toBe('CEUTA_MELILLA');
    expect(zoneForPostalCode('41001')).toBe('PENINSULA');
    expect(requiresTaxReview('CANARIAS')).toBe(true);
    expect(requiresTaxReview('BALEARES')).toBe(false);
  });
});

describe('NIF/NIE/CIF', () => {
  it('valida el dígito de control', () => {
    expect(isValidNif('12345678Z')).toBe(true);
    expect(isValidNif('12345678A')).toBe(false);
    expect(isValidNif('X1234567L')).toBe(true);
    expect(isValidNif('B12345674')).toBe(true);
    expect(isValidNif('B12345670')).toBe(false);
  });
});

describe('estados de pedido', () => {
  it('solo permite transiciones manuales coherentes', () => {
    expect(canTransition('PAID', 'PREPARING')).toBe(true);
    expect(canTransition('PENDING_PAYMENT', 'PAID')).toBe(false); // solo webhook
    expect(canTransition('PAID', 'CANCELLED')).toBe(false); // se reembolsa, no se cancela
    expect(canTransition('SHIPPED', 'DELIVERED')).toBe(true);
    expect(canTransition('DELIVERED', 'PREPARING')).toBe(false);
    expect(canRefund('PAID', 'SUCCEEDED')).toBe(true);
    expect(canRefund('PENDING_PAYMENT', 'PENDING')).toBe(false);
    expect(canRefund('REFUNDED', 'REFUNDED')).toBe(false);
  });
});

describe('permisos', () => {
  it('restringe acciones sensibles por rol', () => {
    expect(can('ADMIN', 'orders:refund')).toBe(true);
    expect(can('STAFF', 'orders:refund')).toBe(false);
    expect(can('STAFF', 'orders:update')).toBe(true);
    expect(can('CUSTOMER', 'admin:access')).toBe(false);
    expect(can(null, 'admin:access')).toBe(false);
  });
});

describe('markdown de páginas', () => {
  it('escapa HTML y solo admite enlaces seguros', () => {
    const html = renderLightMarkdown('## Título\n<script>alert(1)</script>\n- **uno**\n[mal](javascript:alert(1)) [bien](/contacto)');
    expect(html).toContain('<h2>Título</h2>');
    expect(html).not.toContain('<script>');
    expect(html).toContain('&lt;script&gt;');
    expect(html).not.toContain('href="javascript');
    expect(html).toContain('<a href="/contacto">bien</a>');
    expect(html).toContain('<li><strong>uno</strong></li>');
  });
});

describe('validación', () => {
  const base = {
    email: 'Cliente@Example.com', phone: '612 345 678', firstName: 'Ana', lastName: 'García', line1: 'Calle Mayor 1', postalCode: '28013',
    city: 'Madrid', province: 'Madrid', country: 'ES', shippingRateId: 'r1', wantsInvoice: false, acceptTerms: true
  };
  it('acepta un checkout correcto y normaliza email y teléfono', () => {
    const r = checkoutSchema.safeParse(base);
    expect(r.success).toBe(true);
    if (r.success) { expect(r.data.email).toBe('cliente@example.com'); expect(r.data.phone).toBe('612345678'); }
  });
  it('exige NIF válido cuando se pide factura', () => {
    const r = checkoutSchema.safeParse({ ...base, wantsInvoice: true, billingName: 'Empresa SL', billingTaxId: '123', billingLine1: 'Calle 1', billingPostalCode: '28001', billingCity: 'Madrid' });
    expect(r.success).toBe(false);
  });
  it('rechaza CP inválido y condiciones sin aceptar', () => {
    expect(checkoutSchema.safeParse({ ...base, postalCode: '60000' }).success).toBe(false);
    expect(checkoutSchema.safeParse({ ...base, acceptTerms: false }).success).toBe(false);
  });
  const product = {
    name: 'iPhone 15', model: 'iPhone 15', brandId: 'b', categoryId: 'c', condition: 'REFURBISHED', status: 'DRAFT', specs: [],
    variants: [{ sku: 'IP15-128', price: '469,90', compareAt: '', stock: 3, storageGb: '128', batteryHealth: '', batteryCheckedAt: '' }]
  };
  it('acepta precios con coma decimal y campos opcionales vacíos', () => {
    const r = productSchema.safeParse(product);
    expect(r.success).toBe(true);
    if (r.success) { expect(r.data.variants[0].price).toBe(469.9); expect(r.data.variants[0].compareAt).toBeNull(); expect(r.data.variants[0].storageGb).toBe(128); }
  });
  it('no permite salud de batería sin fecha de comprobación ni precio anterior menor', () => {
    expect(productSchema.safeParse({ ...product, variants: [{ ...product.variants[0], batteryHealth: '91' }] }).success).toBe(false);
    expect(productSchema.safeParse({ ...product, variants: [{ ...product.variants[0], compareAt: '400' }] }).success).toBe(false);
    expect(productSchema.safeParse({ ...product, variants: [{ ...product.variants[0], stock: -1 }] }).success).toBe(false);
  });
});

describe('fechas en hora de Madrid', () => {
  it('calcula el inicio del día y del mes', () => {
    expect(startOfDay(new Date('2026-07-10T21:30:00Z')).toISOString()).toBe('2026-07-09T22:00:00.000Z');
    expect(startOfDay(new Date('2026-01-10T23:30:00Z')).toISOString()).toBe('2026-01-10T23:00:00.000Z');
    expect(startOfMonth(new Date('2026-03-15T10:00:00Z')).toISOString()).toBe('2026-02-28T23:00:00.000Z');
    expect(dayKey(new Date('2026-07-10T22:30:00Z'))).toBe('2026-07-11');
  });
});

describe('utilidades', () => {
  it('genera ilustraciones deterministas y slugs limpios', () => {
    expect(renderDeviceArt('phone', { color: '#123456' })).toBe(renderDeviceArt('phone', { color: '#123456' }));
    expect(renderDeviceArt('phone', { color: '"><script>' })).not.toContain('<script>');
    expect(slugify('iPhone 15 Pro – 256 GB Reacondicionado')).toBe('iphone-15-pro-256-gb-reacondicionado');
  });
});

describe('webhook de Stripe', () => {
  it('solo acepta eventos firmados con el secreto correcto', () => {
    const stripe = new Stripe('sk_test_dummy');
    const payload = JSON.stringify({ id: 'evt_1', object: 'event', type: 'checkout.session.completed', data: { object: {} } });
    const secret = 'whsec_test_secret';
    const header = stripe.webhooks.generateTestHeaderString({ payload, secret });
    expect(stripe.webhooks.constructEvent(payload, header, secret).id).toBe('evt_1');
    expect(() => stripe.webhooks.constructEvent(payload, header, 'whsec_otro')).toThrow();
    expect(() => stripe.webhooks.constructEvent(payload.replace('evt_1', 'evt_2'), header, secret)).toThrow();
  });
});

'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useRef } from 'react';
import { ChevronRight, Menu, X } from 'lucide-react';

export function MobileMenu({ nav, signedIn }: { nav: { href: string; label: string }[]; signedIn: boolean }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const pathname = usePathname();
  useEffect(() => dialog.current?.close(), [pathname]);

  const item = (href: string, label: string) => (
    <Link key={href} href={href} className="flex items-center justify-between border-b border-line py-3.5 text-base font-medium hover:text-brand">
      {label}
      <ChevronRight className="size-4 text-muted" aria-hidden />
    </Link>
  );

  return (
    <>
      <button type="button" className="-ml-2 grid size-[42px] place-items-center rounded-full hover:bg-soft md:hidden" aria-label="Abrir menú" onClick={() => dialog.current?.showModal()}>
        <Menu className="size-5" aria-hidden />
      </button>
      <dialog
        ref={dialog}
        className="m-0 h-dvh max-h-none w-[min(360px,88%)] bg-white p-0 shadow-pop backdrop:bg-ink/40"
        aria-label="Menú"
        onClick={(e) => { if (e.target === dialog.current) dialog.current?.close(); }}
      >
        <div className="flex items-center justify-between border-b border-line px-5 py-4">
          <span className="text-lg font-semibold">Menú</span>
          <button type="button" className="grid size-10 place-items-center rounded-full hover:bg-soft" aria-label="Cerrar menú" onClick={() => dialog.current?.close()}>
            <X className="size-5" aria-hidden />
          </button>
        </div>
        <div className="px-5 pb-8">
          <p className="pt-5 text-xs font-semibold tracking-widest text-muted uppercase">Categorías</p>
          <nav>{nav.map((n) => item(n.href, n.label))}</nav>
          <p className="pt-6 text-xs font-semibold tracking-widest text-muted uppercase">Tu cuenta</p>
          <nav>
            {item(signedIn ? '/cuenta' : '/cuenta/acceso', signedIn ? 'Mi cuenta' : 'Iniciar sesión')}
            {item('/favoritos', 'Favoritos')}
            {item('/contacto', 'Atención al cliente')}
            {item('/info/envios', 'Envíos y devoluciones')}
          </nav>
        </div>
      </dialog>
    </>
  );
}

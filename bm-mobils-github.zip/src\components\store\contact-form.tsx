'use client';

import Link from 'next/link';
import { useActionState, useEffect, useRef } from 'react';
import { contactAction } from '@/app/actions/contact';
import { Button } from '../ui/button';
import { Checkbox, Field, Input, Textarea } from '../ui/field';
import { useToast } from '../toast';

export function ContactForm() {
  const [state, action, pending] = useActionState(contactAction, undefined);
  const form = useRef<HTMLFormElement>(null);
  const { show } = useToast();
  useEffect(() => {
    if (state?.ok) { form.current?.reset(); show(state.message!); }
  }, [state, show]);
  const e = state?.errors ?? {};
  return (
    <form ref={form} action={action} noValidate className="space-y-4 rounded-card border border-line p-6">
      <h2 className="text-lg font-semibold">Envíanos un mensaje</h2>
      {state?.message && !state.ok && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{state.message}</p>}
      <Field label="Nombre" htmlFor="c-name" error={e.name}><Input id="c-name" name="name" autoComplete="name" /></Field>
      <Field label="Email" htmlFor="c-email" error={e.email}><Input id="c-email" name="email" type="email" autoComplete="email" /></Field>
      <Field label="Nº de pedido" htmlFor="c-order" optional><Input id="c-order" name="orderNumber" /></Field>
      <Field label="Mensaje" htmlFor="c-message" error={e.message}><Textarea id="c-message" name="message" /></Field>
      <input type="text" name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />
      <div>
        <Checkbox name="acceptPrivacy" label={<>Acepto la <Link href="/info/privacidad" className="text-brand underline">política de privacidad</Link>.</>} />
        {e.acceptPrivacy && <p className="mt-1.5 text-[12.5px] text-danger">{e.acceptPrivacy}</p>}
      </div>
      <Button type="submit" className="w-full" disabled={pending}>{pending ? 'Enviando…' : 'Enviar mensaje'}</Button>
    </form>
  );
}

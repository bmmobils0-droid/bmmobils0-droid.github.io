import Link from 'next/link';
import { RefreshCw } from 'lucide-react';
import type { ProductCardData } from '@/lib/catalog/queries';
import { CONDITION_LABEL } from '@/lib/labels';
import { formatPrice } from '@/lib/money';
import { Badge } from '../ui/badge';
import { ProductVisual } from '../device-art';
import { FavoriteButton } from './favorites';

export function ProductCard({ p, priority }: { p: ProductCardData; priority?: boolean }) {
  const meta = [p.storageRange, p.colors.length > 1 ? `${p.colors.length} colores` : null].filter(Boolean).join(' · ');
  return (
    <article className="group relative flex flex-col">
      <div className="relative aspect-square overflow-hidden rounded-card bg-tile transition-shadow duration-300 group-hover:shadow-card">
        <ProductVisual image={p.image} art={p.art} alt={p.name} priority={priority} className="size-full transition-transform duration-500 group-hover:scale-[1.04]" />
        <div className="pointer-events-none absolute top-2.5 right-12 left-2.5 flex flex-wrap gap-1.5 sm:top-3 sm:left-3">
          {p.isDemo && <Badge tone="dark">Demostración</Badge>}
          {p.condition === 'REFURBISHED' && <Badge tone="ok"><RefreshCw className="size-3" aria-hidden />{CONDITION_LABEL.REFURBISHED}</Badge>}
          {p.condition === 'USED' && <Badge tone="warn">{CONDITION_LABEL.USED}</Badge>}
          {p.discountPct >= 5 && <Badge tone="sale">−{p.discountPct}%</Badge>}
          {!p.inStock && !p.isDemo && <Badge tone="gray">Agotado</Badge>}
        </div>
      </div>
      <div className="absolute top-2 right-2 z-10 sm:top-2.5 sm:right-2.5">
        <FavoriteButton slug={p.slug} name={p.name} />
      </div>
      <div className="flex flex-1 flex-col gap-0.5 px-1 pt-3.5">
        <p className="text-[12.5px] font-medium text-muted">{p.brand}</p>
        <h3 className="text-[15px] leading-snug font-semibold tracking-tight">
          <Link href={`/producto/${p.slug}`} className="after:absolute after:inset-0 after:content-['']">{p.name}</Link>
        </h3>
        {meta && <p className="text-[13px] text-muted">{meta}</p>}
        <div className="mt-auto flex flex-wrap items-end justify-between gap-2 pt-2">
          <p>
            {p.priceVaries && <span className="block text-xs leading-tight text-muted">Desde</span>}
            <span className="text-[17px] font-bold tracking-tight">{formatPrice(p.priceCents)}</span>
            {p.compareAtCents && <span className="ml-1.5 text-[13px] font-medium text-muted line-through">{formatPrice(p.compareAtCents)}</span>}
          </p>
          {p.colors.length > 1 && (
            <span className="flex items-center gap-1" aria-hidden>
              {p.colors.slice(0, 4).map((c) => <span key={c.name} className="size-3 rounded-full border border-black/15" style={{ background: c.hex ?? '#ddd' }} />)}
              {p.colors.length > 4 && <span className="text-[11px] text-muted">+{p.colors.length - 4}</span>}
            </span>
          )}
        </div>
        {p.lowStock && !p.isDemo && <p className="text-xs font-medium text-warn">Últimas unidades</p>}
      </div>
    </article>
  );
}

export function ProductGrid({ items, cols = 4 }: { items: ProductCardData[]; cols?: 3 | 4 }) {
  return (
    <div className={cols === 4 ? 'grid grid-cols-2 gap-x-3 gap-y-7 sm:gap-x-5 lg:grid-cols-4' : 'grid grid-cols-2 gap-x-3 gap-y-7 sm:gap-x-5 lg:grid-cols-3'}>
      {items.map((p, i) => <ProductCard key={p.id} p={p} priority={i < 4} />)}
    </div>
  );
}

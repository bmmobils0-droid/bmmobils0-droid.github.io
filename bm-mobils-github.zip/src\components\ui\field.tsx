import { forwardRef, type ComponentProps, type ReactNode } from 'react';
import { cn } from '@/lib/cn';

const control =
  'w-full rounded-[10px] border border-line-strong bg-white px-3.5 text-[15px] outline-none transition placeholder:text-[#8b909c] focus:border-ink focus:ring-4 focus:ring-ink/5 aria-[invalid=true]:border-danger disabled:bg-soft';

export const Input = forwardRef<HTMLInputElement, ComponentProps<'input'>>(function Input({ className, ...props }, ref) {
  return <input ref={ref} className={cn(control, 'h-12', className)} {...props} />;
});

export const Select = forwardRef<HTMLSelectElement, ComponentProps<'select'>>(function Select({ className, ...props }, ref) {
  return (
    <select
      ref={ref}
      className={cn(control, 'h-12 appearance-none bg-[url("data:image/svg+xml,%3Csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20width=%2712%27%20height=%2712%27%20viewBox=%270%200%2024%2024%27%20fill=%27none%27%20stroke=%27%230b0b0f%27%20stroke-width=%272.5%27%3E%3Cpath%20d=%27m6%209%206%206%206-6%27/%3E%3C/svg%3E")] bg-[position:right_14px_center] bg-no-repeat pr-9', className)}
      {...props}
    />
  );
});

export const Textarea = forwardRef<HTMLTextAreaElement, ComponentProps<'textarea'>>(function Textarea({ className, ...props }, ref) {
  return <textarea ref={ref} className={cn(control, 'min-h-32 py-3', className)} {...props} />;
});

export function Field({ label, htmlFor, error, hint, optional, children, className }: {
  label: ReactNode; htmlFor: string; error?: string; hint?: ReactNode; optional?: boolean; children: ReactNode; className?: string;
}) {
  return (
    <div className={cn('flex flex-col gap-1.5', className)}>
      <label htmlFor={htmlFor} className="text-[13.5px] font-medium text-ink-2">
        {label}
        {optional && <span className="font-normal text-muted"> (opcional)</span>}
      </label>
      {children}
      {hint && !error && <p className="text-[12.5px] text-muted">{hint}</p>}
      {error && <p id={`${htmlFor}-error`} className="text-[12.5px] text-danger" role="alert">{error}</p>}
    </div>
  );
}

export function Checkbox({ label, className, ...props }: ComponentProps<'input'> & { label: ReactNode }) {
  return (
    <label className={cn('flex cursor-pointer items-start gap-2.5 text-sm text-ink-2', className)}>
      <input type="checkbox" className="mt-0.5 size-4 flex-none accent-ink" {...props} />
      <span>{label}</span>
    </label>
  );
}

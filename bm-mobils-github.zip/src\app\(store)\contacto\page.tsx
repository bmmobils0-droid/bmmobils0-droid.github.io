import type { Metadata } from 'next';
import { Clock, Mail, MapPin, MessageCircle, Phone } from 'lucide-react';
import { getSettings } from '@/lib/settings';
import { Breadcrumbs } from '@/components/store/breadcrumbs';
import { ContactForm } from '@/components/store/contact-form';

export const metadata: Metadata = { title: 'Atención al cliente', description: 'Contacta con BM Mobils para dudas sobre productos, pedidos, devoluciones o garantías.', alternates: { canonical: '/contacto' } };

export default async function ContactPage() {
  const s = await getSettings();
  const items = [
    s.contactPhone && { Icon: Phone, title: 'Teléfono', value: <a href={`tel:${s.contactPhone.replace(/\s/g, '')}`} className="hover:underline">{s.contactPhone}</a> },
    s.whatsapp && { Icon: MessageCircle, title: 'WhatsApp', value: s.whatsapp },
    s.contactEmail && { Icon: Mail, title: 'Email', value: <a href={`mailto:${s.contactEmail}`} className="hover:underline">{s.contactEmail}</a> },
    s.openingHours && { Icon: Clock, title: 'Horario', value: s.openingHours },
    s.address && { Icon: MapPin, title: 'Dirección', value: s.address }
  ].filter(Boolean) as { Icon: typeof Phone; title: string; value: React.ReactNode }[];

  return (
    <div className="container-page pt-6">
      <Breadcrumbs items={[{ label: 'Contacto' }]} />
      <h1 className="mb-7 text-[28px] font-bold sm:text-4xl">Atención al cliente</h1>
      <div className="grid items-start gap-10 lg:grid-cols-[1fr_1.2fr]">
        <div>
          <p className="text-ink-2">¿Tienes dudas sobre un producto, un pedido, una devolución o una garantía? Escríbenos y te responderemos lo antes posible.</p>
          {items.length > 0 && (
            <ul className="mt-6 divide-y divide-line">
              {items.map(({ Icon, title, value }) => (
                <li key={title} className="flex gap-3 py-3.5"><Icon className="mt-0.5 size-5 flex-none" aria-hidden /><div><strong className="block">{title}</strong><span className="text-ink-2">{value}</span></div></li>
              ))}
            </ul>
          )}
        </div>
        <ContactForm />
      </div>
    </div>
  );
}

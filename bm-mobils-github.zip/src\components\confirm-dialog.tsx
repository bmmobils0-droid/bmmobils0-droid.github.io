'use client';

import { useRef, type ReactNode } from 'react';
import { Button } from './ui/button';

/**
 * Botón que pide confirmación antes de enviar su formulario (acciones destructivas).
 * Debe colocarse dentro del <form> que ejecuta la acción.
 */
export function ConfirmSubmit({ children, title, description, confirmLabel = 'Confirmar', variant = 'danger', size = 'sm', disabled, name, value }: {
  children: ReactNode; title: string; description: ReactNode; confirmLabel?: string; variant?: 'danger' | 'primary' | 'outline'; size?: 'sm' | 'md';
  disabled?: boolean; name?: string; value?: string;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  return (
    <>
      <Button variant={variant} size={size} disabled={disabled} onClick={() => dialog.current?.showModal()}>
        {children}
      </Button>
      <dialog ref={dialog} className="m-auto w-[min(440px,calc(100%-32px))] rounded-2xl p-0 shadow-pop backdrop:bg-ink/40">
        <div className="p-6">
          <h2 className="text-lg font-semibold">{title}</h2>
          <div className="mt-2 text-sm text-ink-2">{description}</div>
          <div className="mt-6 flex justify-end gap-2">
            <Button variant="ghost" size="sm" onClick={() => dialog.current?.close()}>Cancelar</Button>
            <Button
              variant={variant === 'outline' ? 'primary' : variant}
              size="sm"
              type="submit"
              name={name}
              value={value}
              formNoValidate
              // El <dialog> sigue dentro del <form>: este botón lo envía con su name/value.
              onClick={() => setTimeout(() => dialog.current?.close(), 0)}
            >
              {confirmLabel}
            </Button>
          </div>
        </div>
      </dialog>
    </>
  );
}

import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';

const TONES = {
  neutral: 'bg-white text-ink shadow-[0_1px_2px_rgb(16_24_40/.06)]',
  gray: 'bg-[#eceef1] text-ink-2',
  brand: 'bg-brand-soft text-brand',
  ok: 'bg-ok-soft text-ok',
  warn: 'bg-warn-soft text-warn',
  danger: 'bg-danger-soft text-danger',
  sale: 'bg-danger text-white',
  dark: 'bg-ink text-white'
} as const;
export type BadgeTone = keyof typeof TONES;

export function Badge({ tone = 'neutral', children, className }: { tone?: BadgeTone; children: ReactNode; className?: string }) {
  return <span className={cn('inline-flex h-6 items-center gap-1 rounded-full px-2.5 text-xs font-semibold whitespace-nowrap', TONES[tone], className)}>{children}</span>;
}

import Image from 'next/image';
import { requirePermission } from '@/lib/auth';
import { db } from '@/lib/db';
import { EMAIL_TEMPLATE_KEYS, getSettings, PAYMENT_METHOD_OPTIONS } from '@/lib/settings';
import { ZONE_LABEL } from '@/lib/geo';
import { paymentsConfigured, stripeMode } from '@/lib/stripe';
import { saveBannersAction, saveEmailTemplatesAction, saveSettingsAction, saveShippingRateAction } from '@/app/admin/actions/settings';
import { ActionForm } from '@/components/admin/action-form';
import { Card, Notice, PageHeader } from '@/components/admin/ui';
import { ConfirmSubmit } from '@/components/confirm-dialog';
import { Button } from '@/components/ui/button';
import { Checkbox, Field, Input, Textarea } from '@/components/ui/field';

export const metadata = { title: 'Configuración' };

const euros = (c: number | null) => (c == null ? '' : (c / 100).toFixed(2).replace('.', ','));
const ZONES = Object.keys(ZONE_LABEL) as (keyof typeof ZONE_LABEL)[];

export default async function SettingsPage() {
  await requirePermission('settings:manage');
  const [s, rates] = await Promise.all([getSettings(), db.shippingRate.findMany({ orderBy: [{ position: 'asc' }] })]);
  const mode = stripeMode();
  const banners = [0, 1, 2, 3].map((i) => s.banners[i]);

  const rateForm = (r?: (typeof rates)[number]) => (
    <ActionForm key={r?.id ?? 'new'} action={saveShippingRateAction} resetOnSuccess={!r} className="grid gap-3 rounded-xl border border-line p-4 md:grid-cols-[1.2fr_1.4fr_.7fr_.8fr] md:items-end">
      {r && <input type="hidden" name="id" value={r.id} />}
      <Field label="Nombre" htmlFor={`r-name-${r?.id ?? 'new'}`}><Input id={`r-name-${r?.id ?? 'new'}`} name="name" defaultValue={r?.name} className="h-10" required /></Field>
      <Field label="Descripción" htmlFor={`r-desc-${r?.id ?? 'new'}`} optional><Input id={`r-desc-${r?.id ?? 'new'}`} name="description" defaultValue={r?.description ?? ''} className="h-10" /></Field>
      <Field label="Precio (€)" htmlFor={`r-price-${r?.id ?? 'new'}`}><Input id={`r-price-${r?.id ?? 'new'}`} name="price" inputMode="decimal" defaultValue={euros(r?.priceCents ?? null)} className="h-10" required /></Field>
      <Field label="Gratis desde (€)" htmlFor={`r-free-${r?.id ?? 'new'}`} optional><Input id={`r-free-${r?.id ?? 'new'}`} name="freeFrom" inputMode="decimal" defaultValue={euros(r?.freeFromCents ?? null)} className="h-10" /></Field>
      <fieldset className="flex flex-wrap gap-x-4 gap-y-2 md:col-span-3">
        <legend className="sr-only">Zonas</legend>
        {ZONES.map((z) => <Checkbox key={z} name="zones" value={z} defaultChecked={r ? r.zones.includes(z) : z === 'PENINSULA'} label={ZONE_LABEL[z]} />)}
        <Checkbox name="active" defaultChecked={r ? r.active : true} label="Activa" />
      </fieldset>
      <div className="flex gap-2 md:justify-end">
        <Button type="submit" size="sm" name="op" value="save">{r ? 'Guardar' : 'Añadir tarifa'}</Button>
        {r && <ConfirmSubmit title="¿Eliminar tarifa?" description={`Se eliminará “${r.name}”. Los pedidos ya creados no cambian.`} confirmLabel="Eliminar" name="op" value="delete">Eliminar</ConfirmSubmit>}
      </div>
    </ActionForm>
  );

  return (
    <>
      <PageHeader title="Configuración" subtitle="Cambios visibles en la tienda al guardar." />
      <div className="mb-4">
        {!paymentsConfigured()
          ? <Notice>Stripe no está configurado. Los pagos se activan con variables de entorno (ver README), nunca desde aquí, para no exponer claves.</Notice>
          : <Notice tone="info">Stripe activo en modo <strong>{mode === 'live' ? 'real' : 'de prueba'}</strong>.</Notice>}
      </div>

      <ActionForm action={saveSettingsAction} className="space-y-4">
        <Card title="Tienda y contacto">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Nombre de la tienda" htmlFor="st-name"><Input id="st-name" name="storeName" defaultValue={s.storeName} required /></Field>
            <Field label="Logotipo" htmlFor="st-logo" hint="PNG, JPG o WebP (máx. 5 MB). Recomendado 280×72 px." optional>
              <div className="flex items-center gap-3">
                {s.logoUrl && <Image src={s.logoUrl} alt="Logotipo actual" width={120} height={32} className="h-8 w-auto" />}
                <input id="st-logo" name="logo" type="file" accept="image/png,image/jpeg,image/webp" className="text-sm" />
              </div>
            </Field>
            {s.logoUrl && <Checkbox name="removeLogo" label="Quitar logotipo (usar el nombre)" />}
            <Field label="Email de contacto" htmlFor="st-email" optional><Input id="st-email" name="contactEmail" type="email" defaultValue={s.contactEmail ?? ''} /></Field>
            <Field label="Teléfono" htmlFor="st-phone" optional><Input id="st-phone" name="contactPhone" defaultValue={s.contactPhone ?? ''} /></Field>
            <Field label="WhatsApp" htmlFor="st-wa" optional><Input id="st-wa" name="whatsapp" defaultValue={s.whatsapp ?? ''} /></Field>
            <Field label="Horario" htmlFor="st-hours" optional><Input id="st-hours" name="openingHours" defaultValue={s.openingHours ?? ''} /></Field>
            <Field label="Dirección" htmlFor="st-address" optional className="md:col-span-2"><Input id="st-address" name="address" defaultValue={s.address ?? ''} /></Field>
          </div>
        </Card>

        <Card title="Redes sociales">
          <div className="grid gap-4 md:grid-cols-3">
            {(['instagram', 'facebook', 'tiktok', 'x', 'youtube'] as const).map((k) => (
              <Field key={k} label={k === 'x' ? 'X (Twitter)' : k[0].toUpperCase() + k.slice(1)} htmlFor={`so-${k}`} optional><Input id={`so-${k}`} name={k} type="url" placeholder="https://" defaultValue={s.social[k] ?? ''} /></Field>
            ))}
          </div>
        </Card>

        <Card title="Datos legales e impuestos">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Razón social" htmlFor="lg-name" optional><Input id="lg-name" name="legalName" defaultValue={s.legalName ?? ''} /></Field>
            <Field label="NIF / CIF" htmlFor="lg-tax" optional><Input id="lg-tax" name="legalTaxId" defaultValue={s.legalTaxId ?? ''} /></Field>
            <Field label="Domicilio social" htmlFor="lg-address" optional><Input id="lg-address" name="legalAddress" defaultValue={s.legalAddress ?? ''} /></Field>
            <Field label="Datos registrales" htmlFor="lg-registry" optional><Input id="lg-registry" name="legalRegistry" defaultValue={s.legalRegistry ?? ''} /></Field>
            <Field label="IVA general (%)" htmlFor="lg-vat" hint="Se aplica a los gastos de envío. El IVA de cada producto se define en su ficha. Todos los precios se introducen con IVA incluido.">
              <Input id="lg-vat" name="defaultTaxRate" inputMode="decimal" defaultValue={String(s.defaultTaxRate / 100)} />
            </Field>
          </div>
        </Card>

        <Card title="Portada y mensajes">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Titular" htmlFor="hp-title"><Input id="hp-title" name="heroTitle" defaultValue={s.heroTitle} required /></Field>
            <Field label="Imagen del hero" htmlFor="hp-image" optional hint="Sin imagen se usa la ilustración de móviles.">
              <input id="hp-image" name="heroImage" type="file" accept="image/png,image/jpeg,image/webp,image/avif" className="text-sm" />
            </Field>
            {s.heroImageUrl && <Checkbox name="removeHeroImage" label="Quitar imagen del hero" className="md:col-start-2" />}
            <Field label="Subtítulo" htmlFor="hp-sub" className="md:col-span-2"><Textarea id="hp-sub" name="heroSubtitle" rows={2} className="min-h-0" defaultValue={s.heroSubtitle} /></Field>
            <Field label="Barra informativa (un mensaje por línea)" htmlFor="hp-info" className="md:col-span-2" hint="Incluye solo promesas confirmadas por el negocio (envíos, garantía, plazos).">
              <Textarea id="hp-info" name="infoBar" rows={4} defaultValue={s.infoBar.join('\n')} />
            </Field>
          </div>
        </Card>

        <Card title="Métodos de pago mostrados">
          <p className="mb-3 text-sm text-muted">Solo informativo en la web. Los métodos que se ofrecen al pagar se activan en el panel de Stripe (Settings → Payment methods).</p>
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            {Object.entries(PAYMENT_METHOD_OPTIONS).map(([k, label]) => <Checkbox key={k} name="paymentMethods" value={k} defaultChecked={s.paymentMethods.includes(k as keyof typeof PAYMENT_METHOD_OPTIONS)} label={label} />)}
          </div>
        </Card>

        <div className="sticky bottom-4 flex justify-end"><Button type="submit" className="shadow-card">Guardar configuración</Button></div>
      </ActionForm>

      <Card title="Tarifas de envío" className="mt-6">
        <div id="envios" className="space-y-3">
          {rates.map((r) => rateForm(r))}
          <p className="pt-2 text-sm font-semibold">Nueva tarifa</p>
          {rateForm()}
        </div>
      </Card>

      <Card title="Banners de la portada" className="mt-6">
        <ActionForm action={saveBannersAction} className="space-y-4">
          <p className="text-sm text-muted">Hasta 4 banners. Deja el título vacío para quitar uno.</p>
          {banners.map((b, i) => (
            <div key={i} className="grid gap-3 rounded-xl border border-line p-4 md:grid-cols-4 md:items-end">
              <Field label={`Banner ${i + 1}: título`} htmlFor={`b${i}-title`} optional><Input id={`b${i}-title`} name={`b${i}-title`} defaultValue={b?.title ?? ''} className="h-10" /></Field>
              <Field label="Texto" htmlFor={`b${i}-text`} optional><Input id={`b${i}-text`} name={`b${i}-text`} defaultValue={b?.text ?? ''} className="h-10" /></Field>
              <Field label="Enlace" htmlFor={`b${i}-href`} optional><Input id={`b${i}-href`} name={`b${i}-href`} defaultValue={b?.href ?? '/ofertas'} className="h-10" /></Field>
              <Field label="Imagen" htmlFor={`b${i}-image`} optional>
                <input id={`b${i}-image`} name={`b${i}-image`} type="file" accept="image/png,image/jpeg,image/webp,image/avif" className="text-sm" />
              </Field>
              {b?.imageUrl && <Checkbox name={`b${i}-removeImage`} label="Quitar imagen" />}
            </div>
          ))}
          <Button type="submit" size="sm">Guardar banners</Button>
        </ActionForm>
      </Card>

      <Card title="Correos transaccionales" className="mt-6">
        <ActionForm action={saveEmailTemplatesAction} className="space-y-4">
          <p className="text-sm text-muted">Usa <code>{'{numero}'}</code> para el número de pedido y <code>{'{tienda}'}</code> para el nombre de la tienda. El correo incluye siempre el resumen del pedido y un enlace para consultarlo.</p>
          {(Object.entries(EMAIL_TEMPLATE_KEYS) as [keyof typeof EMAIL_TEMPLATE_KEYS, string][]).map(([k, label]) => (
            <div key={k} className="grid gap-3 rounded-xl border border-line p-4 md:grid-cols-[1fr_2fr]">
              <Field label={`${label}: asunto`} htmlFor={`${k}-subject`}><Input id={`${k}-subject`} name={`${k}-subject`} defaultValue={s.emailTemplates[k].subject} className="h-10" /></Field>
              <Field label="Texto inicial" htmlFor={`${k}-intro`}><Textarea id={`${k}-intro`} name={`${k}-intro`} rows={2} className="min-h-0" defaultValue={s.emailTemplates[k].intro} /></Field>
            </div>
          ))}
          <Button type="submit" size="sm">Guardar plantillas</Button>
        </ActionForm>
      </Card>
    </>
  );
}

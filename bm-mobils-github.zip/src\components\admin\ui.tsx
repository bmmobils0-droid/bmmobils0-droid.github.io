import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';
import type { OrderStatus, PaymentStatus } from '@/generated/prisma/enums';
import { ORDER_STATUS_LABEL, PAYMENT_STATUS_LABEL } from '@/lib/order-status';
import { Badge, type BadgeTone } from '../ui/badge';

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-bold">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Card({ title, actions, children, className }: { title?: string; actions?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cn('rounded-card border border-line bg-white p-5', className)}>
      {(title || actions) && (
        <div className="mb-4 flex items-center justify-between gap-3">
          {title && <h2 className="text-base font-semibold">{title}</h2>}
          {actions}
        </div>
      )}
      {children}
    </section>
  );
}

export function Table({ children }: { children: ReactNode }) {
  return (
    <div className="overflow-x-auto rounded-card border border-line bg-white">
      <table className="w-full min-w-[640px] border-collapse text-sm [&_td]:border-t [&_td]:border-line [&_td]:px-4 [&_td]:py-3 [&_th]:bg-soft [&_th]:px-4 [&_th]:py-2.5 [&_th]:text-left [&_th]:text-xs [&_th]:font-semibold [&_th]:tracking-wide [&_th]:text-muted [&_th]:uppercase">
        {children}
      </table>
    </div>
  );
}

const ORDER_TONE: Record<OrderStatus, BadgeTone> = {
  PENDING_PAYMENT: 'warn', PAID: 'brand', PREPARING: 'brand', SHIPPED: 'ok', DELIVERED: 'ok', CANCELLED: 'gray', REFUNDED: 'gray'
};
const PAYMENT_TONE: Record<PaymentStatus, BadgeTone> = {
  PENDING: 'warn', SUCCEEDED: 'ok', FAILED: 'danger', CANCELLED: 'gray', REFUNDED: 'gray', PARTIALLY_REFUNDED: 'warn', REQUIRES_REVIEW: 'danger'
};
export const OrderStatusBadge = ({ status }: { status: OrderStatus }) => <Badge tone={ORDER_TONE[status]}>{ORDER_STATUS_LABEL[status]}</Badge>;
export const PaymentStatusBadge = ({ status }: { status: PaymentStatus }) => <Badge tone={PAYMENT_TONE[status]}>{PAYMENT_STATUS_LABEL[status]}</Badge>;

export function Notice({ tone = 'warn', children }: { tone?: 'warn' | 'info' | 'danger'; children: ReactNode }) {
  const cls = { warn: 'bg-warn-soft text-[#6b3e00]', info: 'bg-brand-soft text-[#1d2f6f]', danger: 'bg-danger-soft text-danger' }[tone];
  return <div className={cn('rounded-xl px-4 py-3 text-sm', cls)}>{children}</div>;
}

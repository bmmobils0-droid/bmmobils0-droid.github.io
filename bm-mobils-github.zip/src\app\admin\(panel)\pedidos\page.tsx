import Link from 'next/link';
import type { Prisma } from '@/generated/prisma/client';
import type { OrderStatus, PaymentStatus } from '@/generated/prisma/enums';
import { requirePermission } from '@/lib/auth';
import { db } from '@/lib/db';
import { formatPrice } from '@/lib/money';
import { ORDER_STATUS_LABEL, PAYMENT_STATUS_LABEL } from '@/lib/order-status';
import { OrderStatusBadge, PageHeader, PaymentStatusBadge, Table } from '@/components/admin/ui';

export const metadata = { title: 'Pedidos' };
const PAGE = 50;

export default async function OrdersPage({ searchParams }: { searchParams: Promise<{ estado?: string; pago?: string; q?: string; pagina?: string; abandonados?: string }> }) {
  await requirePermission('admin:access');
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.pagina) || 1);
  const status = sp.estado && sp.estado in ORDER_STATUS_LABEL ? (sp.estado as OrderStatus) : undefined;
  const pay = sp.pago && sp.pago in PAYMENT_STATUS_LABEL ? (sp.pago as PaymentStatus) : undefined;
  const where: Prisma.OrderWhereInput = {
    ...(status ? { status } : {}),
    ...(pay ? { paymentStatus: pay } : {}),
    // Por defecto se ocultan los intentos de pago abandonados.
    ...(!status && !pay && !sp.abandonados ? { NOT: { status: 'CANCELLED', paymentStatus: 'CANCELLED' } } : {}),
    ...(sp.q ? { OR: [{ number: { contains: sp.q, mode: 'insensitive' } }, { email: { contains: sp.q, mode: 'insensitive' } }, { shipLastName: { contains: sp.q, mode: 'insensitive' } }] } : {})
  };
  const [total, orders] = await Promise.all([
    db.order.count({ where }),
    db.order.findMany({ where, orderBy: { createdAt: 'desc' }, skip: (page - 1) * PAGE, take: PAGE, include: { _count: { select: { items: true } } } })
  ]);
  const date = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Madrid' });
  const tabs: [string, string][] = [['', 'Todos'], ['PAID', 'Pagados'], ['PREPARING', 'Preparando'], ['SHIPPED', 'Enviados'], ['PENDING_PAYMENT', 'Pendientes de pago'], ['DELIVERED', 'Entregados'], ['CANCELLED', 'Cancelados'], ['REFUNDED', 'Reembolsados']];
  const qs = (over: Record<string, string>) => new URLSearchParams({ ...(sp.q ? { q: sp.q } : {}), ...(status ? { estado: status } : {}), ...over }).toString();

  return (
    <>
      <PageHeader title="Pedidos" subtitle={`${total} pedidos`} />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {tabs.map(([v, label]) => (
          <Link key={v} href={v ? `/admin/pedidos?estado=${v}` : '/admin/pedidos'} className={`rounded-full px-3 py-1.5 text-sm font-medium ${(sp.estado ?? '') === v && !pay ? 'bg-ink text-white' : 'bg-white text-ink-2 hover:text-ink'}`}>{label}</Link>
        ))}
        <Link href="/admin/pedidos?pago=REQUIRES_REVIEW" className={`rounded-full px-3 py-1.5 text-sm font-medium ${pay === 'REQUIRES_REVIEW' ? 'bg-danger text-white' : 'bg-white text-danger'}`}>Pago a revisar</Link>
        <form className="ml-auto" role="search">
          {status && <input type="hidden" name="estado" value={status} />}
          <input name="q" defaultValue={sp.q} placeholder="Nº pedido, email o apellido" aria-label="Buscar pedidos" className="h-9 w-64 rounded-full border border-line-strong bg-white px-3.5 text-sm outline-none focus:border-ink" />
        </form>
      </div>
      <Table>
        <thead><tr><th>Pedido</th><th>Fecha</th><th>Cliente</th><th>Estado</th><th>Pago</th><th className="text-right">Total</th></tr></thead>
        <tbody>
          {orders.length === 0 && <tr><td colSpan={6} className="py-10 text-center text-muted">No hay pedidos con estos criterios.</td></tr>}
          {orders.map((o) => (
            <tr key={o.id} className="hover:bg-soft/60">
              <td><Link href={`/admin/pedidos/${o.id}`} className="font-semibold hover:underline">{o.number}</Link><span className="block text-xs text-muted">{o._count.items} líneas{o.requiresTaxReview ? ' · revisión fiscal' : ''}</span></td>
              <td className="whitespace-nowrap">{date.format(o.createdAt)}</td>
              <td>{o.shipFirstName} {o.shipLastName}<span className="block text-xs text-muted">{o.shipCity} ({o.shipProvince})</span></td>
              <td><OrderStatusBadge status={o.status} /></td>
              <td><PaymentStatusBadge status={o.paymentStatus} /></td>
              <td className="text-right font-semibold">{formatPrice(o.totalCents)}</td>
            </tr>
          ))}
        </tbody>
      </Table>
      <div className="mt-4 flex items-center justify-between text-sm">
        <Link href={`/admin/pedidos?${qs({ abandonados: '1' })}`} className="text-muted hover:underline">Ver también intentos de pago abandonados</Link>
        {total > PAGE && (
          <span className="flex gap-2">
            {page > 1 && <Link href={`/admin/pedidos?${qs({ pagina: String(page - 1) })}`} className="rounded-full bg-white px-3 py-1.5">Anterior</Link>}
            <span className="px-3 py-1.5 text-muted">Página {page} de {Math.ceil(total / PAGE)}</span>
            {page * PAGE < total && <Link href={`/admin/pedidos?${qs({ pagina: String(page + 1) })}`} className="rounded-full bg-white px-3 py-1.5">Siguiente</Link>}
          </span>
        )}
      </div>
    </>
  );
}

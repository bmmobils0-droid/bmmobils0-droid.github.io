import Image from 'next/image';
import Link from 'next/link';
import { cn } from '@/lib/cn';

export function Logo({ name, logoUrl, small }: { name: string; logoUrl?: string | null; small?: boolean }) {
  const [first, ...rest] = name.split(' ');
  return (
    <Link href="/" className="inline-flex flex-none items-center gap-2 font-bold tracking-tight" aria-label={`${name}, ir al inicio`}>
      {logoUrl ? (
        <Image src={logoUrl} alt={name} width={140} height={36} className="h-9 w-auto" priority />
      ) : (
        <>
          <span className={cn('grid place-items-center rounded-[10px] bg-ink text-white', small ? 'size-8 text-[13px]' : 'size-9 text-sm')}>{first.slice(0, 3)}</span>
          {rest.length > 0 && <span className={small ? 'text-[19px]' : 'text-[21px]'}>{rest.join(' ')}</span>}
        </>
      )}
    </Link>
  );
}

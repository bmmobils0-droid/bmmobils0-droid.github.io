import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requirePermission } from '@/lib/auth';
import { db } from '@/lib/db';
import { formatPrice } from '@/lib/money';
import { can, ROLE_LABEL } from '@/lib/permissions';
import { updateCustomerAction } from '@/app/admin/actions/misc';
import { ActionForm } from '@/components/admin/action-form';
import { Card, OrderStatusBadge, PageHeader } from '@/components/admin/ui';
import { ConfirmSubmit } from '@/components/confirm-dialog';
import { Checkbox, Select } from '@/components/ui/field';

export const metadata = { title: 'Cliente' };

export default async function CustomerPage({ params }: { params: Promise<{ id: string }> }) {
  const me = await requirePermission('customers:read');
  const { id } = await params;
  const user = await db.user.findUnique({
    where: { id },
    select: {
      id: true, name: true, email: true, phone: true, role: true, disabled: true, createdAt: true, lastLoginAt: true,
      addresses: true,
      orders: { orderBy: { createdAt: 'desc' }, select: { id: true, number: true, status: true, totalCents: true, createdAt: true } }
    }
  });
  if (!user) notFound();
  const date = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'Europe/Madrid' });

  return (
    <>
      <PageHeader title={user.name} subtitle={`${ROLE_LABEL[user.role]} · Alta el ${date.format(user.createdAt)}${user.lastLoginAt ? ` · Último acceso el ${date.format(user.lastLoginAt)}` : ''}`} />
      <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
        <Card title="Historial de pedidos">
          {user.orders.length === 0 ? <p className="text-sm text-muted">Sin pedidos.</p> : (
            <ul className="divide-y divide-line text-sm">
              {user.orders.map((o) => (
                <li key={o.id}><Link href={`/admin/pedidos/${o.id}`} className="flex items-center gap-3 py-2.5 hover:bg-soft"><span className="font-semibold">{o.number}</span><span className="text-muted">{date.format(o.createdAt)}</span><span className="ml-auto flex items-center gap-3"><OrderStatusBadge status={o.status} /><strong>{formatPrice(o.totalCents)}</strong></span></Link></li>
              ))}
            </ul>
          )}
        </Card>
        <div className="space-y-4">
          <Card title="Contacto">
            <p className="text-sm"><a href={`mailto:${user.email}`} className="text-brand hover:underline">{user.email}</a>{user.phone && <><br />{user.phone}</>}</p>
            {user.addresses.map((a) => <p key={a.id} className="mt-3 text-sm text-ink-2">{a.firstName} {a.lastName}<br />{a.line1}{a.line2 && `, ${a.line2}`}<br />{a.postalCode} {a.city} ({a.province})</p>)}
          </Card>
          {can(me.role, 'customers:manage') && (
            <Card title="Acceso y permisos">
              <ActionForm action={updateCustomerAction} className="space-y-4">
                <input type="hidden" name="userId" value={user.id} />
                <label className="block text-sm font-medium" htmlFor="role">Rol</label>
                <Select id="role" name="role" defaultValue={user.role} className="h-10">
                  <option value="CUSTOMER">Cliente</option><option value="STAFF">Equipo (pedidos y productos)</option><option value="ADMIN">Administrador (acceso total)</option>
                </Select>
                <Checkbox name="disabled" defaultChecked={user.disabled} label="Cuenta desactivada (no puede iniciar sesión)" />
                <ConfirmSubmit variant="primary" title="¿Guardar cambios de acceso?" description="Se cerrarán las sesiones abiertas de esta cuenta." confirmLabel="Guardar">Guardar</ConfirmSubmit>
              </ActionForm>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}

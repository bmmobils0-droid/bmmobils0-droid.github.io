import { requirePermission } from '@/lib/auth';
import { PageHeader } from '@/components/admin/ui';
import { ProductForm } from '@/components/admin/product-form';
import { formOptions } from '../product-data';

export const metadata = { title: 'Nuevo producto' };

export default async function NewProductPage() {
  await requirePermission('products:write');
  const { brands, categories } = await formOptions();
  return (
    <>
      <PageHeader title="Nuevo producto" subtitle="Guarda el producto para poder subir sus fotografías." />
      <ProductForm
        productId={null}
        brands={brands}
        categories={categories}
        defaults={{
          name: '', slug: '', model: '', brandId: '', categoryId: '', condition: 'NEW', status: 'DRAFT', featured: false, isDemo: false,
          description: '', conditionDetails: '', specs: [], warrantyMonths: '', warrantyText: '', taxRate: 2100, seoTitle: '', seoDescription: '',
          variants: [{ sku: '', storageGb: '', optionLabel: '', color: '', colorHex: '', grade: '', batteryHealth: '', batteryCheckedAt: '', price: '', compareAt: '', stock: 0, lowStockAt: 2, isActive: true }]
        }}
      />
    </>
  );
}

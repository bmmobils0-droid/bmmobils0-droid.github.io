'use client';

import { useEffect, useState } from 'react';
import { Heart } from 'lucide-react';
import type { ProductCardData } from '@/lib/catalog/queries';
import { ProductCard } from './product-card';
import { EmptyState } from './empty-state';
import { useFavorites } from './favorites';
import { ButtonLink } from '../ui/button';
import { ProductGridSkeleton } from '../ui/skeleton';

export function FavoritesList() {
  const { list } = useFavorites();
  const [data, setData] = useState<{ key: string; items: ProductCardData[] } | null>(null);
  const key = list.join(',');

  useEffect(() => {
    if (!key) return;
    const ctrl = new AbortController();
    fetch(`/api/products?slugs=${encodeURIComponent(key)}`, { signal: ctrl.signal })
      .then((r) => r.json())
      .then((d: { items: ProductCardData[] }) => setData({ key, items: d.items }))
      .catch(() => {});
    return () => ctrl.abort();
  }, [key]);

  // Mientras llega la respuesta de la lista actual se muestra el esqueleto.
  if (key && data?.key !== key) return <ProductGridSkeleton count={4} />;
  const visible = key ? data!.items.filter((i) => list.includes(i.slug)) : [];
  if (!visible.length) {
    return (
      <EmptyState icon={Heart} title="Aún no tienes favoritos" text="Pulsa el corazón de cualquier producto para guardarlo aquí. Se guardan en este navegador.">
        <ButtonLink href="/moviles">Explorar móviles</ButtonLink>
      </EmptyState>
    );
  }
  return (
    <div className="grid grid-cols-2 gap-x-3 gap-y-7 sm:gap-x-5 lg:grid-cols-4">
      {visible.map((p) => <ProductCard key={p.id} p={p} />)}
    </div>
  );
}

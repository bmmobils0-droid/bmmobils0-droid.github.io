import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { LoginForm } from '@/components/auth-forms';

export const metadata: Metadata = { title: 'Iniciar sesión', robots: { index: false } };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  if (await getCurrentUser()) redirect('/cuenta');
  return (
    <div className="container-page max-w-md pt-12">
      <h1 className="mb-2 text-3xl font-bold">Iniciar sesión</h1>
      <p className="mb-7 text-muted">Accede para consultar tus pedidos.</p>
      <LoginForm next={next} />
    </div>
  );
}

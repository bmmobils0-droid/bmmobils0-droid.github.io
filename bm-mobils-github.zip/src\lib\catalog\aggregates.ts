import 'server-only';
import type { Tx } from '../db';
import { db } from '../db';
import { discountPct } from '../money';

/**
 * Recalcula los campos derivados del producto (precio desde, descuento máximo y stock total)
 * a partir de sus variantes activas. Se llama tras cualquier cambio de variantes o stock.
 */
export async function refreshProductAggregates(productId: string, tx: Tx | typeof db = db) {
  const variants = await tx.productVariant.findMany({
    where: { productId, isActive: true },
    select: { priceCents: true, compareAtCents: true, stock: true }
  });
  const fromPriceCents = variants.length ? Math.min(...variants.map((v) => v.priceCents)) : 0;
  const maxDiscountPct = variants.reduce((m, v) => Math.max(m, discountPct(v.priceCents, v.compareAtCents)), 0);
  const totalStock = variants.reduce((s, v) => s + v.stock, 0);
  await tx.product.update({ where: { id: productId }, data: { fromPriceCents, maxDiscountPct, totalStock } });
}

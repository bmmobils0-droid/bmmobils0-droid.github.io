import { safeEqual } from '@/lib/crypto';
import { releaseExpiredReservations } from '@/lib/orders';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Libera el stock de pedidos cuyo pago no se completó. Programarlo cada 10-15 minutos
 * (Vercel Cron, Supabase cron, etc.) con la cabecera Authorization: Bearer <CRON_SECRET>.
 */
export async function GET(req: Request) {
  const secret = process.env.CRON_SECRET;
  const auth = req.headers.get('authorization') ?? '';
  if (!secret || !safeEqual(auth, `Bearer ${secret}`)) return new Response('No autorizado', { status: 401 });
  const released = await releaseExpiredReservations();
  return Response.json({ released });
}

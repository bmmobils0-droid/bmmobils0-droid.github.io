'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useMemo, useState, useTransition } from 'react';
import { BatteryMedium, Info, Lock, Minus, Plus, RefreshCw, ShieldCheck, Truck } from 'lucide-react';
import { addToCartAction } from '@/app/actions/cart';
import { renderDeviceArt, type ArtView } from '@/lib/device-art';
import { CONDITION_LABEL, GRADE_DESCRIPTION, GRADE_LABEL, storageLabel } from '@/lib/labels';
import { discountPct, formatPrice } from '@/lib/money';
import { cn } from '@/lib/cn';
import type { CosmeticGrade, DeviceCondition } from '@/generated/prisma/enums';
import type { ArtSpec } from '../device-art';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { useToast } from '../toast';
import { FavoriteButton } from './favorites';

export type DetailVariant = {
  id: string; storageGb: number | null; optionLabel: string | null; color: string | null; colorHex: string | null; grade: CosmeticGrade | null;
  batteryHealth: number | null; batteryCheckedAt: string | null; priceCents: number; compareAtCents: number | null; stock: number;
};
type Dim = 'grade' | 'option' | 'color';

const GRADE_ORDER: CosmeticGrade[] = ['GOOD', 'VERY_GOOD', 'EXCELLENT'];
const optionOf = (v: DetailVariant) => (v.storageGb != null ? String(v.storageGb) : v.optionLabel);
const valueOf = (v: DetailVariant, d: Dim) => (d === 'grade' ? v.grade : d === 'option' ? optionOf(v) : v.color);

export function ProductDetail(props: {
  slug: string; name: string; brand: string; model: string; condition: DeviceCondition; isDemo: boolean;
  variants: DetailVariant[]; images: { url: string; alt: string; color: string | null }[]; art: Omit<ArtSpec, 'color'>;
  optionTitle: string; warrantyText: string; shippingFromCents: number | null;
}) {
  const { variants, images, art } = props;
  const router = useRouter();
  const { show } = useToast();
  const [pending, start] = useTransition();
  const initial = variants.find((v) => v.stock > 0) ?? variants[0];
  const [sel, setSel] = useState<Record<Dim, string | null>>({ grade: initial?.grade ?? null, option: initial ? optionOf(initial) : null, color: initial?.color ?? null });
  const [qty, setQty] = useState(1);
  const [view, setView] = useState(0);

  const dims = (['grade', 'option', 'color'] as Dim[]).filter((d) => new Set(variants.map((v) => valueOf(v, d)).filter(Boolean)).size > 0);
  const current = useMemo(() => variants.find((v) => dims.every((d) => valueOf(v, d) === sel[d])) ?? initial, [variants, sel, dims, initial]);

  /** Al elegir un valor, se busca la variante que mejor conserva el resto de la selección. */
  const choose = (dim: Dim, value: string) => {
    const candidates = variants.filter((v) => valueOf(v, dim) === value);
    const score = (v: DetailVariant) => dims.reduce((s, d) => s + (d !== dim && valueOf(v, d) === sel[d] ? 2 : 0), 0) + (v.stock > 0 ? 1 : 0);
    const best = candidates.sort((a, b) => score(b) - score(a))[0];
    if (!best) return;
    setSel({ grade: best.grade, option: optionOf(best), color: best.color });
    setQty(1);
    if (dim === 'color') setView(0);
  };

  const options = (dim: Dim) => {
    const seen = new Map<string, DetailVariant[]>();
    variants.forEach((v) => { const k = valueOf(v, dim); if (k) seen.set(k, [...(seen.get(k) ?? []), v]); });
    const entries = [...seen.entries()];
    if (dim === 'grade') entries.sort((a, b) => GRADE_ORDER.indexOf(a[0] as CosmeticGrade) - GRADE_ORDER.indexOf(b[0] as CosmeticGrade));
    if (dim === 'option') entries.sort((a, b) => (Number(a[0]) || 0) - (Number(b[0]) || 0));
    return entries.map(([value, vs]) => {
      const exact = vs.find((v) => dims.every((d) => d === dim || valueOf(v, d) === sel[d]));
      return { value, price: (exact ?? vs.sort((a, b) => a.priceCents - b.priceCents)[0]).priceCents, available: vs.some((v) => v.stock > 0), exact: !!exact, hex: vs[0].colorHex };
    });
  };

  const colorImages = images.filter((i) => !i.color || i.color === current?.color);
  const gallery = images.length
    ? (colorImages.length ? colorImages : images).map((img) => ({ kind: 'img' as const, img }))
    : ((art.type === 'phone' || art.type === 'tablet' ? ['duo', 'back', 'front'] : ['duo']) as ArtView[]).map((v) => ({ kind: 'art' as const, view: v }));
  const shown = gallery[Math.min(view, gallery.length - 1)];
  const artHtml = (v: ArtView) => renderDeviceArt(art.type, { style: art.style, color: current?.colorHex, view: v });

  const purchasable = !props.isDemo && !!current && current.stock > 0;
  const maxQty = Math.min(current?.stock ?? 0, 10);
  const off = current ? discountPct(current.priceCents, current.compareAtCents) : 0;

  const add = (buyNow: boolean) =>
    start(async () => {
      if (!current) return;
      const res = await addToCartAction(current.id, qty);
      if (!res.ok) return show(res.message, { tone: 'error' });
      if (buyNow) router.push('/checkout');
      else { show(res.message, { action: { label: 'Ver carrito', href: '/carrito' } }); router.refresh(); }
    });

  return (
    <div className="grid items-start gap-9 lg:grid-cols-[1.15fr_1fr] lg:gap-14">
      <div className="lg:sticky lg:top-[136px]">
        <div className="relative aspect-square overflow-hidden rounded-3xl bg-tile">
          {shown?.kind === 'img' ? (
            <Image key={shown.img.url} src={shown.img.url} alt={shown.img.alt || props.name} fill priority sizes="(min-width: 1024px) 55vw, 100vw" className="animate-fade-in object-contain p-[5%]" />
          ) : shown ? (
            <div key={shown.view + (current?.colorHex ?? '')} role="img" aria-label={props.name} className="art-box size-full animate-fade-in" dangerouslySetInnerHTML={{ __html: artHtml(shown.view) }} />
          ) : null}
        </div>
        {gallery.length > 1 && (
          <div className="mt-3 flex gap-2.5 overflow-x-auto" role="group" aria-label="Imágenes del producto">
            {gallery.map((g, i) => (
              <button
                key={i}
                type="button"
                aria-label={`Ver imagen ${i + 1}`}
                aria-current={i === view}
                onClick={() => setView(i)}
                className={cn('relative size-[72px] flex-none overflow-hidden rounded-[14px] border-2 bg-tile', i === view ? 'border-ink' : 'border-transparent hover:border-line-strong')}
              >
                {g.kind === 'img' ? <Image src={g.img.url} alt="" fill sizes="72px" className="object-contain p-1" /> : <span className="art-box block size-full" dangerouslySetInnerHTML={{ __html: artHtml(g.view) }} />}
              </button>
            ))}
          </div>
        )}
      </div>

      <div>
        <p className="text-sm font-medium text-muted">{props.brand} · {props.model}</p>
        <h1 className="mt-1 text-[28px] font-bold sm:text-[36px]">{props.name}</h1>
        <div className="mt-3.5 flex flex-wrap gap-1.5">
          {props.condition === 'NEW' && <Badge tone="brand">{CONDITION_LABEL.NEW}</Badge>}
          {props.condition === 'REFURBISHED' && <Badge tone="ok"><RefreshCw className="size-3" aria-hidden />{CONDITION_LABEL.REFURBISHED}{current?.grade ? ` · ${GRADE_LABEL[current.grade]}` : ''}</Badge>}
          {props.condition === 'USED' && <Badge tone="warn">{CONDITION_LABEL.USED}</Badge>}
        </div>

        {props.isDemo && (
          <p className="mt-4 flex gap-2.5 rounded-xl bg-warn-soft p-3.5 text-sm text-[#6b3e00]">
            <Info className="mt-0.5 size-4 flex-none" aria-hidden />
            Producto de demostración: no está disponible para la venta hasta que la tienda confirme su existencia.
          </p>
        )}

        {current && (
          <div className="mt-5">
            <p className="flex flex-wrap items-baseline gap-2.5">
              <span className="text-[30px] font-bold tracking-tight">{formatPrice(current.priceCents)}</span>
              {current.compareAtCents && off > 0 && (
                <>
                  <span className="text-base text-muted line-through">{formatPrice(current.compareAtCents)}</span>
                  <span className="rounded-full bg-danger-soft px-2.5 py-0.5 text-[13px] font-semibold text-danger">Ahorras {formatPrice(current.compareAtCents - current.priceCents)}</span>
                </>
              )}
            </p>
            <p className="mt-1 text-[13px] text-muted">IVA incluido. Gastos de envío calculados en el checkout.</p>
          </div>
        )}

        {dims.includes('grade') && (
          <fieldset className="mt-7">
            <legend className="mb-2.5 flex w-full items-baseline text-sm font-semibold">
              Estado estético
              <Link href="/info/garantia" className="ml-auto text-[13px] font-medium text-brand hover:underline">Garantía y estados</Link>
            </legend>
            <div className="grid grid-cols-[repeat(auto-fill,minmax(130px,1fr))] gap-2">
              {options('grade').map((o) => (
                <OptionButton key={o.value} active={sel.grade === o.value} faded={!o.available} onClick={() => choose('grade', o.value)} title={GRADE_LABEL[o.value as CosmeticGrade]} sub={formatPrice(o.price)} />
              ))}
            </div>
            {current?.grade && <p className="mt-2 text-[13px] text-muted">{GRADE_DESCRIPTION[current.grade]}</p>}
          </fieldset>
        )}

        {dims.includes('option') && (
          <fieldset className="mt-6">
            <legend className="mb-2.5 text-sm font-semibold">{props.optionTitle}</legend>
            <div className="grid grid-cols-[repeat(auto-fill,minmax(130px,1fr))] gap-2">
              {options('option').map((o) => (
                <OptionButton key={o.value} active={sel.option === o.value} faded={!o.available} onClick={() => choose('option', o.value)} title={Number(o.value) ? storageLabel(Number(o.value))! : o.value} sub={formatPrice(o.price)} />
              ))}
            </div>
          </fieldset>
        )}

        {dims.includes('color') && (
          <fieldset className="mt-6">
            <legend className="mb-2.5 text-sm font-semibold">Color <span className="font-normal text-muted">{sel.color}</span></legend>
            <div className="flex flex-wrap gap-2.5">
              {options('color').map((o) => (
                <button
                  key={o.value}
                  type="button"
                  aria-pressed={sel.color === o.value}
                  aria-label={`${o.value}${o.available ? '' : ' (agotado)'}`}
                  title={o.value}
                  onClick={() => choose('color', o.value)}
                  className={cn('relative size-10 rounded-full border-2 border-white transition hover:scale-105', sel.color === o.value ? 'ring-2 ring-ink' : 'ring-1 ring-line-strong', !o.available && 'opacity-40')}
                  style={{ background: o.hex ?? '#ddd' }}
                />
              ))}
            </div>
          </fieldset>
        )}

        {current?.batteryHealth != null && current.batteryCheckedAt && (
          <p className="mt-6 flex items-center gap-2.5 text-sm">
            <BatteryMedium className="size-5 text-ok" aria-hidden />
            <span>
              <strong>Salud de batería: {current.batteryHealth} %</strong>{' '}
              <span className="text-muted">(comprobada el {new Date(current.batteryCheckedAt).toLocaleDateString('es-ES')})</span>
            </span>
          </p>
        )}

        {!props.isDemo && current && (
          <p className={cn('mt-6 flex items-center gap-2 text-sm font-medium', current.stock === 0 ? 'text-muted' : current.stock <= 3 ? 'text-warn' : 'text-ok')}>
            <span className={cn('size-2 rounded-full', current.stock === 0 ? 'bg-line-strong' : current.stock <= 3 ? 'bg-[#e08a00]' : 'bg-ok')} aria-hidden />
            {current.stock === 0 ? 'Agotado' : current.stock <= 3 ? `Últimas ${current.stock} unidades` : 'En stock'}
          </p>
        )}

        <div className="mt-4 flex flex-wrap gap-2.5">
          <div className="inline-flex h-13 items-center rounded-full border border-line-strong px-1" role="group" aria-label="Cantidad">
            <button type="button" className="grid size-10 place-items-center rounded-full hover:bg-soft disabled:opacity-35" onClick={() => setQty((q) => Math.max(1, q - 1))} disabled={qty <= 1 || !purchasable} aria-label="Quitar una unidad"><Minus className="size-4" /></button>
            <output className="min-w-7 text-center font-semibold" aria-live="polite">{qty}</output>
            <button type="button" className="grid size-10 place-items-center rounded-full hover:bg-soft disabled:opacity-35" onClick={() => setQty((q) => Math.min(maxQty, q + 1))} disabled={qty >= maxQty || !purchasable} aria-label="Añadir una unidad"><Plus className="size-4" /></button>
          </div>
          <Button size="lg" className="min-w-[180px] flex-1" disabled={!purchasable || pending} onClick={() => add(false)}>
            {props.isDemo ? 'No disponible' : current?.stock === 0 ? 'Agotado' : pending ? 'Añadiendo…' : 'Añadir al carrito'}
          </Button>
          <FavoriteButton slug={props.slug} name={props.name} large />
        </div>
        {purchasable && (
          <Button size="lg" variant="outline" className="mt-2.5 w-full" disabled={pending} onClick={() => add(true)}>Comprar ahora</Button>
        )}

        <ul className="mt-7 divide-y divide-line rounded-card border border-line text-sm text-ink-2">
          <li className="flex gap-3 p-4"><Truck className="size-5 flex-none text-ink" aria-hidden /><div><strong className="block font-semibold text-ink">Envíos a toda España</strong>{props.shippingFromCents != null ? `Desde ${formatPrice(props.shippingFromCents)} en península. ` : ''}<Link href="/info/envios" className="font-medium text-brand hover:underline">Ver envíos</Link></div></li>
          <li className="flex gap-3 p-4"><ShieldCheck className="size-5 flex-none text-ink" aria-hidden /><div><strong className="block font-semibold text-ink">Garantía</strong>{props.warrantyText} <Link href="/info/garantia" className="font-medium text-brand hover:underline">Condiciones</Link></div></li>
          <li className="flex gap-3 p-4"><Lock className="size-5 flex-none text-ink" aria-hidden /><div><strong className="block font-semibold text-ink">Pago seguro</strong>Procesado por Stripe. No guardamos los datos de tu tarjeta.</div></li>
        </ul>
      </div>
    </div>
  );
}

function OptionButton({ active, faded, onClick, title, sub }: { active: boolean; faded: boolean; onClick: () => void; title: string; sub: string }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        'flex flex-col items-start gap-0.5 rounded-xl border-[1.5px] bg-white px-3.5 py-3 text-left transition',
        active ? 'border-ink bg-[#fafafa] shadow-[inset_0_0_0_1px_var(--color-ink)]' : 'border-line-strong hover:border-ink-2',
        faded && 'opacity-50'
      )}
    >
      <strong className="text-sm font-semibold">{title}</strong>
      <span className="text-[13px] text-muted">{faded ? 'Agotado' : sub}</span>
    </button>
  );
}

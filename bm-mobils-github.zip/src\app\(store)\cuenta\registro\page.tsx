import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { RegisterForm } from '@/components/auth-forms';

export const metadata: Metadata = { title: 'Crear cuenta', robots: { index: false } };

export default async function RegisterPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  if (await getCurrentUser()) redirect('/cuenta');
  return (
    <div className="container-page max-w-md pt-12">
      <h1 className="mb-2 text-3xl font-bold">Crear cuenta</h1>
      <p className="mb-7 text-muted">Consulta tus pedidos y compra más rápido. Los pedidos que hiciste como invitado con el mismo email se vincularán a tu cuenta.</p>
      <RegisterForm next={next} />
    </div>
  );
}

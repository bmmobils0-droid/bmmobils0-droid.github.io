/** Validación de NIF, NIE y CIF españoles (dígito de control). */
const LETTERS = 'TRWAGMYFPDXBNJZSQVHLCKE';

export function isValidNif(value: string): boolean {
  const v = value.toUpperCase().replace(/[\s-]/g, '');
  if (/^\d{8}[A-Z]$/.test(v)) return LETTERS[Number(v.slice(0, 8)) % 23] === v[8];
  if (/^[XYZ]\d{7}[A-Z]$/.test(v)) {
    const num = String('XYZ'.indexOf(v[0])) + v.slice(1, 8);
    return LETTERS[Number(num) % 23] === v[8];
  }
  if (/^[ABCDEFGHJNPQRSUVW]\d{7}[0-9A-J]$/.test(v)) {
    const digits = v.slice(1, 8);
    let sum = 0;
    for (let i = 0; i < 7; i++) {
      let n = Number(digits[i]);
      if (i % 2 === 0) { n *= 2; if (n > 9) n -= 9; }
      sum += n;
    }
    const control = (10 - (sum % 10)) % 10;
    const last = v[8];
    return last === String(control) || last === 'JABCDEFGHI'[control];
  }
  return false;
}

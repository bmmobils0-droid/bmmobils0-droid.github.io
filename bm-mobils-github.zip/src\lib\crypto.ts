import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

function secret(): string {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 32) throw new Error('SESSION_SECRET debe tener al menos 32 caracteres.');
  return s;
}

export function randomToken(bytes = 32): string {
  return randomBytes(bytes).toString('base64url');
}

/** Hash con clave de un token. En la base de datos solo se guarda este hash. */
export function hashToken(token: string): string {
  return createHmac('sha256', secret()).update(token).digest('hex');
}

export function safeEqual(a: string, b: string): boolean {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  return ba.length === bb.length && timingSafeEqual(ba, bb);
}

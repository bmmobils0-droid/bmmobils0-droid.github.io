'use server';

import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { getCurrentUser } from '@/lib/auth';
import { addItem, setCoupon, updateItemQuantity, type CartActionResult } from '@/lib/cart';
import { clientIp, rateLimit } from '@/lib/rate-limit';

const idSchema = z.string().min(1).max(64);

export async function addToCartAction(variantId: string, quantity: number): Promise<CartActionResult> {
  const v = idSchema.safeParse(variantId);
  const q = z.number().int().min(1).max(10).safeParse(quantity);
  if (!v.success || !q.success) return { ok: false, message: 'Datos no válidos.' };
  if (!(await rateLimit(`cart:${await clientIp()}`, 120, 60_000))) return { ok: false, message: 'Demasiadas peticiones. Espera un momento.' };
  const user = await getCurrentUser();
  const res = await addItem(v.data, q.data, user?.id);
  revalidatePath('/', 'layout');
  return res;
}

export async function updateCartItemAction(itemId: string, quantity: number): Promise<CartActionResult> {
  const v = idSchema.safeParse(itemId);
  const q = z.number().int().min(0).max(10).safeParse(quantity);
  if (!v.success || !q.success) return { ok: false, message: 'Datos no válidos.' };
  const res = await updateItemQuantity(v.data, q.data);
  revalidatePath('/', 'layout');
  return res;
}

export async function applyCouponAction(code: string): Promise<CartActionResult> {
  const c = z.string().trim().min(1).max(30).safeParse(code);
  if (!c.success) return { ok: false, message: 'Introduce un código.' };
  if (!(await rateLimit(`coupon:${await clientIp()}`, 15, 10 * 60_000))) return { ok: false, message: 'Demasiados intentos. Prueba más tarde.' };
  const res = await setCoupon(c.data);
  revalidatePath('/carrito');
  revalidatePath('/checkout');
  return res;
}

export async function removeCouponAction(): Promise<CartActionResult> {
  const res = await setCoupon(null);
  revalidatePath('/carrito');
  revalidatePath('/checkout');
  return res;
}

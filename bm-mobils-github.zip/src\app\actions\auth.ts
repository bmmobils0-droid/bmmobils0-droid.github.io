'use server';

import { redirect } from 'next/navigation';
import { createSession, destroySession, hashPassword, verifyCredentials } from '@/lib/auth';
import { db } from '@/lib/db';
import { can } from '@/lib/permissions';
import { clientIp, rateLimit } from '@/lib/rate-limit';
import { fieldErrors, loginSchema, registerSchema } from '@/lib/validators';

export type FormState = { message?: string; errors?: Record<string, string> } | undefined;

/** Solo redirecciones internas: evita redirecciones abiertas a otros dominios. */
function safeNext(next: FormDataEntryValue | null, fallback: string) {
  const n = typeof next === 'string' ? next : '';
  return n.startsWith('/') && !n.startsWith('//') && !n.startsWith('/\\') ? n : fallback;
}

export async function loginAction(_: FormState, formData: FormData): Promise<FormState> {
  const parsed = loginSchema.safeParse({ email: formData.get('email'), password: formData.get('password') });
  if (!parsed.success) return { errors: fieldErrors(parsed.error) };
  const ip = await clientIp();
  const allowed = (await rateLimit(`login:ip:${ip}`, 20, 15 * 60_000)) && (await rateLimit(`login:email:${parsed.data.email}`, 8, 15 * 60_000));
  if (!allowed) return { message: 'Demasiados intentos. Espera 15 minutos e inténtalo de nuevo.' };

  const user = await verifyCredentials(parsed.data.email, parsed.data.password);
  if (!user) return { message: 'Email o contraseña incorrectos.' };

  const adminArea = formData.get('area') === 'admin';
  if (adminArea && !can(user.role, 'admin:access')) return { message: 'Esta cuenta no tiene acceso al panel.' };

  await createSession(user.id);
  redirect(safeNext(formData.get('next'), adminArea ? '/admin' : '/cuenta'));
}

export async function registerAction(_: FormState, formData: FormData): Promise<FormState> {
  const parsed = registerSchema.safeParse({
    name: formData.get('name'),
    email: formData.get('email'),
    password: formData.get('password'),
    acceptPrivacy: formData.get('acceptPrivacy') === 'on'
  });
  if (!parsed.success) return { errors: fieldErrors(parsed.error) };
  if (!(await rateLimit(`register:${await clientIp()}`, 5, 60 * 60_000))) return { message: 'Demasiados registros desde esta conexión. Prueba más tarde.' };

  const exists = await db.user.findUnique({ where: { email: parsed.data.email } });
  if (exists) return { errors: { email: 'Ya existe una cuenta con este email. Inicia sesión.' } };

  const user = await db.user.create({
    data: { email: parsed.data.email, name: parsed.data.name, passwordHash: await hashPassword(parsed.data.password), role: 'CUSTOMER' }
  });
  // Vincula los pedidos que la persona hizo como invitado con el mismo email.
  await db.order.updateMany({ where: { email: user.email, userId: null }, data: { userId: user.id } });
  await createSession(user.id);
  redirect(safeNext(formData.get('next'), '/cuenta'));
}

export async function logoutAction() {
  await destroySession();
  redirect('/');
}

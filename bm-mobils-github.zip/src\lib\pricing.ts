/**
 * Cálculo de totales. Función pura: el servidor siempre recalcula con precios de la base
 * de datos y nunca usa importes enviados por el navegador.
 *
 * Todos los importes son céntimos con IVA incluido.
 */
import { taxIncluded } from './money';

export type PricingLine = { unitPriceCents: number; quantity: number; taxRate: number };

export type CouponRule = {
  code: string;
  type: 'PERCENT' | 'FIXED';
  value: number;
  minSubtotalCents: number | null;
  startsAt: Date | null;
  endsAt: Date | null;
  maxRedemptions: number | null;
  redemptions: number;
  active: boolean;
};

export type ShippingRule = { priceCents: number; freeFromCents: number | null };

export type Totals = {
  subtotalCents: number;
  discountCents: number;
  shippingCents: number;
  taxCents: number;
  totalCents: number;
  couponError: string | null;
};

export function validateCoupon(coupon: CouponRule, subtotalCents: number, now = new Date()): string | null {
  if (!coupon.active) return 'Este cupón no está activo.';
  if (coupon.startsAt && now < coupon.startsAt) return 'Este cupón todavía no es válido.';
  if (coupon.endsAt && now > coupon.endsAt) return 'Este cupón ha caducado.';
  if (coupon.maxRedemptions != null && coupon.redemptions >= coupon.maxRedemptions) return 'Este cupón ya no está disponible.';
  if (coupon.minSubtotalCents != null && subtotalCents < coupon.minSubtotalCents) {
    return `Este cupón requiere un pedido mínimo de ${(coupon.minSubtotalCents / 100).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' })}.`;
  }
  return null;
}

export function couponDiscount(coupon: CouponRule, subtotalCents: number): number {
  const raw = coupon.type === 'PERCENT' ? Math.round((subtotalCents * coupon.value) / 10000) : coupon.value;
  return Math.max(0, Math.min(raw, subtotalCents));
}

export function shippingCost(rule: ShippingRule | null, subtotalAfterDiscountCents: number): number {
  if (!rule) return 0;
  if (rule.freeFromCents != null && subtotalAfterDiscountCents >= rule.freeFromCents) return 0;
  return rule.priceCents;
}

export function computeTotals(input: {
  lines: PricingLine[];
  coupon?: CouponRule | null;
  shipping?: ShippingRule | null;
  shippingTaxRate: number;
  now?: Date;
}): Totals {
  const subtotalCents = input.lines.reduce((sum, l) => sum + l.unitPriceCents * l.quantity, 0);

  let discountCents = 0;
  let couponError: string | null = null;
  if (input.coupon) {
    couponError = validateCoupon(input.coupon, subtotalCents, input.now);
    if (!couponError) discountCents = couponDiscount(input.coupon, subtotalCents);
  }

  const afterDiscount = subtotalCents - discountCents;
  const shippingCents = shippingCost(input.shipping ?? null, afterDiscount);

  // El descuento se reparte proporcionalmente entre líneas para calcular el IVA de cada tipo.
  let allocated = 0;
  let taxCents = 0;
  input.lines.forEach((l, i) => {
    const gross = l.unitPriceCents * l.quantity;
    const share = i === input.lines.length - 1
      ? discountCents - allocated
      : subtotalCents > 0 ? Math.round((discountCents * gross) / subtotalCents) : 0;
    allocated += share;
    taxCents += taxIncluded(gross - share, l.taxRate);
  });
  taxCents += taxIncluded(shippingCents, input.shippingTaxRate);

  return { subtotalCents, discountCents, shippingCents, taxCents, totalCents: afterDiscount + shippingCents, couponError };
}

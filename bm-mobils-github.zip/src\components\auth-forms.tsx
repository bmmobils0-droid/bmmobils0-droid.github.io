'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { loginAction, registerAction } from '@/app/actions/auth';
import { Button } from './ui/button';
import { Checkbox, Field, Input } from './ui/field';

export function LoginForm({ next, area }: { next?: string; area?: 'admin' }) {
  const [state, action, pending] = useActionState(loginAction, undefined);
  return (
    <form action={action} className="space-y-4" noValidate>
      <input type="hidden" name="next" value={next ?? ''} />
      {area && <input type="hidden" name="area" value={area} />}
      {state?.message && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{state.message}</p>}
      <Field label="Email" htmlFor="l-email" error={state?.errors?.email}>
        <Input id="l-email" name="email" type="email" autoComplete="email" required aria-invalid={!!state?.errors?.email} />
      </Field>
      <Field label="Contraseña" htmlFor="l-password" error={state?.errors?.password}>
        <Input id="l-password" name="password" type="password" autoComplete="current-password" required aria-invalid={!!state?.errors?.password} />
      </Field>
      <Button type="submit" className="w-full" disabled={pending}>{pending ? 'Entrando…' : 'Iniciar sesión'}</Button>
      {!area && <p className="text-center text-sm text-muted">¿No tienes cuenta? <Link href={`/cuenta/registro${next ? `?next=${encodeURIComponent(next)}` : ''}`} className="font-semibold text-brand hover:underline">Crear cuenta</Link></p>}
    </form>
  );
}

export function RegisterForm({ next }: { next?: string }) {
  const [state, action, pending] = useActionState(registerAction, undefined);
  return (
    <form action={action} className="space-y-4" noValidate>
      <input type="hidden" name="next" value={next ?? ''} />
      {state?.message && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{state.message}</p>}
      <Field label="Nombre y apellidos" htmlFor="r-name" error={state?.errors?.name}><Input id="r-name" name="name" autoComplete="name" required /></Field>
      <Field label="Email" htmlFor="r-email" error={state?.errors?.email}><Input id="r-email" name="email" type="email" autoComplete="email" required /></Field>
      <Field label="Contraseña" htmlFor="r-password" error={state?.errors?.password} hint="Mínimo 10 caracteres."><Input id="r-password" name="password" type="password" autoComplete="new-password" required minLength={10} /></Field>
      <div>
        <Checkbox name="acceptPrivacy" label={<>Acepto la <Link href="/info/privacidad" className="text-brand underline">política de privacidad</Link>.</>} />
        {state?.errors?.acceptPrivacy && <p className="mt-1.5 text-[12.5px] text-danger">{state.errors.acceptPrivacy}</p>}
      </div>
      <Button type="submit" className="w-full" disabled={pending}>{pending ? 'Creando cuenta…' : 'Crear cuenta'}</Button>
      <p className="text-center text-sm text-muted">¿Ya tienes cuenta? <Link href="/cuenta/acceso" className="font-semibold text-brand hover:underline">Inicia sesión</Link></p>
    </form>
  );
}

import Link from 'next/link';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { dayKey, startOfDay, startOfMonth } from '@/lib/dates';
import { formatPrice } from '@/lib/money';
import { SALE_STATUSES } from '@/lib/order-status';
import { paymentsConfigured, stripeMode } from '@/lib/stripe';
import { variantLabel } from '@/lib/labels';
import { Card, Notice, OrderStatusBadge, PageHeader } from '@/components/admin/ui';
import { SalesChart } from '@/components/admin/sales-chart';

export const metadata = { title: 'Resumen' };

export default async function DashboardPage({ searchParams }: { searchParams: Promise<{ 'sin-permiso'?: string }> }) {
  const sp = await searchParams;
  const user = await getCurrentUser();
  const now = new Date();
  const today = startOfDay(now);
  const month = startOfMonth(now);
  const since30 = startOfDay(new Date(now.getTime() - 29 * 86400_000));
  const sale = { status: { in: SALE_STATUSES } };

  const [todayAgg, monthAgg, ordersMonth, toShip, pendingPay, published, demoCount, reviewPayments, lowStock, recent, last30, legalPending, sampleRates] = await Promise.all([
    db.order.aggregate({ where: { ...sale, paidAt: { gte: today } }, _sum: { totalCents: true }, _count: true }),
    db.order.aggregate({ where: { ...sale, paidAt: { gte: month } }, _sum: { totalCents: true } }),
    db.order.count({ where: { ...sale, paidAt: { gte: month } } }),
    db.order.count({ where: { status: { in: ['PAID', 'PREPARING'] } } }),
    db.order.count({ where: { status: 'PENDING_PAYMENT' } }),
    db.product.count({ where: { status: 'PUBLISHED', isDemo: false } }),
    db.product.count({ where: { isDemo: true, status: { not: 'ARCHIVED' } } }),
    db.order.count({ where: { paymentStatus: 'REQUIRES_REVIEW' } }),
    db.$queryRaw<{ id: string; productId: string; name: string; stock: number; lowStockAt: number; storageGb: number | null; optionLabel: string | null; color: string | null; grade: null }[]>`
      SELECT v."id", v."productId", p."name", v."stock", v."lowStockAt", v."storageGb", v."optionLabel", v."color", NULL AS "grade"
      FROM "ProductVariant" v JOIN "Product" p ON p."id" = v."productId"
      WHERE v."isActive" AND p."status" = 'PUBLISHED' AND NOT p."isDemo" AND v."stock" <= v."lowStockAt"
      ORDER BY v."stock" ASC LIMIT 10`,
    db.order.findMany({ where: { NOT: { status: 'CANCELLED', paymentStatus: 'CANCELLED' } }, orderBy: { createdAt: 'desc' }, take: 6, select: { id: true, number: true, status: true, totalCents: true, createdAt: true, shipFirstName: true, shipLastName: true } }),
    db.order.findMany({ where: { ...sale, paidAt: { gte: since30 } }, select: { paidAt: true, totalCents: true } }),
    db.page.count({ where: { needsLegalReview: true } }),
    db.shippingRate.count({ where: { description: { contains: 'ejemplo', mode: 'insensitive' } } })
  ]);

  // Serie diaria de ventas (últimos 30 días) calculada a partir de pedidos cobrados.
  const byDay = new Map<string, number>();
  for (const o of last30) { const k = dayKey(o.paidAt!); byDay.set(k, (byDay.get(k) ?? 0) + o.totalCents); }
  const series = Array.from({ length: 30 }, (_, i) => {
    const d = new Date(since30.getTime() + i * 86400_000 + 12 * 3600_000);
    const k = dayKey(d);
    return { key: k, label: d.toLocaleDateString('es-ES', { day: 'numeric', month: 'short', timeZone: 'Europe/Madrid' }), cents: byDay.get(k) ?? 0 };
  });

  const mode = stripeMode();
  const date = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Madrid' });

  return (
    <>
      <PageHeader title={`Hola, ${user?.name.split(' ')[0] ?? ''}`} subtitle="Resumen de la tienda calculado a partir de pedidos reales." />

      <div className="mb-6 space-y-2">
        {sp['sin-permiso'] && <Notice tone="danger">No tienes permiso para acceder a esa sección.</Notice>}
        {!paymentsConfigured() && <Notice>Los pagos no están activados: falta configurar <code>STRIPE_SECRET_KEY</code> y <code>STRIPE_WEBHOOK_SECRET</code>. Consulta el README.</Notice>}
        {mode === 'test' && paymentsConfigured() && <Notice tone="info">Stripe está en <strong>modo de prueba</strong>: los pagos no son reales.</Notice>}
        {reviewPayments > 0 && <Notice tone="danger"><Link href="/admin/pedidos?pago=REQUIRES_REVIEW" className="font-semibold underline">{reviewPayments} {reviewPayments === 1 ? 'pago requiere' : 'pagos requieren'} revisión</Link> (importe no coincidente o pedido cancelado).</Notice>}
        {demoCount > 0 && <Notice><Link href="/admin/productos?demo=1" className="font-semibold underline">{demoCount} productos de demostración</Link>: no se pueden comprar ni se indexan. Revísalos y desmarca “Demostración” solo cuando confirmes que existen.</Notice>}
        {legalPending > 0 && <Notice><Link href="/admin/paginas" className="font-semibold underline">{legalPending} páginas legales</Link> pendientes de completar y revisar.</Notice>}
        {sampleRates > 0 && <Notice><Link href="/admin/configuracion#envios" className="font-semibold underline">Tarifas de envío de ejemplo</Link>: confirma los importes reales antes de vender.</Notice>}
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Ventas de hoy" value={formatPrice(todayAgg._sum.totalCents ?? 0)} sub={`${todayAgg._count} pedidos`} />
        <Stat label="Ventas del mes" value={formatPrice(monthAgg._sum.totalCents ?? 0)} sub={`${ordersMonth} pedidos cobrados`} />
        <Stat label="Pendientes de enviar" value={String(toShip)} sub={`${pendingPay} esperando pago`} href="/admin/pedidos?estado=PAID" />
        <Stat label="Productos publicados" value={String(published)} sub={`${lowStock.length} con poco stock`} href="/admin/productos" />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.6fr_1fr]">
        <Card title="Ventas de los últimos 30 días">
          <SalesChart data={series} />
        </Card>
        <Card title="Poco stock" actions={<Link href="/admin/productos" className="text-sm font-medium text-brand hover:underline">Ver productos</Link>}>
          {lowStock.length === 0 ? <p className="text-sm text-muted">Ninguna variante publicada por debajo de su umbral.</p> : (
            <ul className="divide-y divide-line text-sm">
              {lowStock.map((v) => (
                <li key={v.id} className="flex items-center justify-between gap-3 py-2.5">
                  <Link href={`/admin/productos/${v.productId}`} className="min-w-0 hover:underline"><span className="block truncate font-medium">{v.name}</span><span className="text-xs text-muted">{variantLabel(v)}</span></Link>
                  <span className={v.stock === 0 ? 'font-semibold text-danger' : 'font-semibold text-warn'}>{v.stock} ud.</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <Card title="Últimos pedidos" className="mt-4" actions={<Link href="/admin/pedidos" className="text-sm font-medium text-brand hover:underline">Ver todos</Link>}>
        {recent.length === 0 ? <p className="text-sm text-muted">Todavía no hay pedidos.</p> : (
          <ul className="divide-y divide-line text-sm">
            {recent.map((o) => (
              <li key={o.id}>
                <Link href={`/admin/pedidos/${o.id}`} className="flex flex-wrap items-center gap-3 py-2.5 hover:bg-soft">
                  <span className="font-semibold">{o.number}</span>
                  <span className="text-muted">{o.shipFirstName} {o.shipLastName}</span>
                  <span className="text-muted">{date.format(o.createdAt)}</span>
                  <span className="ml-auto flex items-center gap-3"><OrderStatusBadge status={o.status} /><strong>{formatPrice(o.totalCents)}</strong></span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </>
  );
}

function Stat({ label, value, sub, href }: { label: string; value: string; sub: string; href?: string }) {
  const body = (
    <>
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 text-2xl font-bold tracking-tight">{value}</p>
      <p className="mt-0.5 text-xs text-muted">{sub}</p>
    </>
  );
  return href ? <Link href={href} className="rounded-card border border-line bg-white p-5 transition hover:border-ink">{body}</Link> : <div className="rounded-card border border-line bg-white p-5">{body}</div>;
}

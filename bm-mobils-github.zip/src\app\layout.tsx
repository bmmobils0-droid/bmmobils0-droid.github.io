import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import { ToastProvider } from '@/components/toast';
import { siteUrl } from '@/lib/site';
import './globals.css';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' });

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl()),
  title: { default: 'BM Mobils — Móviles nuevos, reacondicionados y accesorios', template: '%s | BM Mobils' },
  description: 'Compra iPhone, Samsung, Xiaomi y Google Pixel nuevos, reacondicionados y de segunda mano, además de fundas, cargadores y accesorios. Envíos a toda España.',
  openGraph: { type: 'website', locale: 'es_ES', siteName: 'BM Mobils' },
  icons: { icon: '/icon.svg' }
};

export const viewport: Viewport = { themeColor: '#ffffff', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" className={inter.variable}>
      <body className="min-h-dvh font-sans">
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}

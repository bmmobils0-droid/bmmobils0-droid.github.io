import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { Suspense } from 'react';
import { SearchX } from 'lucide-react';
import { resolveCollection } from '@/lib/catalog/collections';
import { getFacets, listProducts, parseFilters, SORTS } from '@/lib/catalog/queries';
import { CONDITION_LABEL, CONDITION_SLUG, storageLabel } from '@/lib/labels';
import { Breadcrumbs } from '@/components/store/breadcrumbs';
import { ActiveFilters, CatalogFilters, SortSelect } from '@/components/store/catalog-filters';
import { CatalogResults, CatalogShell } from '@/components/store/catalog-shell';
import { EmptyState } from '@/components/store/empty-state';
import { Pagination } from '@/components/store/pagination';
import { ProductGrid } from '@/components/store/product-card';
import { ButtonLink } from '@/components/ui/button';

type Props = { params: Promise<{ collection: string }>; searchParams: Promise<Record<string, string | string[] | undefined>> };

const FILTER_KEYS = ['marca', 'modelo', 'capacidad', 'color', 'estado', 'categoria', 'bateria', 'disponible', 'min', 'max', 'q', 'orden'];

export async function generateMetadata({ params, searchParams }: Props): Promise<Metadata> {
  const { collection } = await params;
  const sp = await searchParams;
  const col = await resolveCollection(collection);
  if (!col) return {};
  const filtered = FILTER_KEYS.some((k) => sp[k]);
  const page = Number(sp.pagina) > 1 ? Number(sp.pagina) : 1;
  const title = sp.q ? `Resultados para “${String(sp.q).slice(0, 60)}”` : `${col.seoTitle ?? col.title}${page > 1 ? ` — Página ${page}` : ''}`;
  return {
    title,
    description: col.seoDescription ?? col.description,
    // Las combinaciones de filtros no se indexan para evitar contenido duplicado.
    alternates: { canonical: page > 1 && !filtered ? `/${col.slug}?pagina=${page}` : `/${col.slug}` },
    robots: filtered ? { index: false, follow: true } : undefined,
    openGraph: { title, description: col.description, url: `/${col.slug}` }
  };
}

export default async function CollectionPage({ params, searchParams }: Props) {
  const { collection } = await params;
  const sp = await searchParams;
  const col = await resolveCollection(collection);
  if (!col) notFound();

  const filters = parseFilters(sp);
  const [result, facets] = await Promise.all([listProducts(col.where, filters), getFacets(col.where)]);

  const labelOf = (list: { value: string; label: string }[], v: string) => list.find((o) => o.value === v)?.label ?? v;
  const chips = [
    ...filters.conditions.map((c) => ({ param: 'estado', value: CONDITION_SLUG[c], label: CONDITION_LABEL[c] })),
    ...filters.categories.map((v) => ({ param: 'categoria', value: v, label: labelOf(facets.categories, v) })),
    ...filters.brands.map((v) => ({ param: 'marca', value: v, label: labelOf(facets.brands, v) })),
    ...filters.models.map((v) => ({ param: 'modelo', value: v, label: v })),
    ...filters.storage.map((v) => ({ param: 'capacidad', value: String(v), label: storageLabel(v)! })),
    ...filters.colors.map((v) => ({ param: 'color', value: v, label: v })),
    ...(filters.batteryMin != null ? [{ param: 'bateria', value: '', label: `Batería ≥ ${filters.batteryMin} %` }] : []),
    ...(filters.available ? [{ param: 'disponible', value: '', label: 'Solo disponibles' }] : []),
    ...(filters.minCents != null ? [{ param: 'min', value: '', label: `Desde ${filters.minCents / 100} €` }] : []),
    ...(filters.maxCents != null ? [{ param: 'max', value: '', label: `Hasta ${filters.maxCents / 100} €` }] : [])
  ];
  const isSearch = !!filters.q;

  return (
    <div className="container-page pt-6 pb-4">
      <Breadcrumbs items={[{ label: col.title, href: `/${col.slug}` }, ...(isSearch ? [{ label: 'Búsqueda' }] : [])]} />
      <header className="mb-7">
        <h1 className="text-[28px] font-bold sm:text-4xl">{isSearch ? `Resultados para “${filters.q}”` : col.title}</h1>
        {!isSearch && col.description && <p className="mt-2 max-w-[70ch] text-muted">{col.description}</p>}
      </header>

      <Suspense>
        <CatalogShell>
          <div className="grid items-start gap-10 lg:grid-cols-[250px_1fr]">
            <div className="flex items-center gap-3 lg:block">
              <CatalogFilters facets={facets} fixed={col.fixed} total={result.total} />
              <div className="flex flex-1 items-center justify-end gap-3 lg:hidden">
                <SortSelect options={SORTS} value={filters.sort} />
              </div>
            </div>
            <section aria-label="Resultados" className="min-w-0">
              <div className="mb-4 flex items-center gap-3">
                <p className="text-sm whitespace-nowrap text-muted" aria-live="polite">{result.total} {result.total === 1 ? 'producto' : 'productos'}</p>
                <div className="ml-auto hidden lg:block"><SortSelect options={SORTS} value={filters.sort} /></div>
              </div>
              <ActiveFilters chips={chips} />
              <CatalogResults>
                {result.items.length ? (
                  <ProductGrid items={result.items} cols={3} />
                ) : (
                  <EmptyState
                    icon={SearchX}
                    title={isSearch && !chips.length ? 'No hemos encontrado resultados' : 'Ningún producto coincide'}
                    text={isSearch && !chips.length ? 'Prueba con otro término, por ejemplo “iPhone 15”, “Galaxy” o “funda”.' : 'Prueba a quitar alguno de los filtros aplicados.'}
                  >
                    <ButtonLink href={`/${col.slug}`}>{isSearch ? 'Ver todo el catálogo' : 'Quitar filtros'}</ButtonLink>
                  </EmptyState>
                )}
              </CatalogResults>
              <Pagination page={result.page} pages={result.pages} basePath={`/${col.slug}`} params={sp} />
            </section>
          </div>
        </CatalogShell>
      </Suspense>
    </div>
  );
}

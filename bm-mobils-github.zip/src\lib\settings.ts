import 'server-only';
import { cache } from 'react';
import { z } from 'zod';
import { db } from './db';

export const PAYMENT_METHOD_OPTIONS = {
  card: 'Tarjeta (Visa, Mastercard)',
  apple_pay: 'Apple Pay',
  google_pay: 'Google Pay',
  paypal: 'PayPal',
  klarna: 'Klarna'
} as const;

export const EMAIL_TEMPLATE_KEYS = {
  orderConfirmation: 'Confirmación de pedido',
  shipped: 'Pedido enviado',
  delivered: 'Pedido entregado',
  cancelled: 'Pedido cancelado',
  refunded: 'Reembolso realizado'
} as const;
export type EmailTemplateKey = keyof typeof EMAIL_TEMPLATE_KEYS;

const DEFAULT_TEMPLATES: Record<EmailTemplateKey, { subject: string; intro: string }> = {
  orderConfirmation: { subject: 'Hemos recibido tu pedido {numero}', intro: 'Gracias por tu compra. Tu pago se ha confirmado y ya estamos preparando tu pedido.' },
  shipped: { subject: 'Tu pedido {numero} está en camino', intro: 'Tu pedido ha salido de nuestro almacén. Puedes seguir el envío con los datos de abajo.' },
  delivered: { subject: 'Tu pedido {numero} se ha entregado', intro: 'El transportista ha confirmado la entrega de tu pedido. ¡Esperamos que lo disfrutes!' },
  cancelled: { subject: 'Tu pedido {numero} se ha cancelado', intro: 'Tu pedido se ha cancelado. Si se realizó algún cargo, se reembolsará por el mismo método de pago.' },
  refunded: { subject: 'Reembolso del pedido {numero}', intro: 'Hemos procesado el reembolso de tu pedido. El plazo en que aparece en tu cuenta depende de tu banco.' }
};

const templatesSchema = z.record(z.string(), z.object({ subject: z.string(), intro: z.string() }));
const bannersSchema = z.array(z.object({ title: z.string(), text: z.string().default(''), href: z.string().default('/'), imageUrl: z.string().optional() }));
const socialSchema = z.object({
  instagram: z.string().optional(),
  facebook: z.string().optional(),
  tiktok: z.string().optional(),
  x: z.string().optional(),
  youtube: z.string().optional()
});

function parse<T>(schema: z.ZodType<T>, value: unknown, fallback: T): T {
  const r = schema.safeParse(value);
  return r.success ? r.data : fallback;
}

export const getSettings = cache(async () => {
  const row = (await db.storeSettings.findUnique({ where: { id: 1 } })) ?? (await db.storeSettings.create({ data: { id: 1 } }));
  const templates = parse(templatesSchema, row.emailTemplates, {});
  return {
    ...row,
    social: parse(socialSchema, row.social, {}),
    infoBar: parse(z.array(z.string()), row.infoBar, []),
    banners: parse(bannersSchema, row.banners, []),
    paymentMethods: parse(z.array(z.string()), row.paymentMethods, ['card']).filter((m): m is keyof typeof PAYMENT_METHOD_OPTIONS => m in PAYMENT_METHOD_OPTIONS),
    emailTemplates: Object.fromEntries(
      (Object.keys(DEFAULT_TEMPLATES) as EmailTemplateKey[]).map((k) => [k, { ...DEFAULT_TEMPLATES[k], ...templates[k] }])
    ) as Record<EmailTemplateKey, { subject: string; intro: string }>
  };
});

export type StoreSettingsView = Awaited<ReturnType<typeof getSettings>>;

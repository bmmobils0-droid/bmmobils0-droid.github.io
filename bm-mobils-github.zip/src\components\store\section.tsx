import Link from 'next/link';
import type { ReactNode } from 'react';
import { ArrowRight } from 'lucide-react';

export function Section({ id, title, subtitle, link, children }: { id: string; title: string; subtitle?: string; link?: { href: string; label: string }; children: ReactNode }) {
  return (
    <section className="pt-14 md:pt-[72px]" aria-labelledby={id}>
      <div className="mb-6 flex items-end justify-between gap-4">
        <div>
          <h2 id={id} className="text-2xl font-bold md:text-[32px]">{title}</h2>
          {subtitle && <p className="mt-1.5 text-muted">{subtitle}</p>}
        </div>
        {link && (
          <Link href={link.href} className="inline-flex items-center gap-1 text-[15px] font-semibold whitespace-nowrap hover:text-brand">
            {link.label}
            <ArrowRight className="size-4" aria-hidden />
          </Link>
        )}
      </div>
      {children}
    </section>
  );
}

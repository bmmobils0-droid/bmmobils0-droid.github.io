export const MAIN_NAV: { href: string; label: string; deal?: boolean }[] = [
  { href: '/moviles', label: 'Móviles' },
  { href: '/iphone', label: 'iPhone' },
  { href: '/samsung', label: 'Samsung' },
  { href: '/reacondicionados', label: 'Reacondicionados' },
  { href: '/segunda-mano', label: 'Segunda mano' },
  { href: '/tablets', label: 'Tablets' },
  { href: '/accesorios', label: 'Accesorios' },
  { href: '/audio', label: 'Audio y wearables' },
  { href: '/ofertas', label: 'Ofertas', deal: true }
];

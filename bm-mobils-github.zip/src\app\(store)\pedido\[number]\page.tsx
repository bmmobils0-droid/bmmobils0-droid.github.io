import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { CircleCheck, Clock, Package, XCircle } from 'lucide-react';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { verifyOrderAccess } from '@/lib/order-access';
import { ORDER_STATUS_LABEL } from '@/lib/order-status';
import { formatPrice } from '@/lib/money';
import { ButtonLink } from '@/components/ui/button';
import { AutoRefresh } from '@/components/auto-refresh';

export const metadata: Metadata = { title: 'Tu pedido', robots: { index: false, follow: false } };

export default async function OrderPage({ params, searchParams }: { params: Promise<{ number: string }>; searchParams: Promise<{ t?: string }> }) {
  const { number } = await params;
  const { t } = await searchParams;
  const order = await db.order.findUnique({
    where: { number },
    include: { items: true, shipments: { orderBy: { shippedAt: 'desc' } } }
  });
  // Solo el titular (por sesión o por enlace firmado) puede ver el pedido. Respuesta idéntica si no existe.
  const user = await getCurrentUser();
  if (!order || !(verifyOrderAccess(order.id, t) || (user && order.userId === user.id))) notFound();

  const waiting = order.status === 'PENDING_PAYMENT';
  const Icon = order.status === 'CANCELLED' ? XCircle : waiting ? Clock : order.status === 'SHIPPED' || order.status === 'DELIVERED' ? Package : CircleCheck;
  const heading = waiting
    ? order.paymentStatus === 'FAILED' ? 'El pago no se ha completado' : 'Estamos confirmando tu pago…'
    : order.status === 'CANCELLED' ? 'Pedido cancelado' : order.status === 'REFUNDED' ? 'Pedido reembolsado' : '¡Gracias por tu pedido!';

  return (
    <div className="container-page max-w-2xl pt-10 text-center">
      {waiting && <AutoRefresh seconds={4} />}
      <div className={`mx-auto mb-5 grid size-16 place-items-center rounded-full ${order.status === 'CANCELLED' ? 'bg-danger-soft text-danger' : waiting ? 'bg-warn-soft text-warn' : 'bg-ok-soft text-ok'}`}>
        <Icon className="size-7" aria-hidden />
      </div>
      <h1 className="text-[28px] font-bold sm:text-[32px]">{heading}</h1>
      <p className="mt-2.5 text-ink-2">
        Pedido <strong>{order.number}</strong> · {ORDER_STATUS_LABEL[order.status]}
        {order.paidAt && <> · Te hemos enviado la confirmación a <strong>{order.email}</strong></>}
      </p>
      {waiting && <p className="mt-2 text-sm text-muted">Esta página se actualiza sola. Si has pagado, la confirmación llega en unos segundos.</p>}
      {order.requiresTaxReview && order.paidAt && <p className="mt-4 rounded-xl bg-warn-soft p-3 text-sm text-[#6b3e00]">Envío a Canarias, Ceuta o Melilla: te contactaremos para confirmar las condiciones fiscales y aduaneras.</p>}

      {order.shipments.length > 0 && (
        <div className="mt-6 rounded-card border border-line p-4 text-left text-sm">
          {order.shipments.map((s) => (
            <p key={s.id}><strong>{s.carrier}</strong> · {s.trackingNumber}{s.trackingUrl && <> · <a href={s.trackingUrl} target="_blank" rel="noopener noreferrer" className="text-brand underline">Seguir envío</a></>}</p>
          ))}
        </div>
      )}

      <section className="mt-8 flex flex-col gap-2.5 rounded-card bg-soft p-6 text-left" aria-label="Resumen">
        <h2 className="mb-1 text-lg font-semibold">Resumen</h2>
        <ul className="divide-y divide-line-strong">
          {order.items.map((i) => (
            <li key={i.id} className="flex justify-between gap-3 py-2.5 text-sm">
              <span><span className="font-semibold">{i.productName}</span><span className="block text-[12.5px] text-muted">{i.variantLabel} × {i.quantity}</span></span>
              <span className="font-semibold whitespace-nowrap">{formatPrice(i.lineTotalCents)}</span>
            </li>
          ))}
        </ul>
        <div className="flex justify-between text-[14.5px] text-ink-2"><span>Subtotal</span><span>{formatPrice(order.subtotalCents)}</span></div>
        {order.discountCents > 0 && <div className="flex justify-between text-[14.5px] text-ok"><span>Descuento</span><span>−{formatPrice(order.discountCents)}</span></div>}
        <div className="flex justify-between text-[14.5px] text-ink-2"><span>{order.shippingMethod}</span><span>{order.shippingCents === 0 ? 'Gratis' : formatPrice(order.shippingCents)}</span></div>
        <div className="flex justify-between border-t border-line-strong pt-3 text-lg font-bold"><span>Total</span><span>{formatPrice(order.totalCents)}</span></div>
        <p className="text-[12.5px] text-muted">IVA incluido ({formatPrice(order.taxCents)}). Entrega: {order.shipFirstName} {order.shipLastName}, {order.shipLine1}{order.shipLine2 ? `, ${order.shipLine2}` : ''}, {order.shipPostalCode} {order.shipCity} ({order.shipProvince}).</p>
      </section>

      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <ButtonLink href="/">Seguir comprando</ButtonLink>
        {user ? <ButtonLink href="/cuenta" variant="outline">Mis pedidos</ButtonLink> : <Link href="/contacto" className="self-center text-sm font-medium text-brand hover:underline">¿Necesitas ayuda?</Link>}
      </div>
    </div>
  );
}

import type { Metadata } from 'next';
import Link from 'next/link';
import { ChevronRight, Package } from 'lucide-react';
import { requireUser } from '@/lib/auth';
import { db } from '@/lib/db';
import { can } from '@/lib/permissions';
import { ORDER_STATUS_LABEL } from '@/lib/order-status';
import { formatPrice } from '@/lib/money';
import { logoutAction } from '@/app/actions/auth';
import { Button, ButtonLink } from '@/components/ui/button';
import { EmptyState } from '@/components/store/empty-state';

export const metadata: Metadata = { title: 'Mi cuenta', robots: { index: false } };

export default async function AccountPage() {
  const user = await requireUser('/cuenta');
  // Cada cliente solo ve sus propios pedidos.
  const orders = await db.order.findMany({
    // Se ocultan los intentos de pago abandonados (cancelados sin llegar a cobrarse).
    where: { userId: user.id, NOT: { status: 'CANCELLED', paymentStatus: 'CANCELLED' } },
    orderBy: { createdAt: 'desc' },
    select: { id: true, number: true, status: true, totalCents: true, createdAt: true, _count: { select: { items: true } } },
    take: 50
  });
  const date = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <div className="container-page pt-10">
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Mi cuenta</h1>
          <p className="mt-1 text-muted">{user.name} · {user.email}</p>
        </div>
        <div className="flex gap-2">
          {can(user.role, 'admin:access') && <ButtonLink href="/admin" variant="outline" size="sm">Panel de administración</ButtonLink>}
          <form action={logoutAction}><Button type="submit" variant="ghost" size="sm">Cerrar sesión</Button></form>
        </div>
      </div>
      <h2 className="mb-4 text-xl font-semibold">Mis pedidos</h2>
      {orders.length === 0 ? (
        <EmptyState icon={Package} title="Todavía no tienes pedidos" text="Cuando compres, podrás seguir aquí el estado de tus pedidos."><ButtonLink href="/moviles">Ver móviles</ButtonLink></EmptyState>
      ) : (
        <ul className="divide-y divide-line rounded-card border border-line">
          {orders.map((o) => (
            <li key={o.id}>
              <Link href={`/pedido/${o.number}`} className="flex items-center justify-between gap-4 p-4 hover:bg-soft">
                <span>
                  <strong className="block">Pedido {o.number}</strong>
                  <span className="text-[13px] text-muted">{date.format(o.createdAt)} · {o._count.items} {o._count.items === 1 ? 'producto' : 'productos'} · {ORDER_STATUS_LABEL[o.status]}</span>
                </span>
                <span className="flex items-center gap-2 font-semibold">{formatPrice(o.totalCents)}<ChevronRight className="size-4 text-muted" aria-hidden /></span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

import Link from 'next/link';
import { requirePermission } from '@/lib/auth';
import { db } from '@/lib/db';
import { PageHeader, Table } from '@/components/admin/ui';
import { Badge } from '@/components/ui/badge';

export const metadata = { title: 'Páginas' };

export default async function PagesPage() {
  await requirePermission('content:manage');
  const pages = await db.page.findMany({ orderBy: { title: 'asc' } });
  const date = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', year: 'numeric' });
  return (
    <>
      <PageHeader title="Páginas legales e informativas" subtitle="Los textos legales son plantillas: complétalos y revísalos con un asesor antes de vender." />
      <Table>
        <thead><tr><th>Página</th><th>URL</th><th>Estado</th><th>Actualizada</th></tr></thead>
        <tbody>
          {pages.map((p) => (
            <tr key={p.id}>
              <td><Link href={`/admin/paginas/${p.slug}`} className="font-semibold hover:underline">{p.title}</Link></td>
              <td className="font-mono text-xs text-muted">/info/{p.slug}</td>
              <td>{p.needsLegalReview ? <Badge tone="warn">Pendiente de revisión</Badge> : <Badge tone="ok">Revisada</Badge>}</td>
              <td>{date.format(p.updatedAt)}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </>
  );
}

import { db } from '@/lib/db';
import { cardInclude, PUBLIC_PRODUCT, toCard } from '@/lib/catalog/queries';

export const dynamic = 'force-dynamic';

/** Tarjetas de producto públicas por slug (usado por la página de favoritos). */
export async function GET(req: Request) {
  const slugs = (new URL(req.url).searchParams.get('slugs') ?? '').split(',').map((s) => s.trim()).filter((s) => /^[a-z0-9-]{1,140}$/.test(s)).slice(0, 100);
  if (!slugs.length) return Response.json({ items: [] });
  const rows = await db.product.findMany({ where: { AND: [PUBLIC_PRODUCT, { slug: { in: slugs } }] }, include: cardInclude });
  const order = new Map(slugs.map((s, i) => [s, i]));
  return Response.json({ items: rows.map(toCard).sort((a, b) => order.get(a.slug)! - order.get(b.slug)!) });
}

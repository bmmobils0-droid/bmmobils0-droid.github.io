'use server';

import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { adminAction, UserError, type ActionResult } from '@/lib/admin-action';
import { db } from '@/lib/db';
import { addShipment, requestRefund, updateOrderStatus } from '@/lib/orders';
import { shipmentSchema } from '@/lib/validators';

const orderId = z.string().min(1).max(64);

export async function changeOrderStatusAction(fd: FormData): Promise<ActionResult> {
  return adminAction('orders:update', async (user) => {
    const id = orderId.parse(fd.get('orderId'));
    const to = z.enum(['PREPARING', 'DELIVERED', 'CANCELLED']).parse(fd.get('to'));
    const note = z.string().trim().max(300).optional().parse(fd.get('note') || undefined);
    await updateOrderStatus(id, to, user.id, note);
    revalidatePath(`/admin/pedidos/${id}`);
    return { ok: true, message: 'Estado del pedido actualizado.' };
  });
}

export async function addShipmentAction(fd: FormData): Promise<ActionResult> {
  return adminAction('orders:update', async (user) => {
    const id = orderId.parse(fd.get('orderId'));
    const parsed = shipmentSchema.safeParse({ carrier: fd.get('carrier'), trackingNumber: fd.get('trackingNumber'), trackingUrl: fd.get('trackingUrl') ?? '' });
    if (!parsed.success) throw new UserError(parsed.error.issues[0].message);
    await addShipment(id, parsed.data, user.id);
    revalidatePath(`/admin/pedidos/${id}`);
    return { ok: true, message: 'Envío registrado. Se ha avisado al cliente.' };
  });
}

export async function refundOrderAction(fd: FormData): Promise<ActionResult> {
  return adminAction('orders:refund', async (user) => {
    const id = orderId.parse(fd.get('orderId'));
    const raw = String(fd.get('amount') ?? '').trim().replace(',', '.');
    const amountCents = raw ? Math.round(Number(raw) * 100) : undefined;
    if (raw && !Number.isFinite(amountCents)) throw new UserError('Importe no válido.');
    await requestRefund(id, user.id, amountCents);
    revalidatePath(`/admin/pedidos/${id}`);
    return { ok: true, message: 'Reembolso solicitado a Stripe. El estado cambiará cuando Stripe lo confirme.' };
  });
}

export async function addOrderNoteAction(fd: FormData): Promise<ActionResult> {
  return adminAction('orders:update', async (user) => {
    const id = orderId.parse(fd.get('orderId'));
    const message = z.string().trim().min(2, { error: 'Escribe la nota.' }).max(500).parse(fd.get('message'));
    await db.orderEvent.create({ data: { orderId: id, actorId: user.id, message: `Nota interna: ${message}` } });
    revalidatePath(`/admin/pedidos/${id}`);
    return { ok: true, message: 'Nota añadida.' };
  });
}

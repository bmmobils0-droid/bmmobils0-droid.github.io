import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requirePermission } from '@/lib/auth';
import { db } from '@/lib/db';
import { renderLightMarkdown } from '@/lib/markdown';
import { savePageAction } from '@/app/admin/actions/settings';
import { ActionForm } from '@/components/admin/action-form';
import { Card, PageHeader } from '@/components/admin/ui';
import { Button } from '@/components/ui/button';
import { Checkbox, Field, Input, Textarea } from '@/components/ui/field';

export const metadata = { title: 'Editar página' };

export default async function EditPagePage({ params }: { params: Promise<{ slug: string }> }) {
  await requirePermission('content:manage');
  const { slug } = await params;
  const page = await db.page.findUnique({ where: { slug } });
  if (!page) notFound();
  return (
    <>
      <PageHeader title={page.title} subtitle={<Link href={`/info/${page.slug}`} target="_blank" className="text-brand hover:underline">Ver en la tienda</Link>} />
      <div className="grid gap-4 xl:grid-cols-2">
        <Card title="Contenido">
          <ActionForm action={savePageAction} className="space-y-4">
            <input type="hidden" name="slug" value={page.slug} />
            <Field label="Título" htmlFor="pg-title"><Input id="pg-title" name="title" defaultValue={page.title} /></Field>
            <Field label="Texto" htmlFor="pg-content" hint="Formato: ## Título, ### Subtítulo, - elemento de lista, **negrita**, [texto](/ruta o https://…). Busca [PENDIENTE] para ver lo que falta.">
              <Textarea id="pg-content" name="content" rows={24} className="font-mono text-[13px]" defaultValue={page.content} />
            </Field>
            <Checkbox name="needsLegalReview" defaultChecked={page.needsLegalReview} label="Pendiente de revisión legal" />
            <Button type="submit" size="sm">Guardar página</Button>
          </ActionForm>
        </Card>
        <Card title="Vista previa (al guardar)">
          <article className="prose-bm" dangerouslySetInnerHTML={{ __html: renderLightMarkdown(page.content) }} />
        </Card>
      </div>
    </>
  );
}

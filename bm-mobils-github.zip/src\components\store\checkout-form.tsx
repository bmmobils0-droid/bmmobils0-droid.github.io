'use client';

import { useEffect, useMemo, useState, useTransition } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import type { z } from 'zod';
import { Info, Lock } from 'lucide-react';
import { cancelPendingCheckoutAction, checkoutAction } from '@/app/actions/checkout';
import { POSTAL_CODE_RE, PROVINCES, provinceFromPostalCode, requiresTaxReview, zoneForPostalCode } from '@/lib/geo';
import { computeTotals, type CouponRule } from '@/lib/pricing';
import { formatPrice } from '@/lib/money';
import { checkoutSchema } from '@/lib/validators';
import type { ShippingZone } from '@/generated/prisma/enums';
import { Checkbox, Field, Input, Select, Textarea } from '../ui/field';
import { Button } from '../ui/button';
import { useToast } from '../toast';
import { ProductVisual, type ArtSpec } from '../device-art';

type Rate = { id: string; name: string; description: string | null; priceCents: number; freeFromCents: number | null; zones: ShippingZone[] };
type Line = { itemId: string; name: string; label: string; quantity: number; unitPriceCents: number; lineTotalCents: number; taxRate: number; image: { url: string; alt: string } | null; art: ArtSpec };
type In = z.input<typeof checkoutSchema>;
type Out = z.output<typeof checkoutSchema>;

export function CheckoutForm({ lines, rates, coupon, shippingTaxRate, defaults, paymentsEnabled, cancelled }: {
  lines: Line[]; rates: Rate[]; coupon: (CouponRule & { code: string }) | null; shippingTaxRate: number;
  defaults: Partial<In>; paymentsEnabled: boolean; cancelled: boolean;
}) {
  const { show } = useToast();
  const [pending, start] = useTransition();
  const [formError, setFormError] = useState<string | null>(null);
  const { register, handleSubmit, setValue, setError, control, formState: { errors } } = useForm<In, unknown, Out>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: { country: 'ES', wantsInvoice: false, shippingRateId: '', province: '', ...defaults },
    mode: 'onTouched'
  });

  useEffect(() => { if (cancelled) cancelPendingCheckoutAction(); }, [cancelled]);

  const postalCode = useWatch({ control, name: 'postalCode' }) ?? '';
  const rateId = useWatch({ control, name: 'shippingRateId' });
  const wantsInvoice = useWatch({ control, name: 'wantsInvoice' });
  const validCp = POSTAL_CODE_RE.test(postalCode);
  const zone = validCp ? zoneForPostalCode(postalCode) : null;
  const zoneRates = useMemo(() => (zone ? rates.filter((r) => r.zones.includes(zone)) : []), [rates, zone]);

  useEffect(() => {
    const province = provinceFromPostalCode(postalCode);
    if (province) setValue('province', province, { shouldValidate: true });
  }, [postalCode, setValue]);
  useEffect(() => {
    if (zoneRates.length && !zoneRates.some((r) => r.id === rateId)) setValue('shippingRateId', zoneRates[0].id);
    if (!zoneRates.length && rateId) setValue('shippingRateId', '');
  }, [zoneRates, rateId, setValue]);

  const rate = zoneRates.find((r) => r.id === rateId) ?? null;
  const totals = computeTotals({ lines, coupon, shipping: rate, shippingTaxRate });

  const onSubmit = (data: Out) =>
    start(async () => {
      setFormError(null);
      const res = await checkoutAction(data);
      if (res.ok) { window.location.assign(res.url); return; }
      setFormError(res.message);
      show(res.message, { tone: 'error' });
      for (const [k, msg] of Object.entries(res.fieldErrors ?? {})) setError(k as keyof In, { message: msg });
    });

  const err = (k: keyof In) => (errors[k]?.message as string | undefined);
  const aria = (k: keyof In) => ({ 'aria-invalid': !!errors[k], 'aria-describedby': errors[k] ? `f-${k}-error` : undefined });

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="grid items-start gap-10 lg:grid-cols-[1fr_400px] lg:gap-12">
      <div>
        {cancelled && <p className="mb-6 flex gap-2.5 rounded-xl bg-warn-soft p-3.5 text-sm text-[#6b3e00]"><Info className="mt-0.5 size-4 flex-none" aria-hidden />No se ha completado el pago. Tu carrito sigue disponible: puedes intentarlo de nuevo.</p>}
        {!paymentsEnabled && <p className="mb-6 flex gap-2.5 rounded-xl bg-warn-soft p-3.5 text-sm text-[#6b3e00]"><Info className="mt-0.5 size-4 flex-none" aria-hidden />Los pagos online todavía no están activados en esta tienda.</p>}

        <Step n={1} title="Contacto">
          <div className="grid gap-3.5 sm:grid-cols-2">
            <Field label="Email" htmlFor="f-email" error={err('email')}><Input id="f-email" type="email" autoComplete="email" inputMode="email" {...register('email')} {...aria('email')} /></Field>
            <Field label="Teléfono" htmlFor="f-phone" error={err('phone')} hint="Para avisos de la entrega."><Input id="f-phone" type="tel" autoComplete="tel" inputMode="tel" placeholder="600 000 000" {...register('phone')} {...aria('phone')} /></Field>
          </div>
        </Step>

        <Step n={2} title="Dirección de envío">
          <div className="grid gap-3.5 sm:grid-cols-2">
            <Field label="Nombre" htmlFor="f-firstName" error={err('firstName')}><Input id="f-firstName" autoComplete="given-name" {...register('firstName')} {...aria('firstName')} /></Field>
            <Field label="Apellidos" htmlFor="f-lastName" error={err('lastName')}><Input id="f-lastName" autoComplete="family-name" {...register('lastName')} {...aria('lastName')} /></Field>
            <Field label="Dirección" htmlFor="f-line1" error={err('line1')} className="sm:col-span-2"><Input id="f-line1" autoComplete="address-line1" placeholder="Calle y número" {...register('line1')} {...aria('line1')} /></Field>
            <Field label="Piso, puerta, escalera" htmlFor="f-line2" optional className="sm:col-span-2"><Input id="f-line2" autoComplete="address-line2" {...register('line2')} /></Field>
            <Field label="Código postal" htmlFor="f-postalCode" error={err('postalCode')}><Input id="f-postalCode" autoComplete="postal-code" inputMode="numeric" maxLength={5} {...register('postalCode')} {...aria('postalCode')} /></Field>
            <Field label="Ciudad" htmlFor="f-city" error={err('city')}><Input id="f-city" autoComplete="address-level2" {...register('city')} {...aria('city')} /></Field>
            <Field label="Provincia" htmlFor="f-province" error={err('province')}>
              <Select id="f-province" autoComplete="address-level1" {...register('province')} {...aria('province')}>
                <option value="">Selecciona…</option>
                {PROVINCES.map((p) => <option key={p}>{p}</option>)}
              </Select>
            </Field>
            <Field label="País" htmlFor="f-country" hint="Por ahora enviamos solo a España.">
              <Select id="f-country" autoComplete="country" {...register('country')}><option value="ES">España</option></Select>
            </Field>
          </div>
          {zone && requiresTaxReview(zone) && (
            <p className="mt-4 flex gap-2.5 rounded-xl bg-warn-soft p-3.5 text-[13.5px] text-[#6b3e00]">
              <Info className="mt-0.5 size-4 flex-none" aria-hidden />
              Canarias, Ceuta y Melilla tienen un régimen fiscal distinto y los envíos pueden estar sujetos a trámites aduaneros. Te contactaremos para confirmar las condiciones antes de enviar.
            </p>
          )}
          <div className="mt-5">
            <Checkbox label="Necesito factura con datos de empresa o distintos a los de envío" {...register('wantsInvoice')} />
          </div>
          {wantsInvoice && (
            <div className="mt-4 grid gap-3.5 rounded-card border border-line p-4 sm:grid-cols-2">
              <Field label="Nombre o razón social" htmlFor="f-billingName" error={err('billingName')}><Input id="f-billingName" autoComplete="organization" {...register('billingName')} {...aria('billingName')} /></Field>
              <Field label="NIF / NIE / CIF" htmlFor="f-billingTaxId" error={err('billingTaxId')}><Input id="f-billingTaxId" {...register('billingTaxId')} {...aria('billingTaxId')} /></Field>
              <Field label="Dirección de facturación" htmlFor="f-billingLine1" error={err('billingLine1')} className="sm:col-span-2"><Input id="f-billingLine1" {...register('billingLine1')} {...aria('billingLine1')} /></Field>
              <Field label="Código postal" htmlFor="f-billingPostalCode" error={err('billingPostalCode')}><Input id="f-billingPostalCode" inputMode="numeric" maxLength={5} {...register('billingPostalCode')} {...aria('billingPostalCode')} /></Field>
              <Field label="Ciudad" htmlFor="f-billingCity" error={err('billingCity')}><Input id="f-billingCity" {...register('billingCity')} {...aria('billingCity')} /></Field>
              <Field label="Provincia" htmlFor="f-billingProvince" optional className="sm:col-span-2">
                <Select id="f-billingProvince" {...register('billingProvince')}><option value="">Selecciona…</option>{PROVINCES.map((p) => <option key={p}>{p}</option>)}</Select>
              </Field>
            </div>
          )}
        </Step>

        <Step n={3} title="Método de envío">
          {!validCp ? (
            <p className="text-sm text-muted">Introduce tu código postal para ver los métodos de envío disponibles.</p>
          ) : zoneRates.length === 0 ? (
            <p className="rounded-xl bg-danger-soft p-3.5 text-sm text-danger">No hay métodos de envío configurados para tu zona. Contacta con nosotros.</p>
          ) : (
            <div className="space-y-2.5" role="radiogroup" aria-label="Método de envío">
              {zoneRates.map((r) => {
                const cost = computeTotals({ lines, coupon, shipping: r, shippingTaxRate }).shippingCents;
                return (
                  <label key={r.id} className="flex cursor-pointer items-center gap-3.5 rounded-xl border-[1.5px] border-line-strong p-4 transition hover:border-ink-2 has-[:checked]:border-ink has-[:checked]:bg-[#fafafa] has-[:checked]:shadow-[inset_0_0_0_1px_var(--color-ink)]">
                    <input type="radio" value={r.id} {...register('shippingRateId')} className="size-[18px] accent-ink" />
                    <span className="flex-1"><strong className="block text-[14.5px] font-semibold">{r.name}</strong>{r.description && <small className="text-[13px] text-muted">{r.description}</small>}</span>
                    <span className="text-[14.5px] font-semibold">{cost === 0 ? 'Gratis' : formatPrice(cost)}</span>
                  </label>
                );
              })}
            </div>
          )}
          {err('shippingRateId') && <p className="mt-2 text-[12.5px] text-danger">{err('shippingRateId')}</p>}
        </Step>

        <Step n={4} title="Pago" last>
          <p className="flex gap-2.5 rounded-xl bg-brand-soft p-3.5 text-[13.5px] text-[#1d2f6f]">
            <Lock className="mt-0.5 size-4 flex-none" aria-hidden />
            Al continuar irás a la pasarela segura de Stripe para pagar con tarjeta u otros métodos disponibles. No almacenamos los datos de tu tarjeta.
          </p>
          <div className="mt-5">
            <Field label="Notas del pedido" htmlFor="f-customerNote" optional><Textarea id="f-customerNote" rows={3} className="min-h-0" {...register('customerNote')} /></Field>
          </div>
          <div className="mt-5">
            <Checkbox
              label={<>He leído y acepto las <a href="/info/condiciones" target="_blank" className="text-brand underline">condiciones de venta</a> y la <a href="/info/privacidad" target="_blank" className="text-brand underline">política de privacidad</a>.</>}
              {...register('acceptTerms')}
              aria-invalid={!!errors.acceptTerms}
            />
            {err('acceptTerms') && <p className="mt-1.5 text-[12.5px] text-danger" role="alert">{err('acceptTerms')}</p>}
          </div>
        </Step>
      </div>

      <aside className="flex flex-col gap-3 rounded-card bg-soft p-6 lg:sticky lg:top-[136px]" aria-label="Resumen del pedido">
        <h2 className="mb-1 text-lg font-semibold">Tu pedido</h2>
        <ul className="mb-1 max-h-80 divide-y divide-line-strong overflow-auto">
          {lines.map((l) => (
            <li key={l.itemId} className="grid grid-cols-[56px_1fr] gap-3 py-2.5">
              <span className="relative block size-14 rounded-[10px] bg-white">
                <ProductVisual image={l.image} art={l.art} view={l.art.type === 'phone' ? 'back' : undefined} alt="" sizes="56px" className="size-full overflow-hidden rounded-[10px]" />
                <span className="absolute -top-1.5 -right-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-ink-2 px-1 text-[11px] font-bold text-white">{l.quantity}</span>
              </span>
              <span className="min-w-0">
                <span className="flex justify-between gap-2 text-sm"><span className="font-semibold">{l.name}</span><span className="font-semibold whitespace-nowrap">{formatPrice(l.lineTotalCents)}</span></span>
                <span className="block text-[12.5px] text-muted">{l.label}</span>
              </span>
            </li>
          ))}
        </ul>
        <Row label="Subtotal" value={formatPrice(totals.subtotalCents)} />
        {totals.discountCents > 0 && <Row label={`Descuento (${coupon?.code})`} value={`−${formatPrice(totals.discountCents)}`} className="text-ok" />}
        <Row label="Envío" value={rate ? (totals.shippingCents === 0 ? 'Gratis' : formatPrice(totals.shippingCents)) : '—'} />
        <div className="mt-1 flex justify-between border-t border-line-strong pt-3 text-lg font-bold"><span>Total</span><span>{formatPrice(totals.totalCents)}</span></div>
        <p className="text-[12.5px] text-muted">IVA incluido ({formatPrice(totals.taxCents)}).</p>
        {formError && <p className="rounded-xl bg-danger-soft p-3 text-sm text-danger" role="alert">{formError}</p>}
        <Button type="submit" size="lg" className="w-full" disabled={pending || !paymentsEnabled}>
          {pending ? 'Preparando el pago…' : `Pagar ${formatPrice(totals.totalCents)}`}
        </Button>
        <p className="flex items-center justify-center gap-2 text-[12.5px] text-muted"><Lock className="size-3.5" aria-hidden />Pago seguro con Stripe</p>
      </aside>
    </form>
  );
}

function Step({ n, title, last, children }: { n: number; title: string; last?: boolean; children: React.ReactNode }) {
  return (
    <section className={last ? 'pt-7' : 'border-b border-line py-7 first:pt-0'}>
      <h2 className="mb-4.5 flex items-center gap-3 text-xl font-semibold"><span className="grid size-7 place-items-center rounded-full bg-ink text-[13px] font-bold text-white">{n}</span>{title}</h2>
      {children}
    </section>
  );
}

function Row({ label, value, className }: { label: string; value: string; className?: string }) {
  return <div className={`flex justify-between text-[14.5px] text-ink-2 ${className ?? ''}`}><span>{label}</span><span>{value}</span></div>;
}

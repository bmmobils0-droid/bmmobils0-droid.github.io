import Link from 'next/link';
import type { ComponentProps } from 'react';
import { cn } from '@/lib/cn';

type Variant = 'primary' | 'brand' | 'outline' | 'ghost' | 'danger' | 'link';
type Size = 'sm' | 'md' | 'lg';

const VARIANTS: Record<Variant, string> = {
  primary: 'bg-ink text-white hover:bg-[#2a2c33] hover:shadow-card',
  brand: 'bg-brand text-white hover:bg-brand-ink',
  outline: 'border border-line-strong bg-white text-ink hover:border-ink',
  ghost: 'text-ink hover:bg-soft',
  danger: 'bg-danger text-white hover:bg-[#912018]',
  link: 'text-brand underline-offset-2 hover:underline !px-0 !h-auto'
};
const SIZES: Record<Size, string> = { sm: 'h-9 px-3.5 text-sm', md: 'h-11 px-5 text-[15px]', lg: 'h-13 px-6 text-base' };

export function buttonClass(variant: Variant = 'primary', size: Size = 'md', extra?: string) {
  return cn(
    'inline-flex items-center justify-center gap-2 rounded-full font-semibold whitespace-nowrap transition duration-150 active:scale-[.98] disabled:pointer-events-none disabled:opacity-45',
    VARIANTS[variant],
    SIZES[size],
    extra
  );
}

export function Button({ variant, size, className, type = 'button', ...props }: ComponentProps<'button'> & { variant?: Variant; size?: Size }) {
  return <button type={type} className={buttonClass(variant, size, className)} {...props} />;
}

export function ButtonLink({ variant, size, className, ...props }: ComponentProps<typeof Link> & { variant?: Variant; size?: Size }) {
  return <Link className={buttonClass(variant, size, className)} {...props} />;
}

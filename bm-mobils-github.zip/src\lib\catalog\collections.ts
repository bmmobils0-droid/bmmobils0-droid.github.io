import 'server-only';
import { cache } from 'react';
import type { Prisma } from '@/generated/prisma/client';
import { db } from '../db';

export type Collection = {
  slug: string;
  title: string;
  description: string;
  seoTitle?: string | null;
  seoDescription?: string | null;
  where: Prisma.ProductWhereInput;
  /** Oculta el filtro de marca/estado cuando la colección ya lo fija. */
  fixed?: { brand?: boolean; condition?: boolean };
};

const inCategory = (slug: string): Prisma.ProductWhereInput => ({ category: { OR: [{ slug }, { parent: { slug } }] } });

const STATIC: Record<string, Omit<Collection, 'slug'>> = {
  catalogo: { title: 'Catálogo', description: 'Todos los productos de BM Mobils.', where: {} },
  moviles: {
    title: 'Móviles',
    description: 'Smartphones nuevos, reacondicionados y de segunda mano de las principales marcas.',
    seoTitle: 'Comprar móviles nuevos, reacondicionados y de segunda mano',
    where: inCategory('moviles')
  },
  iphone: {
    title: 'iPhone',
    description: 'iPhone nuevos, reacondicionados y de segunda mano.',
    seoTitle: 'Comprar iPhone nuevo, reacondicionado o de segunda mano',
    where: { AND: [inCategory('moviles'), { brand: { slug: 'apple' } }] },
    fixed: { brand: true }
  },
  samsung: {
    title: 'Samsung',
    description: 'Móviles, tablets y accesorios Samsung Galaxy.',
    seoTitle: 'Comprar móviles Samsung Galaxy',
    where: { brand: { slug: 'samsung' } },
    fixed: { brand: true }
  },
  reacondicionados: {
    title: 'Reacondicionados',
    description: 'Dispositivos revisados y clasificados según su estado estético.',
    seoTitle: 'Móviles reacondicionados',
    where: { condition: 'REFURBISHED' },
    fixed: { condition: true }
  },
  'segunda-mano': {
    title: 'Segunda mano',
    description: 'Móviles de segunda mano. Cada ficha describe el estado de la unidad.',
    seoTitle: 'Móviles de segunda mano',
    where: { condition: 'USED' },
    fixed: { condition: true }
  },
  tablets: { title: 'Tablets', description: 'iPad, Galaxy Tab, Xiaomi Pad y más.', where: inCategory('tablets') },
  accesorios: { title: 'Fundas y accesorios', description: 'Fundas, protectores de pantalla, cargadores y cables.', where: inCategory('accesorios') },
  audio: { title: 'Audio y wearables', description: 'Auriculares, smartwatches y pulseras de actividad.', where: inCategory('audio-y-wearables') },
  ofertas: {
    title: 'Ofertas',
    description: 'Productos con precio rebajado respecto a su precio de referencia.',
    seoTitle: 'Ofertas en móviles y accesorios',
    where: { maxDiscountPct: { gt: 0 } }
  }
};

export const STATIC_COLLECTION_SLUGS = Object.keys(STATIC);

/** Resuelve una URL de primer nivel (/moviles, /iphone, /<categoria>, /<marca>). */
export const resolveCollection = cache(async (slug: string): Promise<Collection | null> => {
  const s = STATIC[slug];
  if (s) return { slug, ...s };
  const category = await db.category.findUnique({ where: { slug } });
  if (category) {
    return {
      slug,
      title: category.name,
      description: category.description ?? '',
      seoTitle: category.seoTitle,
      seoDescription: category.seoDescription,
      where: inCategory(slug)
    };
  }
  const brand = await db.brand.findUnique({ where: { slug } });
  if (brand) {
    return { slug, title: brand.name, description: `Productos ${brand.name} en BM Mobils.`, where: { brandId: brand.id }, fixed: { brand: true } };
  }
  return null;
});

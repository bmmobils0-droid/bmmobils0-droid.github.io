import 'server-only';
import { cache } from 'react';
import { cookies, headers } from 'next/headers';
import { redirect } from 'next/navigation';
import bcrypt from 'bcryptjs';
import { db } from './db';
import { hashToken, randomToken } from './crypto';
import { can, type Permission } from './permissions';

export const SESSION_COOKIE = 'bm_session';
const SESSION_DAYS = 30;
// Hash con el que se compara cuando el usuario no existe, para no revelar por el tiempo de respuesta si el email está registrado.
let dummyHash: string | undefined;
const getDummyHash = () => (dummyHash ??= bcrypt.hashSync('bm-mobils-dummy-password', 12));

export function hashPassword(password: string) {
  return bcrypt.hash(password, 12);
}

export async function verifyCredentials(email: string, password: string) {
  const user = await db.user.findUnique({ where: { email: email.toLowerCase().trim() } });
  const ok = await bcrypt.compare(password, user?.passwordHash ?? getDummyHash());
  if (!user || !ok || user.disabled) return null;
  return user;
}

export async function createSession(userId: string) {
  const token = randomToken();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400_000);
  const ua = (await headers()).get('user-agent')?.slice(0, 200) ?? null;
  await db.session.create({ data: { id: hashToken(token), userId, expiresAt, userAgent: ua } });
  await db.user.update({ where: { id: userId }, data: { lastLoginAt: new Date() } });
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    expires: expiresAt
  });
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) await db.session.deleteMany({ where: { id: hashToken(token) } });
  jar.delete(SESSION_COOKIE);
}

/** Usuario de la sesión actual (o null). Se resuelve una vez por petición. */
export const getCurrentUser = cache(async () => {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const session = await db.session.findUnique({
    where: { id: hashToken(token) },
    include: { user: { select: { id: true, email: true, name: true, role: true, disabled: true, phone: true } } }
  });
  if (!session || session.expiresAt < new Date() || session.user.disabled) return null;
  return session.user;
});

export type CurrentUser = NonNullable<Awaited<ReturnType<typeof getCurrentUser>>>;

export async function requireUser(next = '/cuenta') {
  const user = await getCurrentUser();
  if (!user) redirect(`/cuenta/acceso?next=${encodeURIComponent(next)}`);
  return user;
}

/** Para páginas del panel: redirige al login si no hay permiso. */
export async function requirePermission(permission: Permission) {
  const user = await getCurrentUser();
  if (!user) redirect('/admin/login');
  if (!can(user.role, permission)) redirect('/admin?sin-permiso=1');
  return user;
}

/** Para server actions: lanza un error en vez de redirigir. */
export async function assertPermission(permission: Permission) {
  const user = await getCurrentUser();
  if (!user || !can(user.role, permission)) throw new Error('No tienes permiso para realizar esta acción.');
  return user;
}

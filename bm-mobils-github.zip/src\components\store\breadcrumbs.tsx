import Link from 'next/link';
import { ChevronRight } from 'lucide-react';
import { absoluteUrl } from '@/lib/site';
import { JsonLd } from './json-ld';

export function Breadcrumbs({ items }: { items: { label: string; href?: string }[] }) {
  const all = [{ label: 'Inicio', href: '/' }, ...items];
  return (
    <>
      <nav aria-label="Ruta de navegación" className="mb-5 flex flex-wrap items-center gap-1.5 text-[13px] text-muted">
        {all.map((it, i) => (
          <span key={i} className="inline-flex items-center gap-1.5">
            {i > 0 && <ChevronRight className="size-3.5" aria-hidden />}
            {it.href && i < all.length - 1 ? <Link href={it.href} className="hover:text-ink hover:underline">{it.label}</Link> : <span aria-current="page">{it.label}</span>}
          </span>
        ))}
      </nav>
      <JsonLd
        data={{
          '@context': 'https://schema.org',
          '@type': 'BreadcrumbList',
          itemListElement: all.map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it.label, ...(it.href ? { item: absoluteUrl(it.href) } : {}) }))
        }}
      />
    </>
  );
}

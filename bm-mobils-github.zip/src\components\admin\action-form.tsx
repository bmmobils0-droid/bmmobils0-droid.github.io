'use client';

import { useRouter } from 'next/navigation';
import { useTransition, type ReactNode } from 'react';
import { useToast } from '../toast';

type Result = { ok: boolean; message: string; redirect?: string };

/** Formulario que ejecuta una server action del panel y muestra el resultado como aviso. */
export function ActionForm({ action, children, className, resetOnSuccess }: {
  action: (fd: FormData) => Promise<Result>; children: ReactNode; className?: string; resetOnSuccess?: boolean;
}) {
  const router = useRouter();
  const { show } = useToast();
  const [pending, start] = useTransition();
  return (
    <form
      className={className}
      aria-busy={pending}
      onSubmit={(e) => {
        e.preventDefault();
        const form = e.currentTarget;
        const fd = new FormData(form);
        const submitter = (e.nativeEvent as SubmitEvent).submitter as HTMLButtonElement | null;
        if (submitter?.name) fd.set(submitter.name, submitter.value);
        start(async () => {
          const res = await action(fd);
          show(res.message, { tone: res.ok ? 'success' : 'error' });
          if (res.ok && resetOnSuccess) form.reset();
          if (res.ok && res.redirect) router.push(res.redirect);
          else if (res.ok) router.refresh();
        });
      }}
    >
      <fieldset disabled={pending} className="contents">{children}</fieldset>
    </form>
  );
}

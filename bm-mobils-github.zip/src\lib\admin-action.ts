import 'server-only';
import { Prisma } from '@/generated/prisma/client';
import { assertPermission, type CurrentUser } from './auth';
import type { Permission } from './permissions';

export type ActionResult = { ok: boolean; message: string; redirect?: string; errors?: Record<string, string> };

/** Error con un mensaje apto para mostrar al usuario del panel. */
export class UserError extends Error {}

/**
 * Envuelve una server action del panel: comprueba el permiso en el servidor y traduce
 * los errores a mensajes legibles sin exponer detalles internos.
 */
export async function adminAction(permission: Permission, fn: (user: CurrentUser) => Promise<ActionResult>): Promise<ActionResult> {
  let user: CurrentUser;
  try {
    user = await assertPermission(permission);
  } catch {
    return { ok: false, message: 'No tienes permiso para realizar esta acción.' };
  }
  try {
    return await fn(user);
  } catch (err) {
    if (err instanceof UserError || (err instanceof Error && err.constructor === Error)) return { ok: false, message: err.message };
    if (err instanceof Prisma.PrismaClientKnownRequestError) {
      if (err.code === 'P2002') return { ok: false, message: 'Ya existe un registro con ese valor único (SKU, slug, código…).' };
      if (err.code === 'P2003') return { ok: false, message: 'No se puede completar: hay registros relacionados.' };
      if (err.code === 'P2025') return { ok: false, message: 'El registro ya no existe. Recarga la página.' };
    }
    if (err instanceof Error && /violates check constraint/.test(err.message)) {
      return { ok: false, message: 'Los datos no cumplen las reglas de integridad (p. ej. stock negativo o precio de referencia no válido).' };
    }
    console.error('[admin]', err);
    return { ok: false, message: 'Ha ocurrido un error inesperado.' };
  }
}

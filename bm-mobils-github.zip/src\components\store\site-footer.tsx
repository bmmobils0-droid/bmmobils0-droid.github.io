import Link from 'next/link';
import { getSettings, PAYMENT_METHOD_OPTIONS } from '@/lib/settings';
import { Logo } from './logo';
import { CookieSettingsLink } from './cookie-consent';

const COLUMNS: [string, [string, string][]][] = [
  ['Comprar', [['/iphone', 'iPhone'], ['/samsung', 'Samsung'], ['/reacondicionados', 'Reacondicionados'], ['/segunda-mano', 'Segunda mano'], ['/accesorios', 'Accesorios'], ['/tablets', 'Tablets']]],
  ['Ayuda', [['/info/envios', 'Envíos'], ['/info/devoluciones', 'Devoluciones'], ['/info/garantia', 'Garantía'], ['/contacto', 'Contacto'], ['/cuenta', 'Mi cuenta']]],
  ['Legal', [['/info/aviso-legal', 'Aviso legal'], ['/info/condiciones', 'Condiciones de venta'], ['/info/privacidad', 'Privacidad'], ['/info/cookies', 'Cookies']]]
];

export async function SiteFooter() {
  const s = await getSettings();
  const social = Object.entries(s.social).filter(([, url]) => url && /^https:\/\//.test(url));
  return (
    <footer className="mt-24 bg-soft pt-14 pb-7 text-sm">
      <div className="container-page grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.6fr_1fr_1fr_1fr]">
        <div className="sm:col-span-2 lg:col-span-1">
          <Logo name={s.storeName} logoUrl={s.logoUrl} small />
          <p className="mt-3.5 mb-4 max-w-[34ch] text-muted">Móviles nuevos, reacondicionados y de segunda mano, tablets y accesorios.</p>
          {(s.contactEmail || s.contactPhone) && (
            <p className="mb-4 text-ink-2">
              {s.contactPhone && <a href={`tel:${s.contactPhone.replace(/\s/g, '')}`} className="hover:underline">{s.contactPhone}</a>}
              {s.contactPhone && s.contactEmail && ' · '}
              {s.contactEmail && <a href={`mailto:${s.contactEmail}`} className="hover:underline">{s.contactEmail}</a>}
            </p>
          )}
          <ul className="flex flex-wrap gap-2" aria-label="Métodos de pago">
            {s.paymentMethods.map((m) => (
              <li key={m} className="inline-flex h-[30px] items-center rounded-[7px] border border-line-strong bg-white px-2.5 text-xs font-semibold text-ink-2">{PAYMENT_METHOD_OPTIONS[m]}</li>
            ))}
          </ul>
          {social.length > 0 && (
            <ul className="mt-4 flex gap-4" aria-label="Redes sociales">
              {social.map(([name, url]) => <li key={name}><a href={url} rel="noopener noreferrer" target="_blank" className="capitalize text-ink-2 hover:text-ink hover:underline">{name}</a></li>)}
            </ul>
          )}
        </div>
        {COLUMNS.map(([title, links]) => (
          <div key={title}>
            <h2 className="mb-3.5 text-sm font-semibold">{title}</h2>
            <ul className="space-y-2.5">
              {links.map(([href, label]) => <li key={href}><Link href={href} className="text-ink-2 hover:text-ink hover:underline">{label}</Link></li>)}
              {title === 'Legal' && <li><CookieSettingsLink /></li>}
            </ul>
          </div>
        ))}
      </div>
      <div className="container-page mt-10 flex flex-wrap justify-between gap-4 border-t border-line-strong pt-5 text-[13px] text-muted">
        <p>© {new Date().getFullYear()} {s.legalName ?? s.storeName}. Todos los precios incluyen IVA.</p>
        <p>Las marcas mencionadas pertenecen a sus respectivos propietarios.</p>
      </div>
    </footer>
  );
}

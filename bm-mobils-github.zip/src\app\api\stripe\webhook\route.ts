import type Stripe from 'stripe';
import { db } from '@/lib/db';
import { getStripe } from '@/lib/stripe';
import { cancelPendingOrder, markOrderPaid, markPaymentFailed, markPaymentPending, markRefund } from '@/lib/orders';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Webhook de Stripe. Es la única fuente de verdad del estado de los pagos:
 * la firma se verifica con STRIPE_WEBHOOK_SECRET y cada evento se procesa una sola vez.
 */
export async function POST(req: Request) {
  const stripe = getStripe();
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!stripe || !secret) return new Response('Pagos no configurados', { status: 503 });

  const signature = req.headers.get('stripe-signature');
  if (!signature) return new Response('Falta la firma', { status: 400 });

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(await req.text(), signature, secret);
  } catch {
    return new Response('Firma no válida', { status: 400 });
  }

  if (await db.webhookEvent.findUnique({ where: { id: event.id } })) return Response.json({ received: true, duplicate: true });

  try {
    await handle(event);
    await db.webhookEvent.upsert({ where: { id: event.id }, create: { id: event.id, type: event.type }, update: {} });
  } catch (err) {
    console.error('[stripe:webhook] Error procesando', event.type, event.id, err);
    // 500 => Stripe reintentará el evento. Los manejadores son idempotentes.
    return new Response('Error procesando el evento', { status: 500 });
  }
  return Response.json({ received: true });
}

const paymentIntentId = (pi: string | Stripe.PaymentIntent | null) => (typeof pi === 'string' ? pi : pi?.id ?? null);

async function handle(event: Stripe.Event) {
  switch (event.type) {
    case 'checkout.session.completed':
    case 'checkout.session.async_payment_succeeded': {
      const s = event.data.object;
      const orderId = s.metadata?.orderId ?? s.client_reference_id;
      if (!orderId) return;
      if (s.payment_status === 'paid' || s.payment_status === 'no_payment_required') {
        await markOrderPaid({ orderId, sessionId: s.id, paymentIntentId: paymentIntentId(s.payment_intent), amountTotal: s.amount_total, currency: s.currency });
      } else {
        await markPaymentPending(orderId, paymentIntentId(s.payment_intent));
      }
      return;
    }
    case 'checkout.session.async_payment_failed': {
      const s = event.data.object;
      const orderId = s.metadata?.orderId ?? s.client_reference_id;
      if (orderId) await markPaymentFailed(orderId, 'El método de pago no se pudo completar.');
      return;
    }
    case 'checkout.session.expired': {
      const s = event.data.object;
      const orderId = s.metadata?.orderId ?? s.client_reference_id;
      if (orderId) await cancelPendingOrder(orderId, 'La sesión de pago ha caducado sin completarse.', { skipStripe: true });
      return;
    }
    case 'charge.refunded': {
      const c = event.data.object;
      const pi = paymentIntentId(c.payment_intent);
      if (pi) await markRefund(pi, c.amount_refunded, c.amount);
      return;
    }
    default:
      return;
  }
}

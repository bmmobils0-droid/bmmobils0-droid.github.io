'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/cn';

export function CatNav({ nav }: { nav: { href: string; label: string; deal?: boolean }[] }) {
  const pathname = usePathname();
  return (
    <nav className="hidden border-t border-line md:block" aria-label="Categorías">
      <div className="container-page flex h-12 items-center gap-1 overflow-x-auto [scrollbar-width:none]">
        {nav.map((item) => {
          const active = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              aria-current={active ? 'page' : undefined}
              className={cn(
                'rounded-full px-3.5 py-1.5 text-sm font-medium whitespace-nowrap transition',
                active ? (item.deal ? 'bg-danger text-white' : 'bg-ink text-white') : item.deal ? 'text-danger hover:bg-danger-soft' : 'text-ink-2 hover:bg-soft hover:text-ink'
              )}
            >
              {item.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

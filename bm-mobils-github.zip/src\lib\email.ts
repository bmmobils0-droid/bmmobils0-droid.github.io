import 'server-only';
import { db } from './db';
import { formatPrice } from './money';
import { getSettings, type EmailTemplateKey } from './settings';
import { absoluteUrl } from './site';
import { orderAccessToken } from './order-access';

const ESC: Record<string, string> = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ESC[c]);

/**
 * Envía un correo con Resend (https://resend.com) si RESEND_API_KEY está configurada.
 * Sin clave, se escribe en la consola del servidor para poder probar en local.
 */
export async function sendEmail(msg: { to: string; subject: string; html: string }): Promise<boolean> {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!key || !from) {
    console.info(`[email:desactivado] Para: ${msg.to} | Asunto: ${msg.subject}`);
    return false;
  }
  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from, to: [msg.to], subject: msg.subject, html: msg.html })
    });
    if (!res.ok) console.error('[email] Error al enviar', res.status, await res.text());
    return res.ok;
  } catch (err) {
    console.error('[email] Error al enviar', err);
    return false;
  }
}

/** Correo transaccional de un pedido usando las plantillas editables del panel. */
export async function sendOrderEmail(orderId: string, template: EmailTemplateKey) {
  const order = await db.order.findUnique({ where: { id: orderId }, include: { items: true, shipments: { orderBy: { shippedAt: 'desc' }, take: 1 } } });
  if (!order) return;
  const settings = await getSettings();
  const t = settings.emailTemplates[template];
  const fill = (s: string) => s.replaceAll('{numero}', order.number).replaceAll('{tienda}', settings.storeName);
  const link = absoluteUrl(`/pedido/${order.number}?t=${orderAccessToken(order.id)}`);
  const shipment = order.shipments[0];

  const rows = order.items
    .map((i) => `<tr><td style="padding:8px 0">${esc(i.productName)}<br><span style="color:#6b7180;font-size:13px">${esc(i.variantLabel)} × ${i.quantity}</span></td><td style="padding:8px 0;text-align:right;white-space:nowrap">${formatPrice(i.lineTotalCents)}</td></tr>`)
    .join('');
  const html = `<!doctype html><html lang="es"><body style="margin:0;background:#f5f5f7;font-family:Inter,Arial,sans-serif;color:#0b0b0f">
  <div style="max-width:560px;margin:0 auto;padding:32px 20px">
    <p style="font-weight:700;font-size:20px;margin:0 0 24px">${esc(settings.storeName)}</p>
    <div style="background:#fff;border-radius:16px;padding:28px">
      <h1 style="font-size:20px;margin:0 0 12px">${esc(fill(t.subject))}</h1>
      <p style="margin:0 0 20px;color:#3d414b;line-height:1.55">${esc(fill(t.intro))}</p>
      ${shipment && template === 'shipped' ? `<p style="margin:0 0 20px"><strong>${esc(shipment.carrier)}</strong> · ${esc(shipment.trackingNumber)}${shipment.trackingUrl ? `<br><a href="${esc(shipment.trackingUrl)}">Seguir envío</a>` : ''}</p>` : ''}
      <table style="width:100%;border-collapse:collapse;font-size:14px;border-top:1px solid #e6e7eb">${rows}
        <tr><td style="padding:12px 0 0;border-top:1px solid #e6e7eb"><strong>Total (IVA incluido)</strong></td><td style="padding:12px 0 0;border-top:1px solid #e6e7eb;text-align:right"><strong>${formatPrice(order.totalCents)}</strong></td></tr>
      </table>
      <p style="margin:24px 0 0"><a href="${link}" style="display:inline-block;background:#0b0b0f;color:#fff;text-decoration:none;padding:12px 20px;border-radius:999px;font-weight:600">Ver mi pedido</a></p>
    </div>
    <p style="color:#6b7180;font-size:12px;margin-top:20px">${esc(settings.legalName ?? settings.storeName)}${settings.contactEmail ? ` · ${esc(settings.contactEmail)}` : ''}</p>
  </div></body></html>`;
  await sendEmail({ to: order.email, subject: fill(t.subject), html });
}

import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { can } from '@/lib/permissions';
import { LoginForm } from '@/components/auth-forms';

export const metadata: Metadata = { title: 'Acceso al panel', robots: { index: false, follow: false } };

export default async function AdminLoginPage() {
  const user = await getCurrentUser();
  if (user && can(user.role, 'admin:access')) redirect('/admin');
  return (
    <main className="grid min-h-dvh place-items-center bg-soft px-4">
      <div className="w-full max-w-sm rounded-2xl bg-white p-7 shadow-card">
        <div className="mb-6 flex items-center gap-2 font-bold">
          <span className="grid size-9 place-items-center rounded-[10px] bg-ink text-sm text-white">BM</span>
          <span className="text-lg">Panel de administración</span>
        </div>
        <LoginForm area="admin" />
      </div>
    </main>
  );
}

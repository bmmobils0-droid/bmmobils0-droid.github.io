import Image from 'next/image';
import { renderDeviceArt, type ArtStyle, type ArtType, type ArtView } from '@/lib/device-art';
import { cn } from '@/lib/cn';

export type ArtSpec = { type: ArtType; style: ArtStyle; color: string | null };

/** Muestra la foto del producto o, si no tiene, su ilustración generada. */
export function ProductVisual({ image, art, view, alt, className, sizes = '(min-width: 1024px) 25vw, 50vw', priority }: {
  image?: { url: string; alt: string } | null; art: ArtSpec; view?: ArtView; alt: string; className?: string; sizes?: string; priority?: boolean;
}) {
  if (image) {
    return (
      <div className={cn('relative', className)}>
        <Image src={image.url} alt={image.alt || alt} fill sizes={sizes} priority={priority} className="object-contain p-[6%]" />
      </div>
    );
  }
  return (
    <div
      className={cn('art-box', className)}
      role="img"
      aria-label={alt}
      dangerouslySetInnerHTML={{ __html: renderDeviceArt(art.type, { color: art.color, style: art.style, view }) }}
    />
  );
}

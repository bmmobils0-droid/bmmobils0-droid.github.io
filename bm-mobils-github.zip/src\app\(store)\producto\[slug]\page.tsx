import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ChevronDown } from 'lucide-react';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { can } from '@/lib/permissions';
import { getCompatibleAccessories, getProductBySlug, getRelated } from '@/lib/catalog/queries';
import { artFor } from '@/lib/device-art';
import { CONDITION_LABEL, GRADE_DESCRIPTION, GRADE_LABEL } from '@/lib/labels';
import { absoluteUrl } from '@/lib/site';
import { Breadcrumbs } from '@/components/store/breadcrumbs';
import { JsonLd } from '@/components/store/json-ld';
import { ProductDetail } from '@/components/store/product-detail';
import { ProductGrid } from '@/components/store/product-card';
import { Section } from '@/components/store/section';

type Props = { params: Promise<{ slug: string }> };

const SCHEMA_CONDITION = { NEW: 'https://schema.org/NewCondition', REFURBISHED: 'https://schema.org/RefurbishedCondition', USED: 'https://schema.org/UsedCondition' } as const;

async function load(slug: string) {
  const product = await getProductBySlug(slug);
  if (!product || product.variants.length === 0) return null;
  if (product.status !== 'PUBLISHED') {
    // Los borradores solo los ve el equipo (vista previa).
    const user = await getCurrentUser();
    if (!can(user?.role, 'products:write')) return null;
  }
  return product;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const p = await load(slug);
  if (!p) return { title: 'Producto no encontrado' };
  const title = p.seoTitle ?? `${p.name}${p.condition !== 'NEW' ? ` ${CONDITION_LABEL[p.condition].toLowerCase()}` : ''}`;
  const description = p.seoDescription ?? (p.description.slice(0, 155) || `Compra ${p.name} en BM Mobils.`);
  return {
    title,
    description,
    alternates: { canonical: `/producto/${p.slug}` },
    robots: p.isDemo || p.status !== 'PUBLISHED' ? { index: false, follow: false } : undefined,
    openGraph: { type: 'website', title, description, url: `/producto/${p.slug}`, images: p.images[0] ? [{ url: p.images[0].url, alt: p.images[0].alt || p.name }] : undefined }
  };
}

export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  const p = await load(slug);
  if (!p) notFound();

  const family = p.brand.slug === 'apple' ? 'iPhone' : p.brand.slug === 'samsung' ? 'Galaxy' : p.brand.name;
  const isDevice = ['moviles', 'tablets'].includes(p.category.slug);
  const [related, addons, cheapestRate] = await Promise.all([
    getRelated(p),
    isDevice ? getCompatibleAccessories(family) : Promise.resolve([]),
    db.shippingRate.findFirst({ where: { active: true, zones: { has: 'PENINSULA' } }, orderBy: { priceCents: 'asc' } })
  ]);

  const specs = Array.isArray(p.specs) ? (p.specs as { label: string; value: string }[]).filter((s) => s?.label && s?.value) : [];
  const grades = [...new Set(p.variants.map((v) => v.grade).filter((g) => g != null))];
  const warrantyText = p.warrantyText ?? (p.warrantyMonths ? `${p.warrantyMonths} meses de garantía.` : 'Garantía legal de conformidad según la normativa vigente.');
  const prices = p.variants.map((v) => v.priceCents);
  const inStock = p.variants.some((v) => v.stock > 0);
  const cat = p.category.parent ?? p.category;
  const catHref = { moviles: '/moviles', tablets: '/tablets', accesorios: '/accesorios', 'audio-y-wearables': '/audio' }[cat.slug] ?? `/${cat.slug}`;

  return (
    <div className="container-page pt-6">
      <Breadcrumbs items={[{ label: cat.name, href: catHref }, { label: p.name }]} />
      {p.status !== 'PUBLISHED' && <p className="mb-4 rounded-xl bg-warn-soft px-4 py-3 text-sm text-[#6b3e00]">Vista previa: este producto no está publicado.</p>}

      <ProductDetail
        slug={p.slug}
        name={p.name}
        brand={p.brand.name}
        model={p.model}
        condition={p.condition}
        isDemo={p.isDemo}
        variants={p.variants.map((v) => ({
          id: v.id, storageGb: v.storageGb, optionLabel: v.optionLabel, color: v.color, colorHex: v.colorHex, grade: v.grade,
          batteryHealth: v.batteryHealth, batteryCheckedAt: v.batteryCheckedAt?.toISOString() ?? null,
          priceCents: v.priceCents, compareAtCents: v.compareAtCents, stock: v.stock
        }))}
        images={p.images.map((i) => ({ url: i.url, alt: i.alt, color: i.color }))}
        art={artFor({ categorySlug: p.category.slug, brandSlug: p.brand.slug, model: p.model })}
        optionTitle={p.variants.some((v) => v.storageGb != null) ? 'Almacenamiento' : 'Opción'}
        warrantyText={warrantyText}
        shippingFromCents={cheapestRate?.priceCents ?? null}
      />

      <section className="mt-16 max-w-[860px]" aria-label="Información del producto">
        <Details title="Descripción" open>
          {p.description ? p.description.split(/\n{2,}/).map((para, i) => <p key={i} className="whitespace-pre-line">{para}</p>) : <p className="text-muted">Sin descripción.</p>}
        </Details>
        <Details title="Especificaciones técnicas">
          {specs.length ? (
            <table className="w-full border-collapse text-sm">
              <tbody>
                <tr className="border-b border-line"><th scope="row" className="w-[38%] py-3 text-left font-medium text-muted">Marca y modelo</th><td className="py-3">{p.brand.name} {p.model}</td></tr>
                {specs.map((s, i) => (
                  <tr key={i} className="border-b border-line last:border-0"><th scope="row" className="w-[38%] py-3 text-left align-top font-medium text-muted">{s.label}</th><td className="py-3">{s.value}</td></tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="text-muted">Especificaciones pendientes de publicar.</p>
          )}
        </Details>
        {p.condition !== 'NEW' && (
          <Details title="Estado del dispositivo">
            <p><strong>{CONDITION_LABEL[p.condition]}.</strong> {p.condition === 'REFURBISHED' ? 'Dispositivo usado revisado antes de su venta.' : 'Dispositivo usado; puede presentar marcas de uso.'}</p>
            {grades.length > 0 && <ul className="mt-3 list-disc space-y-1 pl-5">{grades.map((g) => <li key={g}><strong>{GRADE_LABEL[g!]}:</strong> {GRADE_DESCRIPTION[g!]}</li>)}</ul>}
            {p.conditionDetails && <p className="mt-3 whitespace-pre-line">{p.conditionDetails}</p>}
            <p className="mt-3 text-muted">La salud de batería solo se muestra cuando se ha comprobado en la unidad.</p>
          </Details>
        )}
        <Details title="Garantía">
          <p>{warrantyText}</p>
          <p className="mt-3"><Link href="/info/garantia" className="text-brand underline">Información sobre garantías</Link></p>
        </Details>
        <Details title="Envío y devoluciones">
          <p>Enviamos a toda España. Verás el coste de envío exacto según tu código postal antes de pagar.</p>
          <p className="mt-3">Dispones de 14 días naturales desde la entrega para ejercer tu derecho de desistimiento. <Link href="/info/devoluciones" className="text-brand underline">Política de devoluciones</Link></p>
        </Details>
      </section>

      {p.reviews.length > 0 && (
        <Section id="h-reviews" title="Opiniones de clientes">
          <ul className="grid gap-4 md:grid-cols-2">
            {p.reviews.map((r) => (
              <li key={r.id} className="rounded-card border border-line p-5">
                <p className="font-semibold" aria-label={`${r.rating} de 5`}>{'★'.repeat(r.rating)}<span className="text-line-strong">{'★'.repeat(5 - r.rating)}</span></p>
                {r.title && <p className="mt-2 font-semibold">{r.title}</p>}
                <p className="mt-1 text-sm text-ink-2">{r.body}</p>
                <p className="mt-2 text-xs text-muted">{r.createdAt.toLocaleDateString('es-ES')}{r.verifiedPurchase ? ' · Compra verificada' : ''}</p>
              </li>
            ))}
          </ul>
        </Section>
      )}

      {addons.length > 0 && <Section id="h-addons" title="Completa tu compra"><ProductGrid items={addons} /></Section>}
      {related.length > 0 && <Section id="h-related" title="También te puede interesar"><ProductGrid items={related} /></Section>}

      {!p.isDemo && p.status === 'PUBLISHED' && (
        <JsonLd
          data={{
            '@context': 'https://schema.org',
            '@type': 'Product',
            name: p.name,
            description: p.description || undefined,
            sku: p.variants[0].sku,
            brand: { '@type': 'Brand', name: p.brand.name },
            model: p.model,
            image: p.images.map((i) => (i.url.startsWith('http') ? i.url : absoluteUrl(i.url))),
            itemCondition: SCHEMA_CONDITION[p.condition],
            offers: {
              '@type': 'AggregateOffer',
              priceCurrency: 'EUR',
              lowPrice: (Math.min(...prices) / 100).toFixed(2),
              highPrice: (Math.max(...prices) / 100).toFixed(2),
              offerCount: p.variants.length,
              availability: inStock ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
              url: absoluteUrl(`/producto/${p.slug}`)
            },
            // Solo con reseñas reales y aprobadas.
            ...(p.reviews.length > 0
              ? { aggregateRating: { '@type': 'AggregateRating', ratingValue: (p.reviews.reduce((s, r) => s + r.rating, 0) / p.reviews.length).toFixed(1), reviewCount: p.reviews.length } }
              : {})
          }}
        />
      )}
    </div>
  );
}

function Details({ title, open, children }: { title: string; open?: boolean; children: React.ReactNode }) {
  return (
    <details open={open} className="group border-t border-line last:border-b">
      <summary className="flex cursor-pointer list-none items-center justify-between py-5 text-lg font-semibold tracking-tight [&::-webkit-details-marker]:hidden">
        {title}
        <ChevronDown className="size-5 transition group-open:rotate-180" aria-hidden />
      </summary>
      <div className="pb-6 text-[15px] leading-relaxed text-ink-2">{children}</div>
    </details>
  );
}

/**
 * Esquemas de validación compartidos entre formularios (cliente) y server actions (servidor).
 * El servidor valida siempre, aunque el cliente ya lo haya hecho.
 */
import { z } from 'zod';
import { POSTAL_CODE_RE, PROVINCES } from './geo';
import { isValidNif } from './nif';

const trimmed = (min: number, max: number, msg: string) => z.string().trim().min(min, { error: msg }).max(max, { error: `Máximo ${max} caracteres.` });
const optionalText = (max: number) => z.string().trim().max(max, { error: `Máximo ${max} caracteres.` }).optional().transform((v) => v || undefined);

export const emailSchema = z.string().trim().toLowerCase().pipe(z.email({ error: 'Introduce un email válido.' }));
export const phoneSchema = z
  .string()
  .trim()
  .transform((v) => v.replace(/[\s-]/g, ''))
  .refine((v) => /^(\+34|0034)?[6789]\d{8}$/.test(v), { error: 'Introduce un teléfono español válido.' });
export const passwordSchema = z
  .string()
  .min(10, { error: 'La contraseña debe tener al menos 10 caracteres.' })
  .max(128, { error: 'Máximo 128 caracteres.' });

export const loginSchema = z.object({ email: emailSchema, password: z.string().min(1, { error: 'Introduce tu contraseña.' }).max(128) });

export const registerSchema = z.object({
  name: trimmed(2, 80, 'Introduce tu nombre.'),
  email: emailSchema,
  password: passwordSchema,
  acceptPrivacy: z.literal(true, { error: 'Debes aceptar la política de privacidad.' })
});

export const checkoutSchema = z
  .object({
    email: emailSchema,
    phone: phoneSchema,
    firstName: trimmed(2, 60, 'Introduce tu nombre.'),
    lastName: trimmed(2, 80, 'Introduce tus apellidos.'),
    line1: trimmed(5, 120, 'Introduce la dirección de entrega.'),
    line2: optionalText(80),
    postalCode: z.string().trim().regex(POSTAL_CODE_RE, { error: 'Código postal no válido (5 dígitos).' }),
    city: trimmed(2, 80, 'Introduce la localidad.'),
    province: z.enum(PROVINCES as [string, ...string[]], { error: 'Selecciona la provincia.' }),
    country: z.literal('ES', { error: 'Por ahora solo enviamos a España.' }),
    shippingRateId: z.string().min(1, { error: 'Selecciona un método de envío.' }),
    wantsInvoice: z.boolean().default(false),
    billingName: optionalText(120),
    billingTaxId: optionalText(20),
    billingLine1: optionalText(120),
    billingPostalCode: optionalText(5),
    billingCity: optionalText(80),
    billingProvince: optionalText(60),
    customerNote: optionalText(500),
    acceptTerms: z.literal(true, { error: 'Debes aceptar las condiciones de venta.' })
  })
  .superRefine((d, ctx) => {
    if (!d.wantsInvoice) return;
    if (!d.billingName) ctx.addIssue({ code: 'custom', path: ['billingName'], message: 'Introduce el nombre o razón social.' });
    if (!d.billingTaxId || !isValidNif(d.billingTaxId)) ctx.addIssue({ code: 'custom', path: ['billingTaxId'], message: 'Introduce un NIF, NIE o CIF válido.' });
    if (!d.billingLine1) ctx.addIssue({ code: 'custom', path: ['billingLine1'], message: 'Introduce la dirección de facturación.' });
    if (!d.billingPostalCode || !POSTAL_CODE_RE.test(d.billingPostalCode)) ctx.addIssue({ code: 'custom', path: ['billingPostalCode'], message: 'Código postal no válido.' });
    if (!d.billingCity) ctx.addIssue({ code: 'custom', path: ['billingCity'], message: 'Introduce la localidad.' });
  });
export type CheckoutInput = z.input<typeof checkoutSchema>;

export const contactSchema = z.object({
  name: trimmed(2, 80, 'Introduce tu nombre.'),
  email: emailSchema,
  orderNumber: optionalText(30),
  message: trimmed(10, 3000, 'Escribe tu mensaje (mínimo 10 caracteres).'),
  acceptPrivacy: z.literal(true, { error: 'Debes aceptar la política de privacidad.' })
});

// --- Panel de administración -------------------------------------------------

// Acepta "12,95" y "12.95"; los campos vacíos opcionales se convierten en null.
const normNum = (v: unknown) => (typeof v === 'string' ? v.trim().replace(',', '.') : v);
const emptyToNull = (v: unknown) => {
  const n = normNum(v);
  return n === '' || n === undefined ? null : n;
};
const euros = z.preprocess(
  normNum,
  z.coerce.number({ error: 'Introduce un importe.' }).refine(Number.isFinite, { error: 'Introduce un importe.' }).min(0, { error: 'No puede ser negativo.' }).max(100000, { error: 'Importe demasiado alto.' })
);
const optionalEuros = z.preprocess(emptyToNull, z.coerce.number({ error: 'Importe no válido.' }).min(0, { error: 'No puede ser negativo.' }).max(100000).nullable());
const optionalInt = (min: number, max: number) =>
  z.preprocess(emptyToNull, z.coerce.number({ error: 'Número no válido.' }).int({ error: 'Debe ser un número entero.' }).min(min, { error: `Mínimo ${min}.` }).max(max, { error: `Máximo ${max}.` }).nullable());

export const variantSchema = z
  .object({
    id: z.string().optional(),
    sku: z.string().trim().min(2, { error: 'SKU obligatorio.' }).max(60).regex(/^[A-Za-z0-9._-]+$/, { error: 'Solo letras, números, punto, guion y guion bajo.' }),
    storageGb: optionalInt(1, 8192),
    optionLabel: optionalText(40),
    color: optionalText(40),
    colorHex: z.union([z.literal(''), z.string().regex(/^#[0-9a-fA-F]{6}$/, { error: 'Formato #RRGGBB.' })]).optional().transform((v) => v || undefined),
    grade: z.union([z.literal(''), z.enum(['EXCELLENT', 'VERY_GOOD', 'GOOD'])]).optional().transform((v) => v || undefined),
    batteryHealth: optionalInt(0, 100),
    batteryCheckedAt: z
      .union([z.literal(''), z.null(), z.iso.date({ error: 'Fecha no válida.' })])
      .optional()
      .transform((v) => (v ? v : null)),
    price: euros,
    compareAt: optionalEuros,
    stock: z.coerce.number().int().min(0, { error: 'El stock no puede ser negativo.' }).max(100000),
    /** Stock que había al abrir el formulario: el servidor aplica la diferencia para no pisar reservas simultáneas. */
    originalStock: z.coerce.number().int().min(0).optional(),
    lowStockAt: z.coerce.number().int().min(0).max(1000).default(2),
    isActive: z.boolean().default(true)
  })
  .superRefine((v, ctx) => {
    if (v.compareAt != null && v.compareAt <= v.price) ctx.addIssue({ code: 'custom', path: ['compareAt'], message: 'Debe ser mayor que el precio.' });
    if (v.batteryHealth != null && !v.batteryCheckedAt) ctx.addIssue({ code: 'custom', path: ['batteryCheckedAt'], message: 'Indica la fecha de comprobación.' });
  });

export const productSchema = z.object({
  name: trimmed(2, 120, 'Introduce el nombre.'),
  slug: z.string().trim().max(140).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, { error: 'Solo minúsculas, números y guiones.' }).optional().or(z.literal('')),
  model: trimmed(1, 80, 'Introduce el modelo.'),
  brandId: z.string().min(1, { error: 'Selecciona una marca.' }),
  categoryId: z.string().min(1, { error: 'Selecciona una categoría.' }),
  condition: z.enum(['NEW', 'REFURBISHED', 'USED']),
  status: z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED']),
  featured: z.boolean().default(false),
  isDemo: z.boolean().default(false),
  description: z.string().trim().max(10000).default(''),
  conditionDetails: optionalText(4000),
  specs: z.array(z.object({ label: z.string().trim().min(1).max(60), value: z.string().trim().min(1).max(200) })).max(40).default([]),
  warrantyMonths: optionalInt(0, 120),
  warrantyText: optionalText(500),
  taxRate: z.coerce.number().int().min(0).max(10000).default(2100),
  seoTitle: optionalText(70),
  seoDescription: optionalText(170),
  variants: z.array(variantSchema).min(1, { error: 'Añade al menos una variante.' }).max(60)
});
export type ProductInput = z.input<typeof productSchema>;

export const shipmentSchema = z.object({
  carrier: trimmed(2, 60, 'Indica el transportista.'),
  trackingNumber: trimmed(3, 80, 'Indica el número de seguimiento.'),
  trackingUrl: z.union([z.literal(''), z.url({ error: 'URL no válida.' })]).optional().transform((v) => v || undefined)
});

export const shippingRateSchema = z.object({
  id: z.string().optional(),
  name: trimmed(2, 60, 'Nombre obligatorio.'),
  description: optionalText(120),
  price: euros,
  freeFrom: optionalEuros,
  zones: z.array(z.enum(['PENINSULA', 'BALEARES', 'CANARIAS', 'CEUTA_MELILLA'])).min(1, { error: 'Selecciona al menos una zona.' }),
  active: z.boolean().default(true)
});

export const couponSchema = z.object({
  code: z.string().trim().toUpperCase().min(3).max(30).regex(/^[A-Z0-9_-]+$/, { error: 'Solo letras, números, guion y guion bajo.' }),
  type: z.enum(['PERCENT', 'FIXED']),
  value: z.coerce.number().positive({ error: 'Debe ser mayor que 0.' }),
  minSubtotal: optionalEuros,
  startsAt: z.string().optional().transform((v) => (v ? new Date(v) : null)),
  endsAt: z.string().optional().transform((v) => (v ? new Date(v) : null)),
  maxRedemptions: optionalInt(1, 1_000_000)
}).refine((c) => c.type !== 'PERCENT' || c.value <= 100, { path: ['value'], error: 'Un porcentaje no puede superar el 100 %.' });

export const settingsSchema = z.object({
  storeName: trimmed(2, 60, 'Nombre obligatorio.'),
  contactEmail: z.union([z.literal(''), emailSchema]).transform((v) => v || null),
  contactPhone: optionalText(30).transform((v) => v ?? null),
  whatsapp: optionalText(30).transform((v) => v ?? null),
  address: optionalText(200).transform((v) => v ?? null),
  openingHours: optionalText(200).transform((v) => v ?? null),
  instagram: optionalText(200),
  facebook: optionalText(200),
  tiktok: optionalText(200),
  x: optionalText(200),
  youtube: optionalText(200),
  legalName: optionalText(120).transform((v) => v ?? null),
  legalTaxId: optionalText(20).transform((v) => v ?? null),
  legalAddress: optionalText(200).transform((v) => v ?? null),
  legalRegistry: optionalText(300).transform((v) => v ?? null),
  defaultTaxRate: z.coerce.number().min(0).max(100),
  heroTitle: trimmed(3, 120, 'Título obligatorio.'),
  heroSubtitle: trimmed(3, 300, 'Subtítulo obligatorio.'),
  infoBar: z.string().max(1000).default(''),
  paymentMethods: z.array(z.string()).default([])
});

export const pageSchema = z.object({
  title: trimmed(2, 120, 'Título obligatorio.'),
  content: z.string().max(50000),
  needsLegalReview: z.boolean().default(false)
});

export function fieldErrors(error: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = issue.path.join('.');
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}

import Link from 'next/link';
import { ButtonLink } from '@/components/ui/button';

export default function NotFound() {
  return (
    <main className="container-page grid min-h-[70dvh] place-items-center py-20 text-center">
      <div>
        <p className="text-sm font-semibold tracking-widest text-muted uppercase">Error 404</p>
        <h1 className="mt-3 text-3xl font-bold sm:text-4xl">No encontramos esta página</h1>
        <p className="mx-auto mt-3 max-w-md text-muted">Puede que el enlace haya cambiado o que el producto ya no esté disponible.</p>
        <div className="mt-7 flex flex-wrap justify-center gap-3">
          <ButtonLink href="/">Ir al inicio</ButtonLink>
          <ButtonLink href="/catalogo" variant="outline">Ver catálogo</ButtonLink>
        </div>
        <p className="mt-6 text-sm"><Link href="/contacto" className="text-brand hover:underline">¿Necesitas ayuda?</Link></p>
      </div>
    </main>
  );
}

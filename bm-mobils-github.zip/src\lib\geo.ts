import type { ShippingZone } from '@/generated/prisma/enums';

/** Provincias ordenadas por prefijo de código postal (01 = Álava ... 52 = Melilla). */
export const PROVINCES_BY_PREFIX = [
  'Álava', 'Albacete', 'Alicante', 'Almería', 'Ávila', 'Badajoz', 'Illes Balears', 'Barcelona', 'Burgos', 'Cáceres',
  'Cádiz', 'Castellón', 'Ciudad Real', 'Córdoba', 'A Coruña', 'Cuenca', 'Girona', 'Granada', 'Guadalajara', 'Gipuzkoa',
  'Huelva', 'Huesca', 'Jaén', 'León', 'Lleida', 'La Rioja', 'Lugo', 'Madrid', 'Málaga', 'Murcia', 'Navarra', 'Ourense',
  'Asturias', 'Palencia', 'Las Palmas', 'Pontevedra', 'Salamanca', 'Santa Cruz de Tenerife', 'Cantabria', 'Segovia',
  'Sevilla', 'Soria', 'Tarragona', 'Teruel', 'Toledo', 'Valencia', 'Valladolid', 'Bizkaia', 'Zamora', 'Zaragoza',
  'Ceuta', 'Melilla'
] as const;

export const PROVINCES = [...PROVINCES_BY_PREFIX].sort((a, b) => a.localeCompare(b, 'es'));

export const POSTAL_CODE_RE = /^(0[1-9]|[1-4]\d|5[0-2])\d{3}$/;

export function provinceFromPostalCode(postalCode: string): string | null {
  if (!POSTAL_CODE_RE.test(postalCode)) return null;
  return PROVINCES_BY_PREFIX[Number(postalCode.slice(0, 2)) - 1] ?? null;
}

export function zoneForPostalCode(postalCode: string): ShippingZone {
  const prefix = postalCode.slice(0, 2);
  if (prefix === '07') return 'BALEARES';
  if (prefix === '35' || prefix === '38') return 'CANARIAS';
  if (prefix === '51' || prefix === '52') return 'CEUTA_MELILLA';
  return 'PENINSULA';
}

/** Territorios fuera del ámbito de aplicación del IVA (IGIC / IPSI). */
export function requiresTaxReview(zone: ShippingZone): boolean {
  return zone === 'CANARIAS' || zone === 'CEUTA_MELILLA';
}

export const ZONE_LABEL: Record<ShippingZone, string> = {
  PENINSULA: 'Península',
  BALEARES: 'Illes Balears',
  CANARIAS: 'Canarias',
  CEUTA_MELILLA: 'Ceuta y Melilla'
};

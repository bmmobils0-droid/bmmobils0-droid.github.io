import Link from 'next/link';
import { requirePermission } from '@/lib/auth';
import { db } from '@/lib/db';
import { formatPrice } from '@/lib/money';
import { ROLE_LABEL } from '@/lib/permissions';
import { SALE_STATUSES } from '@/lib/order-status';
import { PageHeader, Table } from '@/components/admin/ui';
import { Badge } from '@/components/ui/badge';

export const metadata = { title: 'Clientes' };

export default async function CustomersPage({ searchParams }: { searchParams: Promise<{ q?: string; vista?: string }> }) {
  await requirePermission('customers:read');
  const sp = await searchParams;
  const guests = sp.vista === 'invitados';
  const q = sp.q?.trim();

  const users = guests ? [] : await db.user.findMany({
    where: q ? { OR: [{ email: { contains: q, mode: 'insensitive' } }, { name: { contains: q, mode: 'insensitive' } }] } : {},
    orderBy: { createdAt: 'desc' },
    take: 100,
    select: { id: true, name: true, email: true, role: true, disabled: true, createdAt: true, orders: { where: { status: { in: SALE_STATUSES } }, select: { totalCents: true } } }
  });
  // Compradores sin cuenta: agrupados por email a partir de sus pedidos cobrados.
  const guestRows = guests
    ? await db.order.groupBy({
        by: ['email'],
        where: { userId: null, status: { in: SALE_STATUSES }, ...(q ? { email: { contains: q, mode: 'insensitive' } } : {}) },
        _count: { _all: true },
        _sum: { totalCents: true },
        _max: { createdAt: true },
        orderBy: { _max: { createdAt: 'desc' } },
        take: 100
      })
    : [];
  const date = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', year: 'numeric' });

  return (
    <>
      <PageHeader title="Clientes" subtitle="Acceso restringido: usa estos datos solo para gestionar compras." />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <Link href="/admin/clientes" className={`rounded-full px-3 py-1.5 text-sm font-medium ${!guests ? 'bg-ink text-white' : 'bg-white text-ink-2'}`}>Con cuenta</Link>
        <Link href="/admin/clientes?vista=invitados" className={`rounded-full px-3 py-1.5 text-sm font-medium ${guests ? 'bg-ink text-white' : 'bg-white text-ink-2'}`}>Compras sin cuenta</Link>
        <form className="ml-auto" role="search">
          {guests && <input type="hidden" name="vista" value="invitados" />}
          <input name="q" defaultValue={q} placeholder="Nombre o email" aria-label="Buscar clientes" className="h-9 w-64 rounded-full border border-line-strong bg-white px-3.5 text-sm outline-none focus:border-ink" />
        </form>
      </div>
      {guests ? (
        <Table>
          <thead><tr><th>Email</th><th>Pedidos</th><th>Total comprado</th><th>Último pedido</th></tr></thead>
          <tbody>
            {guestRows.length === 0 && <tr><td colSpan={4} className="py-10 text-center text-muted">Sin compras de invitados.</td></tr>}
            {guestRows.map((g) => (
              <tr key={g.email}><td><Link href={`/admin/pedidos?q=${encodeURIComponent(g.email)}`} className="font-medium hover:underline">{g.email}</Link></td><td>{g._count._all}</td><td>{formatPrice(g._sum.totalCents ?? 0)}</td><td>{g._max.createdAt ? date.format(g._max.createdAt) : '—'}</td></tr>
            ))}
          </tbody>
        </Table>
      ) : (
        <Table>
          <thead><tr><th>Cliente</th><th>Rol</th><th>Pedidos</th><th>Total comprado</th><th>Alta</th></tr></thead>
          <tbody>
            {users.length === 0 && <tr><td colSpan={5} className="py-10 text-center text-muted">No hay clientes registrados.</td></tr>}
            {users.map((u) => (
              <tr key={u.id}>
                <td><Link href={`/admin/clientes/${u.id}`} className="font-semibold hover:underline">{u.name}</Link><span className="block text-xs text-muted">{u.email}</span></td>
                <td><span className="flex gap-1"><Badge tone={u.role === 'CUSTOMER' ? 'gray' : 'brand'}>{ROLE_LABEL[u.role]}</Badge>{u.disabled && <Badge tone="danger">Desactivada</Badge>}</span></td>
                <td>{u.orders.length}</td>
                <td>{formatPrice(u.orders.reduce((s, o) => s + o.totalCents, 0))}</td>
                <td>{date.format(u.createdAt)}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </>
  );
}

import { SiteHeader } from '@/components/store/site-header';
import { SiteFooter } from '@/components/store/site-footer';
import { CookieConsent } from '@/components/store/cookie-consent';

export default function StoreLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <a href="#contenido" className="absolute -left-[999px] top-2 z-[100] rounded-lg bg-ink px-3.5 py-2 text-white focus:left-2">Saltar al contenido</a>
      <SiteHeader />
      <main id="contenido" tabIndex={-1} className="outline-none">{children}</main>
      <SiteFooter />
      <CookieConsent />
    </>
  );
}

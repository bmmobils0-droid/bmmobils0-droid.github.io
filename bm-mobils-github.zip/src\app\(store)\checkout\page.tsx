import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';
import { getCartView } from '@/lib/cart';
import { paymentsConfigured } from '@/lib/stripe';
import { Breadcrumbs } from '@/components/store/breadcrumbs';
import { CheckoutForm } from '@/components/store/checkout-form';

export const metadata: Metadata = { title: 'Finalizar compra', robots: { index: false } };

export default async function CheckoutPage({ searchParams }: { searchParams: Promise<{ cancelado?: string }> }) {
  const { cancelado } = await searchParams;
  const view = await getCartView();
  if (!view) redirect('/carrito');
  if (view.hasIssues) redirect('/carrito');

  const [user, rates, coupon] = await Promise.all([
    getCurrentUser(),
    db.shippingRate.findMany({ where: { active: true }, orderBy: [{ position: 'asc' }, { priceCents: 'asc' }] }),
    view.couponCode ? db.coupon.findUnique({ where: { code: view.couponCode } }) : null
  ]);
  const address = user ? await db.address.findFirst({ where: { userId: user.id }, orderBy: { isDefault: 'desc' } }) : null;
  const [firstName, ...last] = (user?.name ?? '').split(' ');

  return (
    <div className="container-page pt-6">
      <Breadcrumbs items={[{ label: 'Carrito', href: '/carrito' }, { label: 'Finalizar compra' }]} />
      <h1 className="mb-7 text-[28px] font-bold sm:text-4xl">Finalizar compra</h1>
      <CheckoutForm
        lines={view.lines.map((l) => ({ itemId: l.itemId, name: l.name, label: l.label, quantity: l.quantity, unitPriceCents: l.unitPriceCents, lineTotalCents: l.lineTotalCents, taxRate: l.taxRate, image: l.image, art: l.art }))}
        rates={rates.map((r) => ({ id: r.id, name: r.name, description: r.description, priceCents: r.priceCents, freeFromCents: r.freeFromCents, zones: r.zones }))}
        coupon={coupon && !view.totals.couponError ? coupon : null}
        shippingTaxRate={view.taxRate}
        paymentsEnabled={paymentsConfigured()}
        cancelled={cancelado === '1'}
        defaults={{
          email: user?.email ?? '',
          phone: address?.phone ?? user?.phone ?? '',
          firstName: address?.firstName ?? firstName ?? '',
          lastName: address?.lastName ?? last.join(' '),
          line1: address?.line1 ?? '',
          line2: address?.line2 ?? '',
          postalCode: address?.postalCode ?? '',
          city: address?.city ?? '',
          province: address?.province ?? ''
        }}
      />
    </div>
  );
}

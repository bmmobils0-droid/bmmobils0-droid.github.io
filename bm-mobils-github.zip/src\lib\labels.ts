import type { CosmeticGrade, DeviceCondition, ProductStatus } from '@/generated/prisma/enums';

export const CONDITION_LABEL: Record<DeviceCondition, string> = {
  NEW: 'Nuevo',
  REFURBISHED: 'Reacondicionado',
  USED: 'Segunda mano'
};

export const CONDITION_SLUG: Record<DeviceCondition, string> = { NEW: 'nuevo', REFURBISHED: 'reacondicionado', USED: 'segunda-mano' };
export const CONDITION_FROM_SLUG: Record<string, DeviceCondition> = { nuevo: 'NEW', reacondicionado: 'REFURBISHED', 'segunda-mano': 'USED' };

export const GRADE_LABEL: Record<CosmeticGrade, string> = {
  EXCELLENT: 'Excelente',
  VERY_GOOD: 'Muy bueno',
  GOOD: 'Correcto'
};

export const GRADE_DESCRIPTION: Record<CosmeticGrade, string> = {
  EXCELLENT: 'Prácticamente sin marcas de uso visibles.',
  VERY_GOOD: 'Microarañazos leves, apenas perceptibles a simple vista.',
  GOOD: 'Marcas de uso visibles en pantalla o carcasa.'
};

export const STATUS_LABEL: Record<ProductStatus, string> = { DRAFT: 'Borrador', PUBLISHED: 'Publicado', ARCHIVED: 'Archivado' };

export function storageLabel(gb: number | null | undefined): string | null {
  if (gb == null) return null;
  return gb >= 1024 && gb % 1024 === 0 ? `${gb / 1024} TB` : `${gb} GB`;
}

type VariantLike = { storageGb: number | null; optionLabel: string | null; color: string | null; grade: CosmeticGrade | null };

export function variantLabel(v: VariantLike): string {
  return [storageLabel(v.storageGb) ?? v.optionLabel, v.grade ? `Estado ${GRADE_LABEL[v.grade].toLowerCase()}` : null, v.color]
    .filter(Boolean)
    .join(' · ');
}

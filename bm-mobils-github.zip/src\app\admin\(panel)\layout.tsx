import type { Metadata } from 'next';
import Link from 'next/link';
import { ExternalLink } from 'lucide-react';
import { requirePermission } from '@/lib/auth';
import { db } from '@/lib/db';
import { can, ROLE_LABEL } from '@/lib/permissions';
import { logoutAction } from '@/app/actions/auth';
import { AdminNav, type NavItem } from '@/components/admin/admin-nav';

export const metadata: Metadata = { title: { default: 'Panel', template: '%s · Panel BM Mobils' }, robots: { index: false, follow: false } };
export const dynamic = 'force-dynamic';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await requirePermission('admin:access');
  const [toShip, unread] = await Promise.all([
    db.order.count({ where: { status: { in: ['PAID', 'PREPARING'] } } }),
    can(user.role, 'messages:read') ? db.contactMessage.count({ where: { handled: false } }) : 0
  ]);
  const items: NavItem[] = [
    { href: '/admin', label: 'Resumen', icon: 'dashboard' },
    { href: '/admin/pedidos', label: 'Pedidos', icon: 'orders', badge: toShip },
    { href: '/admin/productos', label: 'Productos', icon: 'products' },
    ...(can(user.role, 'customers:read') ? [{ href: '/admin/clientes', label: 'Clientes', icon: 'customers' as const }] : []),
    ...(can(user.role, 'coupons:manage') ? [{ href: '/admin/cupones', label: 'Cupones', icon: 'coupons' as const }] : []),
    ...(can(user.role, 'messages:read') ? [{ href: '/admin/mensajes', label: 'Mensajes', icon: 'messages' as const, badge: unread }] : []),
    ...(can(user.role, 'content:manage') ? [{ href: '/admin/paginas', label: 'Páginas', icon: 'pages' as const }] : []),
    ...(can(user.role, 'settings:manage') ? [{ href: '/admin/configuracion', label: 'Configuración', icon: 'settings' as const }] : [])
  ];

  return (
    <div className="min-h-dvh bg-soft lg:grid lg:grid-cols-[232px_1fr]">
      <aside className="border-b border-line bg-soft p-3 lg:sticky lg:top-0 lg:h-dvh lg:border-r lg:border-b-0 lg:p-4">
        <div className="mb-3 flex items-center justify-between lg:mb-6">
          <Link href="/admin" className="flex items-center gap-2 font-bold">
            <span className="grid size-8 place-items-center rounded-[9px] bg-ink text-[13px] text-white">BM</span>
            Panel
          </Link>
          <Link href="/" target="_blank" className="inline-flex items-center gap-1 text-xs font-medium text-muted hover:text-ink">Ver tienda<ExternalLink className="size-3.5" aria-hidden /></Link>
        </div>
        <AdminNav items={items} />
        <div className="mt-4 hidden border-t border-line pt-4 text-sm lg:block">
          <p className="truncate font-medium">{user.name}</p>
          <p className="text-xs text-muted">{ROLE_LABEL[user.role]}</p>
          <form action={logoutAction}><button type="submit" className="mt-2 text-xs font-semibold text-brand hover:underline">Cerrar sesión</button></form>
        </div>
      </aside>
      <main className="min-w-0 p-4 sm:p-6 lg:p-8">{children}</main>
    </div>
  );
}

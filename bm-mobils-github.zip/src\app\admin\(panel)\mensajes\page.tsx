import { requirePermission } from '@/lib/auth';
import { db } from '@/lib/db';
import { toggleMessageAction } from '@/app/admin/actions/misc';
import { ActionForm } from '@/components/admin/action-form';
import { PageHeader } from '@/components/admin/ui';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export const metadata = { title: 'Mensajes' };

export default async function MessagesPage() {
  await requirePermission('messages:read');
  const messages = await db.contactMessage.findMany({ orderBy: [{ handled: 'asc' }, { createdAt: 'desc' }], take: 100 });
  const date = new Intl.DateTimeFormat('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Madrid' });
  return (
    <>
      <PageHeader title="Mensajes de contacto" subtitle="Mensajes enviados desde el formulario de la web." />
      {messages.length === 0 ? <p className="rounded-card border border-line bg-white p-8 text-center text-sm text-muted">No hay mensajes.</p> : (
        <ul className="space-y-3">
          {messages.map((m) => (
            <li key={m.id} className={`rounded-card border border-line bg-white p-5 ${m.handled ? 'opacity-60' : ''}`}>
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <strong>{m.name}</strong>
                <a href={`mailto:${m.email}?subject=${encodeURIComponent('Re: tu consulta')}`} className="text-brand hover:underline">{m.email}</a>
                {m.orderNumber && <Badge tone="gray">Pedido {m.orderNumber}</Badge>}
                <span className="text-muted">{date.format(m.createdAt)}</span>
                <ActionForm action={toggleMessageAction} className="ml-auto">
                  <input type="hidden" name="messageId" value={m.id} />
                  <Button type="submit" size="sm" variant="outline">{m.handled ? 'Marcar pendiente' : 'Marcar atendido'}</Button>
                </ActionForm>
              </div>
              <p className="mt-2 text-sm whitespace-pre-line text-ink-2">{m.message}</p>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

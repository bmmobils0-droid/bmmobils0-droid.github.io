'use client';

import { useSearchParams } from 'next/navigation';
import { useRef, useState } from 'react';
import { SlidersHorizontal, X } from 'lucide-react';
import type { Facets } from '@/lib/catalog/queries';
import { CONDITION_LABEL, CONDITION_SLUG } from '@/lib/labels';
import { cn } from '@/lib/cn';
import { Button } from '../ui/button';
import { useCatalog } from './catalog-shell';

type Group = { param: string; title: string; options: { value: string; label: string; count: number; hex?: string | null }[] };

export function CatalogFilters({ facets, fixed, total }: { facets: Facets; fixed?: { brand?: boolean; condition?: boolean }; total: number }) {
  const params = useSearchParams();
  const { setParams, pending } = useCatalog();
  const drawer = useRef<HTMLDialogElement>(null);

  const selected = (param: string) => (params.get(param) ?? '').split(',').filter(Boolean);
  const toggle = (param: string, value: string) =>
    setParams((p) => {
      const cur = new Set((p.get(param) ?? '').split(',').filter(Boolean));
      if (cur.has(value)) cur.delete(value); else cur.add(value);
      if (cur.size) p.set(param, [...cur].join(',')); else p.delete(param);
    });

  const groups: Group[] = [];
  if (!fixed?.condition && facets.conditions.length > 1)
    groups.push({ param: 'estado', title: 'Estado', options: facets.conditions.map((c) => ({ value: CONDITION_SLUG[c.value], label: CONDITION_LABEL[c.value], count: c.count })) });
  if (facets.categories.length > 1) groups.push({ param: 'categoria', title: 'Categoría', options: facets.categories });
  if (!fixed?.brand && facets.brands.length > 1) groups.push({ param: 'marca', title: 'Marca', options: facets.brands });
  if (facets.models.length > 1) groups.push({ param: 'modelo', title: 'Modelo', options: facets.models });
  if (facets.storage.length > 1) groups.push({ param: 'capacidad', title: 'Almacenamiento', options: facets.storage });
  if (facets.colors.length > 1) groups.push({ param: 'color', title: 'Color', options: facets.colors });

  const body = (
    <div className="divide-y divide-line">
      <div className="pb-4">
        <label className="flex cursor-pointer items-center justify-between gap-3 text-sm font-medium">
          Solo disponibles
          <input
            type="checkbox"
            role="switch"
            checked={params.get('disponible') === '1'}
            onChange={(e) => setParams((p) => (e.target.checked ? p.set('disponible', '1') : p.delete('disponible')))}
            className="peer sr-only"
          />
          <span aria-hidden className="relative h-6 w-10 rounded-full bg-line-strong transition peer-checked:bg-ink peer-focus-visible:ring-2 peer-focus-visible:ring-brand after:absolute after:top-0.5 after:left-0.5 after:size-5 after:rounded-full after:bg-white after:shadow after:transition peer-checked:after:translate-x-4" />
        </label>
      </div>
      {groups.map((g) => (
        <fieldset key={g.param} className="py-4">
          <legend className="mb-2.5 text-sm font-semibold tracking-tight">{g.title}</legend>
          <div className="max-h-64 space-y-0.5 overflow-auto pr-1">
            {g.options.map((o) => {
              const checked = selected(g.param).includes(o.value);
              return (
                <label key={o.value} className="flex cursor-pointer items-center gap-2.5 py-1 text-sm text-ink-2 hover:text-ink">
                  <input type="checkbox" checked={checked} onChange={() => toggle(g.param, o.value)} className="size-[18px] flex-none rounded accent-ink" />
                  {o.hex && <span className="size-3.5 rounded-full border border-black/15" style={{ background: o.hex }} aria-hidden />}
                  <span className="flex-1">{o.label}</span>
                  <span className="text-[12.5px] text-muted">{o.count}</span>
                </label>
              );
            })}
          </div>
        </fieldset>
      ))}
      {facets.hasBattery && (
        <fieldset className="py-4">
          <legend className="mb-2.5 text-sm font-semibold tracking-tight">Salud de batería comprobada</legend>
          {['80', '85', '90'].map((v) => (
            <label key={v} className="flex cursor-pointer items-center gap-2.5 py-1 text-sm text-ink-2">
              <input type="radio" name="bateria" checked={params.get('bateria') === v} onChange={() => setParams((p) => p.set('bateria', v))} className="size-[18px] accent-ink" />
              {v} % o más
            </label>
          ))}
          {params.get('bateria') && <button type="button" className="mt-1 text-[13px] font-medium text-brand" onClick={() => setParams((p) => p.delete('bateria'))}>Quitar</button>}
        </fieldset>
      )}
      <fieldset className="py-4">
        <legend className="mb-2.5 text-sm font-semibold tracking-tight">Precio (€)</legend>
        {/* La clave reinicia los campos cuando cambia la URL (p. ej. al quitar el filtro desde un chip). */}
        <PriceFilter key={`${params.get('min') ?? ''}|${params.get('max') ?? ''}`} initialMin={params.get('min') ?? ''} initialMax={params.get('max') ?? ''} maxHint={facets.maxPriceCents} />
      </fieldset>
    </div>
  );

  return (
    <>
      <aside className="sticky top-[136px] hidden max-h-[calc(100vh-156px)] overflow-auto pr-1.5 lg:block" aria-label="Filtros">{body}</aside>
      <div className="lg:hidden">
        <Button variant="outline" size="sm" onClick={() => drawer.current?.showModal()}>
          <SlidersHorizontal className="size-4" aria-hidden />
          Filtros
        </Button>
        <dialog ref={drawer} aria-label="Filtros" className="m-0 h-dvh max-h-none w-[min(380px,92%)] bg-white p-0 backdrop:bg-ink/40" onClick={(e) => { if (e.target === drawer.current) drawer.current?.close(); }}>
          <div className="flex h-full flex-col">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <h2 className="text-lg font-semibold">Filtros</h2>
              <button type="button" onClick={() => drawer.current?.close()} className="grid size-10 place-items-center rounded-full hover:bg-soft" aria-label="Cerrar filtros"><X className="size-5" /></button>
            </div>
            <div className="flex-1 overflow-auto px-5 py-4">{body}</div>
            <div className="border-t border-line p-4">
              <Button className={cn('w-full')} onClick={() => drawer.current?.close()} disabled={pending}>
                {pending ? 'Actualizando…' : `Ver ${total} ${total === 1 ? 'resultado' : 'resultados'}`}
              </Button>
            </div>
          </div>
        </dialog>
      </div>
    </>
  );
}

function PriceFilter({ initialMin, initialMax, maxHint }: { initialMin: string; initialMax: string; maxHint: number }) {
  const { setParams } = useCatalog();
  const [min, setMin] = useState(initialMin);
  const [max, setMax] = useState(initialMax);
  const apply = () => {
    const clean = (v: string) => (v && Number(v) >= 0 ? String(Math.floor(Number(v))) : '');
    const a = clean(min), b = clean(max);
    if (a === initialMin && b === initialMax) return;
    setParams((p) => {
      if (a) p.set('min', a); else p.delete('min');
      if (b) p.set('max', b); else p.delete('max');
    });
  };
  const cls = 'h-10 w-full rounded-lg border border-line-strong px-2.5 text-sm outline-none focus:border-ink';
  return (
    <form className="flex items-center gap-2" onSubmit={(e) => { e.preventDefault(); apply(); }}>
      <label className="sr-only" htmlFor="f-min">Precio mínimo</label>
      <input id="f-min" inputMode="numeric" type="number" min={0} value={min} onChange={(e) => setMin(e.target.value)} onBlur={apply} placeholder="Mín." className={cls} />
      <span aria-hidden>–</span>
      <label className="sr-only" htmlFor="f-max">Precio máximo</label>
      <input id="f-max" inputMode="numeric" type="number" min={0} value={max} onChange={(e) => setMax(e.target.value)} onBlur={apply} placeholder={maxHint ? `${Math.ceil(maxHint / 100)}` : 'Máx.'} className={cls} />
      <button type="submit" className="sr-only">Aplicar precio</button>
    </form>
  );
}

export function ActiveFilters({ chips }: { chips: { param: string; value: string; label: string }[] }) {
  const { setParams } = useCatalog();
  if (!chips.length) return null;
  return (
    <div className="mb-4 flex flex-wrap items-center gap-2">
      {chips.map((c) => (
        <button
          key={`${c.param}:${c.value}`}
          type="button"
          onClick={() =>
            setParams((p) => {
              const rest = (p.get(c.param) ?? '').split(',').filter((v) => v && v !== c.value);
              if (rest.length && c.value) p.set(c.param, rest.join(',')); else p.delete(c.param);
            })
          }
          className="inline-flex h-8 items-center gap-1.5 rounded-full border border-line bg-soft pr-2 pl-3 text-[13px] font-medium hover:border-ink"
          aria-label={`Quitar filtro ${c.label}`}
        >
          {c.label}
          <X className="size-3.5" aria-hidden />
        </button>
      ))}
      <button
        type="button"
        className="text-[13px] font-semibold text-brand hover:underline"
        onClick={() => setParams((p) => { for (const k of [...p.keys()]) if (k !== 'q' && k !== 'orden') p.delete(k); })}
      >
        Eliminar filtros
      </button>
    </div>
  );
}

export function SortSelect({ options, value }: { options: Record<string, string>; value: string }) {
  const { setParams } = useCatalog();
  return (
    <label className="flex items-center gap-2 text-sm text-muted">
      <span className="hidden sm:inline">Ordenar por</span>
      <select
        value={value}
        onChange={(e) => setParams((p) => (e.target.value === 'recomendados' ? p.delete('orden') : p.set('orden', e.target.value)))}
        className="h-10 max-w-[180px] cursor-pointer appearance-none rounded-full border border-line-strong bg-white bg-[url('data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20width=%2212%22%20height=%2212%22%20viewBox=%220%200%2024%2024%22%20fill=%22none%22%20stroke=%22%230b0b0f%22%20stroke-width=%222.5%22%3E%3Cpath%20d=%22m6%209%206%206%206-6%22/%3E%3C/svg%3E')] bg-[position:right_14px_center] bg-no-repeat pr-9 pl-3.5 font-medium text-ink outline-none focus:border-ink"
      >
        {Object.entries(options).map(([k, label]) => <option key={k} value={k}>{label}</option>)}
      </select>
    </label>
  );
}

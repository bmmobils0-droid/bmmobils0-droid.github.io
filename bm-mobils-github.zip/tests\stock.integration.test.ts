/**
 * Prueba de integración contra PostgreSQL (npm run db:local): comprueba que la reserva
 * atómica de stock que usa el checkout no permite vender más unidades de las que hay,
 * incluso con muchas compras simultáneas. Se omite si no hay base de datos disponible.
 */
import 'dotenv/config';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient } from '@/generated/prisma/client';

const db = new PrismaClient({ adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }) });
let available = false;
let variantId = '';
let productId = '';

beforeAll(async () => {
  try {
    await db.$queryRaw`SELECT 1`;
    available = true;
  } catch {
    return;
  }
  const brand = await db.brand.findFirstOrThrow();
  const category = await db.category.findFirstOrThrow();
  const p = await db.product.create({
    data: {
      slug: `test-stock-${Date.now()}`, name: 'Test stock', model: 'Test', brandId: brand.id, categoryId: category.id,
      variants: { create: { sku: `TEST-STOCK-${Date.now()}`, priceCents: 1000, stock: 5 } }
    },
    include: { variants: true }
  });
  productId = p.id;
  variantId = p.variants[0].id;
});

afterAll(async () => {
  if (productId) await db.product.delete({ where: { id: productId } });
  await db.$disconnect();
});

describe('reserva de stock', () => {
  it('con 20 compras simultáneas de 1 unidad y stock 5, solo 5 tienen éxito', async () => {
    if (!available) return;
    const attempts = await Promise.all(
      Array.from({ length: 20 }, () =>
        db.$transaction(async (tx) => {
          const r = await tx.productVariant.updateMany({ where: { id: variantId, stock: { gte: 1 } }, data: { stock: { decrement: 1 } } });
          return r.count;
        })
      )
    );
    expect(attempts.filter((c) => c === 1)).toHaveLength(5);
    const v = await db.productVariant.findUniqueOrThrow({ where: { id: variantId } });
    expect(v.stock).toBe(0);
  });

  it('la base de datos rechaza un stock negativo (restricción CHECK)', async () => {
    if (!available) return;
    await expect(db.productVariant.update({ where: { id: variantId }, data: { stock: -1 } })).rejects.toThrow();
  });
});

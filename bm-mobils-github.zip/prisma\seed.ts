/**
 * Datos iniciales. Idempotente: se puede ejecutar varias veces.
 *
 * - Configuración, marcas, categorías, tarifas de envío de EJEMPLO y páginas legales con
 *   marcadores [PENDIENTE] que el titular debe completar.
 * - Productos de DEMOSTRACIÓN (isDemo = true): se muestran con aviso, no se indexan y no se
 *   pueden comprar hasta que un administrador confirme su existencia y desmarque "Demostración".
 *   No incluyen salud de batería ni detalles de estado inventados: se completan al revisar cada unidad.
 *
 * Uso: npm run db:seed
 */
import 'dotenv/config';
import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient } from '../src/generated/prisma/client';
import type { CosmeticGrade, DeviceCondition } from '../src/generated/prisma/enums';

const db = new PrismaClient({ adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }) });

const BRANDS = [
  ['Apple', 'apple'], ['Samsung', 'samsung'], ['Google', 'google'], ['Xiaomi', 'xiaomi'], ['BM Mobils', 'bm-mobils']
] as const;

const CATEGORIES: { slug: string; name: string; parent?: string; description?: string }[] = [
  { slug: 'moviles', name: 'Móviles', description: 'Smartphones nuevos, reacondicionados y de segunda mano.' },
  { slug: 'tablets', name: 'Tablets', description: 'iPad, Galaxy Tab y otras tablets.' },
  { slug: 'accesorios', name: 'Accesorios', description: 'Fundas, protectores, cargadores y cables.' },
  { slug: 'fundas', name: 'Fundas', parent: 'accesorios' },
  { slug: 'protectores', name: 'Protectores de pantalla', parent: 'accesorios' },
  { slug: 'cargadores', name: 'Cargadores', parent: 'accesorios' },
  { slug: 'cables', name: 'Cables y adaptadores', parent: 'accesorios' },
  { slug: 'audio-y-wearables', name: 'Audio y wearables', description: 'Auriculares, smartwatches y pulseras.' },
  { slug: 'auriculares', name: 'Auriculares', parent: 'audio-y-wearables' },
  { slug: 'smartwatches', name: 'Smartwatches', parent: 'audio-y-wearables' }
];

const LEGAL_NOTE = '**[PENDIENTE DE REVISIÓN LEGAL]** Este texto es una plantilla. Complétalo con los datos reales del titular y revísalo con un asesor antes de publicar la tienda.';

const PAGES: { slug: string; title: string; content: string }[] = [
  {
    slug: 'aviso-legal',
    title: 'Aviso legal',
    content: `${LEGAL_NOTE}

## Datos identificativos
En cumplimiento de la Ley 34/2002, de Servicios de la Sociedad de la Información y de Comercio Electrónico (LSSI-CE):
- Titular: [PENDIENTE: razón social o nombre]
- NIF/CIF: [PENDIENTE]
- Domicilio: [PENDIENTE]
- Email: [PENDIENTE]
- Datos registrales: [PENDIENTE, si procede]

## Condiciones de uso
El acceso a este sitio web atribuye la condición de usuario e implica la aceptación de este aviso legal.`
  },
  {
    slug: 'privacidad',
    title: 'Política de privacidad',
    content: `${LEGAL_NOTE}

## Responsable del tratamiento
[PENDIENTE: titular, NIF, domicilio y email de contacto para protección de datos]

## Qué datos tratamos y para qué
- Datos de contacto y envío: gestionar tus pedidos, envíos, devoluciones y garantías.
- Datos de facturación: cumplir obligaciones fiscales.
- Mensajes del formulario de contacto: responder a tu consulta.

## Base jurídica
Ejecución del contrato de compraventa y cumplimiento de obligaciones legales.

## Destinatarios
Proveedor de pagos (Stripe), empresa de transporte y proveedor de alojamiento. [PENDIENTE: revisar y completar]

## Conservación
[PENDIENTE: plazos de conservación]

## Tus derechos
Puedes ejercer los derechos de acceso, rectificación, supresión, oposición, limitación y portabilidad escribiendo a [PENDIENTE]. También puedes reclamar ante la Agencia Española de Protección de Datos (aepd.es).`
  },
  {
    slug: 'cookies',
    title: 'Política de cookies',
    content: `${LEGAL_NOTE}

## Cookies que utilizamos
Esta web utiliza únicamente cookies técnicas necesarias para su funcionamiento:
- **bm_session**: mantiene la sesión iniciada.
- **bm_cart**: conserva tu carrito.
- **bm_consent**: recuerda tus preferencias de cookies.

No se utilizan cookies de analítica ni de publicidad. Si en el futuro se añaden, solo se activarán después de que des tu consentimiento en el aviso de cookies.`
  },
  {
    slug: 'condiciones',
    title: 'Condiciones generales de contratación',
    content: `${LEGAL_NOTE}

## Objeto
Estas condiciones regulan la compra de productos a través de esta web por parte de consumidores residentes en España.

## Precios e impuestos
Todos los precios incluyen el IVA aplicable. Los gastos de envío se muestran antes de finalizar la compra. Los envíos a Canarias, Ceuta y Melilla tienen un régimen fiscal distinto. [PENDIENTE: definir el tratamiento con el asesor fiscal]

## Proceso de compra y pago
El contrato se perfecciona cuando se confirma el pago. El pago se procesa a través de Stripe; no almacenamos los datos de tu tarjeta.

## Derecho de desistimiento
Dispones de 14 días naturales desde la entrega para desistir del contrato sin indicar el motivo, conforme al Real Decreto Legislativo 1/2007. [PENDIENTE: forma de ejercerlo y quién asume los costes de devolución]

## Garantías
Consulta la página de garantías.

## Legislación aplicable
Legislación española. [PENDIENTE: información sobre resolución de litigios]`
  },
  {
    slug: 'devoluciones',
    title: 'Política de devoluciones',
    content: `Dispones de 14 días naturales desde la recepción del pedido para ejercer tu derecho de desistimiento.

## Cómo solicitar una devolución
- Escríbenos desde la página de [contacto](/contacto) indicando tu número de pedido.
- Te indicaremos cómo enviar el producto.
- Reembolsaremos el importe por el mismo método de pago utilizado.

[PENDIENTE: estado en el que debe devolverse el producto, quién asume los gastos de envío de la devolución y plazos de reembolso]`
  },
  {
    slug: 'garantia',
    title: 'Información sobre garantías',
    content: `Cada ficha de producto indica las condiciones de garantía aplicables. Todos los productos cuentan, como mínimo, con la garantía legal de conformidad que establece la normativa de consumo vigente para productos nuevos, reacondicionados y de segunda mano.

## Qué cubre
Las faltas de conformidad del producto. No cubre daños por golpes, líquidos, uso indebido o manipulación por terceros.

## Cómo gestionarla
Contacta con nosotros desde la página de [contacto](/contacto) con tu número de pedido y una descripción del problema.

[PENDIENTE: confirmar plazos concretos para productos reacondicionados y de segunda mano]`
  },
  {
    slug: 'envios',
    title: 'Información de envíos',
    content: `Enviamos a toda España: península, Illes Balears, Canarias, Ceuta y Melilla.

## Métodos y costes
Los métodos disponibles y su coste se muestran en el checkout según tu código postal, antes de pagar.

## Canarias, Ceuta y Melilla
Estos territorios tienen un régimen fiscal distinto y los envíos pueden estar sujetos a trámites aduaneros. Te contactaremos para confirmar las condiciones antes de enviar tu pedido.

[PENDIENTE: transportistas y plazos orientativos]`
  }
];

type V = { storageGb?: number; optionLabel?: string; color?: string; colorHex?: string; grade?: CosmeticGrade; price: number; compareAt?: number; stock: number };
type P = {
  slug: string; name: string; model: string; brand: string; category: string; condition: DeviceCondition; featured?: boolean;
  description: string; specs: [string, string][]; variants: V[]; conditionDetails?: string;
};

const PENDING_UNIT = 'Pendiente de completar tras la revisión de la unidad: estado estético, estado técnico y, si se comprueba, salud de batería.';

const PRODUCTS: P[] = [
  {
    slug: 'iphone-13-segunda-mano', name: 'iPhone 13', model: 'iPhone 13', brand: 'apple', category: 'moviles', condition: 'USED', featured: true,
    description: 'iPhone 13 de segunda mano.', conditionDetails: PENDING_UNIT,
    specs: [['Pantalla', '6,1"'], ['Chip', 'A15 Bionic'], ['Conector', 'Lightning']],
    variants: [
      { storageGb: 128, color: 'Medianoche', colorHex: '#2E3642', price: 329, stock: 2 },
      { storageGb: 128, color: 'Blanco estelar', colorHex: '#F0EDE6', price: 329, stock: 1 },
      { storageGb: 256, color: 'Medianoche', colorHex: '#2E3642', price: 369, stock: 1 }
    ]
  },
  {
    slug: 'iphone-14-reacondicionado', name: 'iPhone 14', model: 'iPhone 14', brand: 'apple', category: 'moviles', condition: 'REFURBISHED', featured: true,
    description: 'iPhone 14 reacondicionado. Elige el estado estético que prefieras.', conditionDetails: PENDING_UNIT,
    specs: [['Pantalla', '6,1"'], ['Chip', 'A15 Bionic'], ['Conector', 'Lightning']],
    variants: [
      { storageGb: 128, color: 'Azul', colorHex: '#A7BCD0', grade: 'GOOD', price: 409, compareAt: 499, stock: 3 },
      { storageGb: 128, color: 'Azul', colorHex: '#A7BCD0', grade: 'VERY_GOOD', price: 439, compareAt: 499, stock: 2 },
      { storageGb: 128, color: 'Medianoche', colorHex: '#2E3642', grade: 'EXCELLENT', price: 469, compareAt: 529, stock: 1 },
      { storageGb: 256, color: 'Medianoche', colorHex: '#2E3642', grade: 'VERY_GOOD', price: 499, compareAt: 579, stock: 1 }
    ]
  },
  {
    slug: 'iphone-15-pro-reacondicionado', name: 'iPhone 15 Pro', model: 'iPhone 15 Pro', brand: 'apple', category: 'moviles', condition: 'REFURBISHED', featured: true,
    description: 'iPhone 15 Pro reacondicionado con conector USB-C.', conditionDetails: PENDING_UNIT,
    specs: [['Pantalla', '6,1"'], ['Chip', 'A17 Pro'], ['Conector', 'USB-C']],
    variants: [
      { storageGb: 128, color: 'Titanio natural', colorHex: '#BAB4A9', grade: 'VERY_GOOD', price: 729, compareAt: 849, stock: 2 },
      { storageGb: 256, color: 'Titanio natural', colorHex: '#BAB4A9', grade: 'EXCELLENT', price: 829, compareAt: 949, stock: 1 },
      { storageGb: 256, color: 'Titanio negro', colorHex: '#3A3A3C', grade: 'VERY_GOOD', price: 799, compareAt: 949, stock: 2 }
    ]
  },
  {
    slug: 'iphone-16-pro-max', name: 'iPhone 16 Pro Max', model: 'iPhone 16 Pro Max', brand: 'apple', category: 'moviles', condition: 'NEW', featured: true,
    description: 'iPhone 16 Pro Max nuevo y precintado.',
    specs: [['Pantalla', '6,9"'], ['Chip', 'A18 Pro'], ['Conector', 'USB-C']],
    variants: [
      { storageGb: 256, color: 'Titanio desierto', colorHex: '#C4A988', price: 1329, stock: 3 },
      { storageGb: 256, color: 'Titanio negro', colorHex: '#3A3A3C', price: 1329, stock: 2 },
      { storageGb: 512, color: 'Titanio desierto', colorHex: '#C4A988', price: 1579, stock: 1 }
    ]
  },
  {
    slug: 'galaxy-s24-reacondicionado', name: 'Samsung Galaxy S24', model: 'Galaxy S24', brand: 'samsung', category: 'moviles', condition: 'REFURBISHED', featured: true,
    description: 'Galaxy S24 reacondicionado.', conditionDetails: PENDING_UNIT,
    specs: [['Pantalla', '6,2"'], ['Procesador', 'Exynos 2400'], ['Conector', 'USB-C']],
    variants: [
      { storageGb: 128, color: 'Onyx Black', colorHex: '#2E2F33', grade: 'GOOD', price: 399, compareAt: 499, stock: 2 },
      { storageGb: 256, color: 'Marble Grey', colorHex: '#C9CACC', grade: 'VERY_GOOD', price: 459, compareAt: 559, stock: 2 }
    ]
  },
  {
    slug: 'galaxy-s25', name: 'Samsung Galaxy S25', model: 'Galaxy S25', brand: 'samsung', category: 'moviles', condition: 'NEW', featured: true,
    description: 'Galaxy S25 nuevo y precintado.',
    specs: [['Pantalla', '6,2"'], ['Procesador', 'Snapdragon 8 Elite for Galaxy'], ['Conector', 'USB-C']],
    variants: [
      { storageGb: 128, color: 'Navy', colorHex: '#2E3A5C', price: 799, compareAt: 909, stock: 4 },
      { storageGb: 256, color: 'Icyblue', colorHex: '#CFE0EC', price: 859, compareAt: 969, stock: 3 }
    ]
  },
  {
    slug: 'funda-silicona-iphone-15', name: 'Funda de silicona para iPhone 15', model: 'Funda silicona iPhone 15', brand: 'bm-mobils', category: 'fundas', condition: 'NEW',
    description: 'Funda de silicona de tacto suave.',
    specs: [['Compatibilidad', 'iPhone 15'], ['Material', 'Silicona']],
    variants: [
      { color: 'Negro', colorHex: '#232427', price: 19.95, stock: 20 },
      { color: 'Azul marino', colorHex: '#2E3A5C', price: 19.95, stock: 15 },
      { color: 'Lavanda', colorHex: '#B9A9D6', price: 19.95, stock: 10 }
    ]
  },
  {
    slug: 'funda-galaxy-s25', name: 'Funda fina para Galaxy S25', model: 'Funda Galaxy S25', brand: 'bm-mobils', category: 'fundas', condition: 'NEW',
    description: 'Funda fina con acabado mate.',
    specs: [['Compatibilidad', 'Galaxy S25'], ['Material', 'TPU']],
    variants: [{ color: 'Negro', colorHex: '#232427', price: 14.95, stock: 25 }]
  },
  {
    slug: 'protector-cristal-iphone-15', name: 'Protector de cristal templado para iPhone 15', model: 'Protector iPhone 15', brand: 'bm-mobils', category: 'protectores', condition: 'NEW',
    description: 'Protector de cristal templado.',
    specs: [['Compatibilidad', 'iPhone 15']],
    variants: [{ color: 'Transparente', colorHex: '#2D3E57', price: 9.95, stock: 40 }]
  },
  {
    slug: 'cargador-usb-c-20w', name: 'Cargador USB-C 20 W', model: 'Cargador USB-C 20 W', brand: 'bm-mobils', category: 'cargadores', condition: 'NEW', featured: true,
    description: 'Cargador de pared con conector USB-C.',
    specs: [['Potencia', '20 W'], ['Conector', 'USB-C'], ['Enchufe', 'Tipo europeo']],
    variants: [{ color: 'Blanco', colorHex: '#F4F4F4', price: 14.95, stock: 50 }]
  },
  {
    slug: 'cargador-usb-c-45w', name: 'Cargador USB-C 45 W', model: 'Cargador USB-C 45 W', brand: 'bm-mobils', category: 'cargadores', condition: 'NEW',
    description: 'Cargador de pared con conector USB-C.',
    specs: [['Potencia', '45 W'], ['Conector', 'USB-C'], ['Enchufe', 'Tipo europeo']],
    variants: [{ color: 'Negro', colorHex: '#2A2C30', price: 24.95, compareAt: 29.95, stock: 30 }]
  },
  {
    slug: 'cable-usb-c-usb-c', name: 'Cable USB-C a USB-C', model: 'Cable USB-C', brand: 'bm-mobils', category: 'cables', condition: 'NEW',
    description: 'Cable de carga y datos.',
    specs: [['Conectores', 'USB-C a USB-C']],
    variants: [
      { optionLabel: '1 m', color: 'Blanco', colorHex: '#ECECEC', price: 9.95, stock: 60 },
      { optionLabel: '2 m', color: 'Blanco', colorHex: '#ECECEC', price: 12.95, stock: 40 }
    ]
  }
];

async function main() {
  await db.storeSettings.upsert({
    where: { id: 1 },
    update: {},
    create: {
      id: 1,
      infoBar: ['Envíos a toda España', 'Garantía según las condiciones de cada producto', 'Pago seguro', 'Atención al cliente'],
      paymentMethods: ['card', 'apple_pay', 'google_pay']
    }
  });

  for (const [name, slug] of BRANDS) await db.brand.upsert({ where: { slug }, update: {}, create: { name, slug } });

  for (const [i, c] of CATEGORIES.entries()) {
    const parent = c.parent ? await db.category.findUnique({ where: { slug: c.parent } }) : null;
    await db.category.upsert({
      where: { slug: c.slug },
      update: {},
      create: { slug: c.slug, name: c.name, description: c.description, position: i, parentId: parent?.id }
    });
  }

  if ((await db.shippingRate.count()) === 0) {
    await db.shippingRate.createMany({
      data: [
        { name: 'Envío estándar', description: 'Tarifa de ejemplo: revisar en el panel', priceCents: 495, zones: ['PENINSULA'], position: 0 },
        { name: 'Envío urgente', description: 'Tarifa de ejemplo: revisar en el panel', priceCents: 995, zones: ['PENINSULA'], position: 1 },
        { name: 'Envío a Baleares', description: 'Tarifa de ejemplo: revisar en el panel', priceCents: 995, zones: ['BALEARES'], position: 2 },
        { name: 'Envío a Canarias, Ceuta y Melilla', description: 'Tarifa de ejemplo: revisar en el panel', priceCents: 1495, zones: ['CANARIAS', 'CEUTA_MELILLA'], position: 3 }
      ]
    });
  }

  for (const page of PAGES) {
    await db.page.upsert({ where: { slug: page.slug }, update: {}, create: { ...page, needsLegalReview: true } });
  }

  for (const p of PRODUCTS) {
    if (await db.product.findUnique({ where: { slug: p.slug } })) continue;
    const brand = await db.brand.findUniqueOrThrow({ where: { slug: p.brand } });
    const category = await db.category.findUniqueOrThrow({ where: { slug: p.category } });
    const prices = p.variants.map((v) => Math.round(v.price * 100));
    const product = await db.product.create({
      data: {
        slug: p.slug, name: p.name, model: p.model, brandId: brand.id, categoryId: category.id, condition: p.condition,
        status: 'PUBLISHED', featured: !!p.featured, isDemo: true, description: p.description, conditionDetails: p.conditionDetails,
        specs: p.specs.map(([label, value]) => ({ label, value })), publishedAt: new Date(),
        fromPriceCents: Math.min(...prices),
        maxDiscountPct: Math.max(0, ...p.variants.map((v) => (v.compareAt ? Math.round((1 - v.price / v.compareAt) * 100) : 0))),
        totalStock: p.variants.reduce((s, v) => s + v.stock, 0),
        variants: {
          create: p.variants.map((v, i) => ({
            sku: `DEMO-${p.slug.toUpperCase().replace(/[^A-Z0-9]+/g, '-').slice(0, 30)}-${i + 1}`,
            storageGb: v.storageGb, optionLabel: v.optionLabel, color: v.color, colorHex: v.colorHex, grade: v.grade,
            priceCents: Math.round(v.price * 100), compareAtCents: v.compareAt ? Math.round(v.compareAt * 100) : null,
            stock: v.stock, position: i
          }))
        }
      },
      include: { variants: true }
    });
    await db.inventoryMovement.createMany({
      data: product.variants.map((v) => ({ variantId: v.id, delta: v.stock, reason: 'INITIAL' as const, note: 'Stock de demostración' }))
    });
  }

  console.log('Seed completado.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());

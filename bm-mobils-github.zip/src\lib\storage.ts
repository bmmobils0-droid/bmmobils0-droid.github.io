import 'server-only';
import { mkdir, unlink, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { randomToken } from './crypto';

const MAX_BYTES = 5 * 1024 * 1024;

/** Detecta el formato por la firma del archivo, no por la extensión ni el tipo declarado. */
function sniff(buf: Buffer): { ext: string; mime: string } | null {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { ext: 'jpg', mime: 'image/jpeg' };
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { ext: 'png', mime: 'image/png' };
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return { ext: 'webp', mime: 'image/webp' };
  if (buf.toString('ascii', 4, 12) === 'ftypavif') return { ext: 'avif', mime: 'image/avif' };
  return null;
}

export class UploadError extends Error {}

export async function saveImage(file: File, folder = 'products'): Promise<string> {
  if (file.size === 0) throw new UploadError('El archivo está vacío.');
  if (file.size > MAX_BYTES) throw new UploadError('La imagen supera los 5 MB.');
  const buf = Buffer.from(await file.arrayBuffer());
  const kind = sniff(buf);
  if (!kind) throw new UploadError('Formato no admitido. Usa JPG, PNG, WebP o AVIF.');
  const name = `${folder}/${Date.now().toString(36)}-${randomToken(9)}.${kind.ext}`;

  if (process.env.STORAGE_DRIVER === 'supabase') {
    const base = process.env.SUPABASE_URL?.replace(/\/+$/, '');
    const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const bucket = process.env.SUPABASE_STORAGE_BUCKET || 'product-images';
    if (!base || !key) throw new UploadError('Supabase Storage no está configurado.');
    const res = await fetch(`${base}/storage/v1/object/${bucket}/${name}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': kind.mime, 'x-upsert': 'false', 'Cache-Control': 'max-age=31536000' },
      body: buf
    });
    if (!res.ok) throw new UploadError(`Error al subir la imagen (${res.status}).`);
    return `${base}/storage/v1/object/public/${bucket}/${name}`;
  }

  const dir = path.join(process.cwd(), 'public', 'uploads', folder);
  await mkdir(dir, { recursive: true });
  await writeFile(path.join(process.cwd(), 'public', 'uploads', name), buf);
  return `/uploads/${name}`;
}

export async function deleteImage(url: string): Promise<void> {
  try {
    if (url.startsWith('/uploads/')) {
      const target = path.normalize(path.join(process.cwd(), 'public', url));
      if (target.startsWith(path.join(process.cwd(), 'public', 'uploads'))) await unlink(target);
      return;
    }
    const base = process.env.SUPABASE_URL?.replace(/\/+$/, '');
    const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const bucket = process.env.SUPABASE_STORAGE_BUCKET || 'product-images';
    const prefix = `${base}/storage/v1/object/public/${bucket}/`;
    if (base && key && url.startsWith(prefix)) {
      await fetch(`${base}/storage/v1/object/${bucket}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ prefixes: [url.slice(prefix.length)] })
      });
    }
  } catch (err) {
    console.warn('[storage] No se pudo borrar', url, err);
  }
}

import 'server-only';
import { randomInt, randomUUID } from 'node:crypto';
import type { OrderStatus } from '@/generated/prisma/enums';
import { db, type Tx } from './db';
import { getCartView } from './cart';
import { refreshProductAggregates } from './catalog/aggregates';
import { sendOrderEmail } from './email';
import { requiresTaxReview, zoneForPostalCode } from './geo';
import { orderAccessHash, orderAccessToken } from './order-access';
import { canRefund, canTransition, ORDER_STATUS_LABEL } from './order-status';
import { siteUrl } from './site';
import { getStripe, paymentsConfigured } from './stripe';
import type { checkoutSchema } from './validators';
import type { z } from 'zod';

/** Tiempo que el stock queda reservado mientras el cliente paga (Stripe exige ≥ 30 min). */
const RESERVATION_MINUTES = 31;

export class CheckoutError extends Error {}

function newOrderNumber(): string {
  const d = new Date();
  const date = `${String(d.getFullYear()).slice(2)}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const suffix = Array.from({ length: 5 }, () => alphabet[randomInt(alphabet.length)]).join('');
  return `BM-${date}-${suffix}`;
}

// ---------------------------------------------------------------------------
// Creación del pedido y reserva de stock
// ---------------------------------------------------------------------------

export async function createOrderAndCheckout(input: z.output<typeof checkoutSchema>, userId: string | null): Promise<{ url: string }> {
  if (!paymentsConfigured()) throw new CheckoutError('Los pagos online todavía no están activados en esta tienda. Contacta con nosotros para completar tu compra.');
  const stripe = getStripe()!;

  const zone = zoneForPostalCode(input.postalCode);
  const view = await getCartView({ zone, shippingRateId: input.shippingRateId });
  if (!view) throw new CheckoutError('Tu carrito está vacío.');
  if (view.hasIssues) throw new CheckoutError('Algunos productos de tu carrito ya no están disponibles. Revisa el carrito.');
  if (!view.rate) throw new CheckoutError('El método de envío seleccionado no está disponible para tu dirección.');
  if (view.couponCode && view.totals.couponError) throw new CheckoutError(view.totals.couponError);

  if (view.cart.pendingOrderId) await cancelPendingOrder(view.cart.pendingOrderId, 'Sustituido por un nuevo intento de pago.');

  const orderId = randomUUID();
  const number = newOrderNumber();
  const appliedCoupon = view.couponCode && view.totals.discountCents > 0 ? view.couponCode : null;

  await db.$transaction(async (tx) => {
    for (const line of view.lines) {
      // Reserva atómica: solo descuenta si hay unidades suficientes en este instante.
      const res = await tx.productVariant.updateMany({
        where: { id: line.variantId, isActive: true, stock: { gte: line.quantity } },
        data: { stock: { decrement: line.quantity } }
      });
      if (res.count !== 1) throw new CheckoutError(`No quedan unidades suficientes de ${line.name} (${line.label}).`);
    }
    if (appliedCoupon) {
      const updated = await tx.$executeRaw`UPDATE "Coupon" SET "redemptions" = "redemptions" + 1
        WHERE "code" = ${appliedCoupon} AND "active" = true AND ("maxRedemptions" IS NULL OR "redemptions" < "maxRedemptions")`;
      if (updated !== 1) throw new CheckoutError('El cupón ya no está disponible.');
    }
    await tx.order.create({
      data: {
        id: orderId,
        number,
        userId,
        cartId: view.cart.id,
        subtotalCents: view.totals.subtotalCents,
        discountCents: view.totals.discountCents,
        shippingCents: view.totals.shippingCents,
        taxCents: view.totals.taxCents,
        totalCents: view.totals.totalCents,
        couponCode: appliedCoupon,
        email: input.email,
        phone: input.phone,
        shipFirstName: input.firstName,
        shipLastName: input.lastName,
        shipLine1: input.line1,
        shipLine2: input.line2,
        shipPostalCode: input.postalCode,
        shipCity: input.city,
        shipProvince: input.province,
        shipCountry: input.country,
        shippingZone: zone,
        shippingMethod: view.rate!.name,
        billingName: input.wantsInvoice ? input.billingName : null,
        billingTaxId: input.wantsInvoice ? input.billingTaxId?.toUpperCase() : null,
        billingLine1: input.wantsInvoice ? input.billingLine1 : null,
        billingPostalCode: input.wantsInvoice ? input.billingPostalCode : null,
        billingCity: input.wantsInvoice ? input.billingCity : null,
        billingProvince: input.wantsInvoice ? input.billingProvince : null,
        customerNote: input.customerNote,
        requiresTaxReview: requiresTaxReview(zone),
        accessTokenHash: orderAccessHash(orderId),
        reservationExpiresAt: new Date(Date.now() + RESERVATION_MINUTES * 60_000),
        items: {
          create: view.lines.map((l) => ({
            variantId: l.variantId,
            productId: l.productId,
            productName: l.name,
            variantLabel: l.label,
            sku: l.sku,
            unitPriceCents: l.unitPriceCents,
            quantity: l.quantity,
            taxRate: l.taxRate,
            lineTotalCents: l.lineTotalCents
          }))
        },
        events: { create: { toStatus: 'PENDING_PAYMENT', message: 'Pedido creado. Stock reservado a la espera del pago.' } }
      }
    });
    await tx.inventoryMovement.createMany({
      data: view.lines.map((l) => ({ variantId: l.variantId, delta: -l.quantity, reason: 'RESERVATION' as const, orderId }))
    });
    await tx.cart.update({ where: { id: view.cart.id }, data: { pendingOrderId: orderId } });
    for (const productId of new Set(view.lines.map((l) => l.productId))) await refreshProductAggregates(productId, tx);
  });

  try {
    const order = await db.order.findUniqueOrThrow({ where: { id: orderId }, include: { items: true } });
    const discounts = order.discountCents > 0
      ? [{ coupon: (await stripe.coupons.create({ amount_off: order.discountCents, currency: 'eur', duration: 'once', max_redemptions: 1, name: `Cupón ${order.couponCode}` }, { idempotencyKey: `coupon-${order.id}` })).id }]
      : undefined;
    const session = await stripe.checkout.sessions.create(
      {
        mode: 'payment',
        locale: 'es',
        customer_email: order.email,
        client_reference_id: order.id,
        line_items: order.items.map((i) => ({
          quantity: i.quantity,
          price_data: { currency: 'eur', unit_amount: i.unitPriceCents, product_data: { name: i.productName, ...(i.variantLabel ? { description: i.variantLabel } : {}) } }
        })),
        discounts,
        shipping_options: [
          { shipping_rate_data: { type: 'fixed_amount', display_name: order.shippingMethod, fixed_amount: { amount: order.shippingCents, currency: 'eur' } } }
        ],
        metadata: { orderId: order.id, orderNumber: order.number },
        payment_intent_data: { metadata: { orderId: order.id, orderNumber: order.number } },
        expires_at: Math.floor(order.reservationExpiresAt!.getTime() / 1000),
        success_url: `${siteUrl()}/pedido/${order.number}?t=${orderAccessToken(order.id)}`,
        cancel_url: `${siteUrl()}/checkout?cancelado=1`
      },
      { idempotencyKey: `checkout-${order.id}` }
    );
    if (!session.url) throw new Error('Stripe no devolvió la URL de pago.');
    await db.order.update({ where: { id: order.id }, data: { stripeCheckoutSessionId: session.id } });
    return { url: session.url };
  } catch (err) {
    console.error('[checkout] Error al crear la sesión de pago', err);
    await cancelPendingOrder(orderId, 'No se pudo iniciar el pago con Stripe.', { skipStripe: true });
    throw new CheckoutError('No hemos podido iniciar el pago. Inténtalo de nuevo en unos minutos.');
  }
}

// ---------------------------------------------------------------------------
// Liberación de stock y cancelación
// ---------------------------------------------------------------------------

/** Devuelve al stock lo reservado por un pedido. Idempotente gracias a `stockReleased`. */
async function releaseStock(orderId: string, tx: Tx) {
  const flagged = await tx.order.updateMany({ where: { id: orderId, stockReleased: false }, data: { stockReleased: true } });
  if (flagged.count !== 1) return;
  const order = await tx.order.findUniqueOrThrow({ where: { id: orderId }, include: { items: true } });
  for (const item of order.items) {
    if (!item.variantId) continue;
    await tx.productVariant.update({ where: { id: item.variantId }, data: { stock: { increment: item.quantity } } });
    await tx.inventoryMovement.create({ data: { variantId: item.variantId, delta: item.quantity, reason: 'RELEASE', orderId } });
  }
  if (order.couponCode) {
    await tx.$executeRaw`UPDATE "Coupon" SET "redemptions" = GREATEST("redemptions" - 1, 0) WHERE "code" = ${order.couponCode}`;
  }
  for (const productId of new Set(order.items.map((i) => i.productId).filter((p): p is string => !!p))) {
    await refreshProductAggregates(productId, tx);
  }
}

/**
 * Cancela un pedido pendiente de pago y libera su stock. Antes caduca la sesión de Stripe:
 * si el cliente ya ha pagado, no se cancela (el webhook lo marcará como pagado).
 */
export async function cancelPendingOrder(orderId: string, message: string, opts: { actorId?: string | null; skipStripe?: boolean } = {}): Promise<boolean> {
  const order = await db.order.findUnique({ where: { id: orderId }, select: { status: true, stripeCheckoutSessionId: true } });
  if (!order || order.status !== 'PENDING_PAYMENT') return false;

  const stripe = getStripe();
  if (!opts.skipStripe && stripe && order.stripeCheckoutSessionId) {
    const session = await stripe.checkout.sessions.retrieve(order.stripeCheckoutSessionId);
    if (session.status === 'complete') return false;
    if (session.status === 'open') await stripe.checkout.sessions.expire(session.id);
  }

  const cancelled = await db.$transaction(async (tx) => {
    const res = await tx.order.updateMany({
      where: { id: orderId, status: 'PENDING_PAYMENT' },
      data: { status: 'CANCELLED', paymentStatus: 'CANCELLED', cancelledAt: new Date() }
    });
    if (res.count !== 1) return false;
    await releaseStock(orderId, tx);
    await tx.orderEvent.create({ data: { orderId, fromStatus: 'PENDING_PAYMENT', toStatus: 'CANCELLED', message, actorId: opts.actorId ?? null } });
    await tx.cart.updateMany({ where: { pendingOrderId: orderId }, data: { pendingOrderId: null } });
    return true;
  });
  return cancelled;
}

/** Cancela reservas cuyo plazo de pago ha vencido. Se llama desde el cron y de forma oportunista. */
export async function releaseExpiredReservations(limit = 50): Promise<number> {
  const expired = await db.order.findMany({
    where: { status: 'PENDING_PAYMENT', reservationExpiresAt: { lt: new Date(Date.now() - 2 * 60_000) } },
    select: { id: true },
    take: limit
  });
  let n = 0;
  for (const o of expired) {
    try {
      if (await cancelPendingOrder(o.id, 'Reserva caducada: el pago no se completó a tiempo.')) n++;
    } catch (err) {
      console.error('[reservas] No se pudo cancelar', o.id, err);
    }
  }
  return n;
}

// ---------------------------------------------------------------------------
// Confirmaciones del proveedor de pagos (solo desde el webhook verificado)
// ---------------------------------------------------------------------------

export async function markOrderPaid(p: { orderId: string; sessionId: string; paymentIntentId: string | null; amountTotal: number | null; currency: string | null }) {
  const result = await db.$transaction(async (tx) => {
    const order = await tx.order.findUnique({ where: { id: p.orderId } });
    if (!order) return 'missing' as const;
    if (order.paymentStatus === 'SUCCEEDED') return 'already' as const;

    const review = async (message: string) => {
      await tx.order.update({ where: { id: order.id }, data: { paymentStatus: 'REQUIRES_REVIEW', stripePaymentIntentId: p.paymentIntentId } });
      await tx.orderEvent.create({ data: { orderId: order.id, message } });
      return 'review' as const;
    };
    if (order.status !== 'PENDING_PAYMENT') return review(`Pago recibido con el pedido en estado "${ORDER_STATUS_LABEL[order.status]}". Revisar y reembolsar si procede.`);
    if (order.stripeCheckoutSessionId && order.stripeCheckoutSessionId !== p.sessionId) return review('Pago recibido desde una sesión de pago distinta a la registrada.');
    if (p.amountTotal !== order.totalCents || (p.currency ?? '').toLowerCase() !== 'eur') {
      return review(`El importe cobrado (${p.amountTotal} ${p.currency}) no coincide con el total del pedido (${order.totalCents} eur).`);
    }

    await tx.order.update({
      where: { id: order.id },
      data: { status: 'PAID', paymentStatus: 'SUCCEEDED', paidAt: new Date(), stripePaymentIntentId: p.paymentIntentId, reservationExpiresAt: null }
    });
    await tx.payment.create({
      data: { orderId: order.id, providerRef: p.paymentIntentId ?? p.sessionId, status: 'SUCCEEDED', amountCents: p.amountTotal }
    });
    await tx.orderEvent.create({ data: { orderId: order.id, fromStatus: 'PENDING_PAYMENT', toStatus: 'PAID', message: 'Pago confirmado por Stripe.' } });
    if (order.cartId) {
      await tx.cartItem.deleteMany({ where: { cartId: order.cartId } });
      await tx.cart.updateMany({ where: { id: order.cartId }, data: { pendingOrderId: null, couponCode: null } });
    }
    return 'paid' as const;
  });
  if (result === 'paid') await sendOrderEmail(p.orderId, 'orderConfirmation');
  return result;
}

export async function markPaymentPending(orderId: string, paymentIntentId: string | null) {
  await db.order.updateMany({ where: { id: orderId, status: 'PENDING_PAYMENT' }, data: { stripePaymentIntentId: paymentIntentId } });
  await db.orderEvent.create({ data: { orderId, message: 'Pago iniciado con un método de confirmación diferida. Esperando confirmación.' } });
}

export async function markPaymentFailed(orderId: string, message: string) {
  await db.payment.create({ data: { orderId, status: 'FAILED', amountCents: 0, failureMessage: message.slice(0, 300) } });
  await db.order.updateMany({ where: { id: orderId, status: 'PENDING_PAYMENT' }, data: { paymentStatus: 'FAILED' } });
  await cancelPendingOrder(orderId, `Pago fallido: ${message}`, { skipStripe: true });
}

export async function markRefund(paymentIntentId: string, refundedCents: number, chargedCents: number) {
  const order = await db.order.findUnique({ where: { stripePaymentIntentId: paymentIntentId } });
  if (!order) return;
  const full = refundedCents >= chargedCents;
  const changed = await db.$transaction(async (tx) => {
    await tx.payment.updateMany({ where: { orderId: order.id, status: { in: ['SUCCEEDED', 'PARTIALLY_REFUNDED'] } }, data: { refundedCents, status: full ? 'REFUNDED' : 'PARTIALLY_REFUNDED' } });
    if (full && order.status === 'REFUNDED') return false;
    await tx.order.update({
      where: { id: order.id },
      data: full ? { status: 'REFUNDED', paymentStatus: 'REFUNDED' } : { paymentStatus: 'PARTIALLY_REFUNDED' }
    });
    await tx.orderEvent.create({
      data: {
        orderId: order.id,
        fromStatus: full ? order.status : null,
        toStatus: full ? 'REFUNDED' : null,
        message: full ? 'Reembolso total confirmado por Stripe. Revisa si hay que reponer stock.' : `Reembolso parcial confirmado por Stripe (${(refundedCents / 100).toFixed(2)} €).`
      }
    });
    return full;
  });
  if (changed) await sendOrderEmail(order.id, 'refunded');
}

// ---------------------------------------------------------------------------
// Acciones del panel
// ---------------------------------------------------------------------------

export async function updateOrderStatus(orderId: string, to: OrderStatus, actorId: string, note?: string) {
  const order = await db.order.findUniqueOrThrow({ where: { id: orderId } });
  if (!canTransition(order.status, to)) throw new Error(`No se puede pasar de "${ORDER_STATUS_LABEL[order.status]}" a "${ORDER_STATUS_LABEL[to]}".`);
  if (to === 'SHIPPED') throw new Error('Para marcar como enviado, registra el envío con su número de seguimiento.');
  if (to === 'CANCELLED') {
    const ok = await cancelPendingOrder(orderId, note || 'Cancelado desde el panel.', { actorId });
    if (!ok) throw new Error('No se ha podido cancelar: el pago puede haberse completado. Recarga la página.');
    await sendOrderEmail(orderId, 'cancelled');
    return;
  }
  const res = await db.order.updateMany({ where: { id: orderId, status: order.status }, data: { status: to } });
  if (res.count !== 1) throw new Error('El pedido ha cambiado mientras lo editabas. Recarga la página.');
  await db.orderEvent.create({ data: { orderId, fromStatus: order.status, toStatus: to, actorId, message: note || `Estado cambiado a "${ORDER_STATUS_LABEL[to]}".` } });
  if (to === 'DELIVERED') {
    await db.shipment.updateMany({ where: { orderId, deliveredAt: null }, data: { deliveredAt: new Date() } });
    await sendOrderEmail(orderId, 'delivered');
  }
}

export async function addShipment(orderId: string, data: { carrier: string; trackingNumber: string; trackingUrl?: string }, actorId: string) {
  const order = await db.order.findUniqueOrThrow({ where: { id: orderId } });
  if (order.status !== 'PAID' && order.status !== 'PREPARING') throw new Error('Solo se pueden enviar pedidos pagados o en preparación.');
  await db.$transaction(async (tx) => {
    const res = await tx.order.updateMany({ where: { id: orderId, status: order.status }, data: { status: 'SHIPPED' } });
    if (res.count !== 1) throw new Error('El pedido ha cambiado mientras lo editabas. Recarga la página.');
    await tx.shipment.create({ data: { orderId, ...data } });
    await tx.orderEvent.create({ data: { orderId, fromStatus: order.status, toStatus: 'SHIPPED', actorId, message: `Enviado con ${data.carrier} (${data.trackingNumber}).` } });
  });
  await sendOrderEmail(orderId, 'shipped');
}

export async function requestRefund(orderId: string, actorId: string, amountCents?: number) {
  const order = await db.order.findUniqueOrThrow({ where: { id: orderId } });
  if (!canRefund(order.status, order.paymentStatus) || !order.stripePaymentIntentId) throw new Error('Este pedido no se puede reembolsar.');
  const stripe = getStripe();
  if (!stripe) throw new Error('Stripe no está configurado.');
  if (amountCents != null && (amountCents <= 0 || amountCents > order.totalCents)) throw new Error('Importe de reembolso no válido.');
  await stripe.refunds.create(
    { payment_intent: order.stripePaymentIntentId, ...(amountCents ? { amount: amountCents } : {}), metadata: { orderId, actorId } },
    { idempotencyKey: `refund-${orderId}-${amountCents ?? 'full'}-${Date.now() >> 16}` }
  );
  await db.orderEvent.create({
    data: { orderId, actorId, message: `Reembolso solicitado a Stripe${amountCents ? ` (${(amountCents / 100).toFixed(2)} €)` : ' (total)'}. El estado cambiará al confirmarse.` }
  });
}

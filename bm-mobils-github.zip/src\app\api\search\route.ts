import { db } from '@/lib/db';
import { buildWhere, parseFilters } from '@/lib/catalog/queries';
import { CONDITION_LABEL } from '@/lib/labels';

export const dynamic = 'force-dynamic';

/** Sugerencias del buscador (solo productos publicados, datos públicos). */
export async function GET(req: Request) {
  const q = new URL(req.url).searchParams.get('q')?.trim().slice(0, 80) ?? '';
  if (q.length < 2) return Response.json({ items: [] });
  const rows = await db.product.findMany({
    where: buildWhere({}, { ...parseFilters({}), q }),
    select: { slug: true, name: true, fromPriceCents: true, condition: true, brand: { select: { name: true } } },
    orderBy: [{ featured: 'desc' }, { totalStock: 'desc' }],
    take: 6
  });
  return Response.json(
    { items: rows.map((r) => ({ slug: r.slug, name: r.name, brand: r.brand.name, priceCents: r.fromPriceCents, condition: CONDITION_LABEL[r.condition] })) },
    { headers: { 'Cache-Control': 'public, max-age=30' } }
  );
}

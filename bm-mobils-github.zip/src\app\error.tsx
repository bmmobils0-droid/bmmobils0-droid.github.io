'use client';

import { useEffect } from 'react';
import { Button, ButtonLink } from '@/components/ui/button';

// No se muestran detalles técnicos al cliente; el error queda en el registro del servidor.
export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error(error); }, [error]);
  return (
    <main className="container-page grid min-h-[70dvh] place-items-center py-20 text-center">
      <div>
        <h1 className="text-3xl font-bold">Algo ha fallado</h1>
        <p className="mx-auto mt-3 max-w-md text-muted">Ha ocurrido un error inesperado. Inténtalo de nuevo y, si persiste, contacta con nosotros.</p>
        {error.digest && <p className="mt-2 text-xs text-muted">Referencia: {error.digest}</p>}
        <div className="mt-7 flex justify-center gap-3">
          <Button onClick={reset}>Reintentar</Button>
          <ButtonLink href="/" variant="outline">Ir al inicio</ButtonLink>
        </div>
      </div>
    </main>
  );
}
